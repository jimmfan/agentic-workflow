from pathlib import Path
import hashlib
import json
import shutil
import stat
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = Path(sys.argv[1]).resolve()
assert (ROOT / 'arm-key.json').is_file(), 'wait for independent grading and arm-key reveal'
assert (ROOT / 'grader-view/grading/grades.json').is_file()
assert OUT != ROOT and ROOT not in OUT.parents
OUT.mkdir(parents=True, exist_ok=True)
for name in ['run.json', 'arm-key.json']:
    shutil.copyfile(ROOT / name, OUT / name)
for name in ['grading.txt', 'grades.json']:
    shutil.copyfile(ROOT / 'grader-view/grading' / name, OUT / name)
archive_path = OUT / 'evidence.zip'
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(ROOT.rglob('*')):
        relative = path.relative_to(ROOT)
        if '__pycache__' in relative.parts or path.suffix == '.pyc':
            continue
        if path.is_symlink():
            info = zipfile.ZipInfo(str(relative))
            info.create_system = 3
            info.external_attr = (stat.S_IFLNK | 0o777) << 16
            archive.writestr(info, str(path.readlink()))
        elif path.is_file():
            archive.write(path, str(relative))
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
lines = []
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name != 'SHA256SUMS':
        lines.append(hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + path.name)
(OUT / 'SHA256SUMS').write_text('\n'.join(lines) + '\n')
print(json.dumps({'archive': str(archive_path), 'bytes': archive_path.stat().st_size, 'sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(), 'checksummed_files': len(lines)}))
