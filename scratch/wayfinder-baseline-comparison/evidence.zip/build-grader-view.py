#!/usr/bin/env python3
"""Controller-only, label-only grader input preparation; never a grading run.

Prepare only after X/Y writer and files-only reader captures have completed and
controller validation artifacts have been saved. This helper does not launch
subjects, run audit/integrity scripts, interpret outcomes, or read an arm key.

    python build-grader-view.py
    python build-grader-view.py --include-h X-H Y-H

Optional H inputs may be partial. Their completed, pending, and unexecuted cells
are separately listed; a missing response never becomes a graded endpoint.
Original captures, archives, installed instructions, and consumers are untouched.
"""

from pathlib import Path
import argparse
import datetime
import hashlib
import json
import re
import shutil
import tempfile
import zipfile


ROOT = Path(__file__).resolve().parent
PRIOR = ROOT / "prior" / "evidence"
CAPTURE_NAMES = (
    "request.json", "response.txt", "completion.json",
    "before.json", "before.zip", "after.json", "after.zip",
)
SCRIPTS = ("checkpoint.py", "audit.py", "final-integrity.py")
EVIDENCE_NAMES = (
    "run.json", "session-envelope.txt", "session-envelopes.json",
    "controller-observations.txt", "fresh-reader-input.json",
    "preparation-freeze.json", "frozen-requests.json", "setup.json",
    "audit.json", "final-integrity.json", "integrity-adapter-map.json",
    "validation-execution.json", "limitations.json", "arm-completion.json",
)
VALIDATION_NAMES = (
    "audit.json", "final-integrity.json", "integrity-adapter-map.json",
    "validation-execution.json",
)
# Deliberately exclude schema versions and synthetic r16/r17/v2/v3 qualifiers.
PROVENANCE_KEYS = {
    "framework_commit", "framework_version", "framework_revision",
    "framework_condition", "framework_label", "source_head", "source_commit",
    "source_revision", "source_version", "source_label", "checkout_head",
    "repository_head", "repository_commit", "git_head", "git_commit",
    "pinned_commit", "pinned_revision", "revision_label", "condition_label",
    "baseline_commit", "current_commit", "baseline_revision", "current_revision",
}
GIT_PIN = re.compile(r"(?<![0-9a-fA-F])[0-9a-fA-F]{40}(?![0-9a-fA-F])")
VERSION_PIN = re.compile(
    r"(?im)(?:\bVERSION\s*[:=]|\b(?:framework|agentic.workflow|installed|source)"
    r"[\w\s\"'_-]{0,40}(?:version|release))[^\n]{0,80}?\b\d+\.\d+(?:\.\d+)?\b"
)
VERSION_LINE = re.compile(r"\b\d+\.\d+\.\d+\b")
PRIOR_OUTCOME = "Earlier 220 + 94 passing tests remain earlier-session evidence."
COVER_NOTE = """FACTUAL COVER NOTE — INPUT PACKAGING AND HISTORICAL CONTEXT

The grading task is grader-task.txt. Its original procedural and criterion wording
is preserved, with arm/count/path substitutions, discovery of each arm's own
installed instructions, and the unavoidable change of diagnostic context.

Two blinded arms each receive frozen W1-W31 and a files-only fresh reader.
Authority controls are intentionally omitted. There is one trajectory per arm;
exact host/model identity is inherited and unavailable. No exact inherited-host
match is asserted. Optional X-H/Y-H inputs are writers only. arms.json lists each
arm's captured completed turns, prepared pending requests, and unexecuted cells.
Only completed cells have public response endpoints in this supplied input set.

The common protocol and expected-meaning notes retain historical preparation
language for the frozen scenario and rubric. Their approval, status, and coverage
statements describe that prior preparation, not findings for these arms. The
original prior grader task also stated:

"No PR-description requirement was exercised because no PR was created. The
stale-count repair occurred before the planned local-check turn; assess the
resulting evidence-discrimination probe and its reduced planned trigger coverage."

That statement and its original directive concern the prior diagnostic only;
they do not establish whether either event occurred in these new arms. The
untouched original task is preserved outside the supplied view. No prior grades,
outcome fields, or reasons are supplied. rubric-definitions.json contains only
the unchanged dimension_scopes and G01-G10 id/check definitions.

Common protocol/notes/scripts/rubric are in evidence/. Each arm's available run,
timing/session, audit, reader-input, and capture files are in arms/<label>/evidence/.
The original session-envelopes filename may instead be session-envelope.txt;
arms.json lists missing metadata files. Optional partial H arms can lack validation
outputs. final-integrity.json has legacy slots described by integrity-adapter-map.json;
validation aliases are not extra evaluation subjects or independent observations.

sanitation-ledger.json records provenance field/line omissions in view copies
without including removed values. copy-inventory.json records original/view
hashes. External framework/source metadata, including source_head and its printed
validation copy, is omitted. Archives, public responses, consumers, installed
instructions, scripts, and rubric definitions retain original bytes. Domain
r16/r17 and v2/v3 qualifiers remain literal.

Preserved absolute paths and symlink targets are captured evidence; originals
outside this view are outside the grading read scope. The supplied input roots
are the view paths in grader-task.txt. Installed instructions, file layout, and
behavior may permit condition inference. Label-only grading does not establish
full blinding or hard read isolation. This view contains no arm key.
"""


def digest(body):
    return hashlib.sha256(body).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def save_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def regular_file(path):
    if not path.is_file() or path.is_symlink():
        raise ValueError(f"expected a physical controller file: {path}")


def scan_immutable(body, location, findings):
    """Do not print the values of residual identity pins, even on failure."""
    text = body.decode("utf-8", errors="replace")
    if GIT_PIN.search(text):
        findings.append({"location": location, "rule": "explicit commit pin"})
    if VERSION_PIN.search(text):
        findings.append({"location": location, "rule": "explicit framework version"})


def inspect_arm(label):
    arm = ROOT / "live" / label
    evidence = arm / "evidence"
    if not evidence.is_dir() or evidence.resolve() != evidence:
        raise ValueError(f"missing or linked controller evidence: {label}")
    regular_file(evidence / "run.json")
    required = {("subject-01", n) for n in range(1, 32)}
    is_h = label.endswith("-H")
    if not is_h:
        required.add(("subject-04", 1))
    completed = set()
    prepared = set()
    findings = []
    for turn in sorted((evidence / "turns").glob("*/*")):
        if not turn.is_dir() or turn.is_symlink():
            raise ValueError(f"invalid turn capture directory: {label}/{turn.name}")
        subject, ordinal = turn.parent.name, turn.name
        if not ordinal.isdigit() or ordinal != f"{int(ordinal):02d}":
            raise ValueError(f"noncanonical turn capture: {label}/{subject}/{ordinal}")
        key = (subject, int(ordinal))
        if key not in required:
            raise ValueError(f"capture outside approved arm scope: {label}/{subject}/{ordinal}")
        if (turn / "request.json").is_file():
            prepared.add(key)
            regular_file(turn / "request.json")
            request = read_json(turn / "request.json")
            if request.get("subject") != subject or request.get("ordinal") != int(ordinal):
                raise ValueError(f"request identity mismatch: {label}/{subject}/{ordinal}")
        if (turn / "completion.json").exists():
            for name in CAPTURE_NAMES:
                regular_file(turn / name)
            completed.add(key)
        for name in ("before.zip", "after.zip"):
            archive = turn / name
            if not archive.exists():
                continue
            regular_file(archive)
            with zipfile.ZipFile(archive) as z:
                for member in z.infolist():
                    if not member.is_dir():
                        scan_immutable(z.read(member), f"arms/{label}/evidence/turns/{subject}/{ordinal}/{name}::{member.filename}", findings)
    recorded = read_json(evidence / "run.json").get("completed_turns", [])
    expected_recorded = {f"{subject}:{n}" for subject, n in completed}
    if len(recorded) != len(expected_recorded) or set(recorded) != expected_recorded:
        raise ValueError(f"run.json completed_turns disagrees with captures: {label}")
    pending = prepared - completed
    if not is_h and (completed != required or pending):
        raise ValueError(f"normal arm endpoints not ready: {label}; completed={len(completed)}, missing={len(required-completed)}, pending={len(pending)}")
    if not is_h or completed == required:
        for name in VALIDATION_NAMES:
            regular_file(evidence / name)
    subjects = ("subject-01",) if is_h else ("subject-01", "subject-04")
    for subject in subjects:
        consumer = arm / "subjects" / subject
        if not consumer.is_dir() or consumer.is_symlink():
            raise ValueError(f"missing or linked saved consumer: {label}/{subject}")
        for path in sorted(consumer.rglob("*")):
            relative = str(path.relative_to(consumer))
            if path.is_symlink():
                scan_immutable(str(path.readlink()).encode(), f"arms/{label}/subjects/{subject}/{relative} (symlink target)", findings)
            elif path.is_file():
                scan_immutable(path.read_bytes(), f"arms/{label}/subjects/{subject}/{relative}", findings)
    return {
        "label": label, "arm": arm, "evidence": evidence,
        "required": required, "completed": completed, "prepared": prepared,
        "subjects": subjects, "residual_identity_findings": findings,
    }


def sanitize_json(value, file_name, ledger, pointer=""):
    if isinstance(value, dict):
        clean = {}
        for key, item in value.items():
            field = key.casefold().replace("-", "_")
            here = pointer + "/" + key.replace("~", "~0").replace("/", "~1")
            provenance = field in PROVENANCE_KEYS
            if field in {"framework", "condition", "commit", "revision", "version"} and isinstance(item, str):
                provenance = bool(GIT_PIN.search(item) or VERSION_LINE.search(item) or item.casefold() in {"baseline", "current", "current-main", "historical"})
            if provenance:
                ledger.append({"file": file_name, "location": here, "action": "omit field in view copy", "rule": "explicit framework/source provenance"})
                continue
            clean[key] = sanitize_json(item, file_name, ledger, here)
        return clean
    if isinstance(value, list):
        return [sanitize_json(item, file_name, ledger, pointer + "/" + str(index)) for index, item in enumerate(value)]
    if isinstance(value, str) and pointer.rsplit("/", 1)[-1] in {"stdout", "stderr"}:
        # The unchanged legacy integrity script also prints its JSON result.
        # Validation captures that result as a string, so sanitize its nested
        # metadata without losing the execution status or altering originals.
        try:
            nested = json.loads(value)
        except (ValueError, TypeError):
            return sanitize_text(value, file_name + "#" + pointer, ledger)
        if isinstance(nested, (dict, list)):
            cleaned = sanitize_json(nested, file_name, ledger, pointer + "/decoded-json")
            return json.dumps(cleaned, ensure_ascii=False) + ("\n" if value.endswith("\n") else "")
    return value


def sanitize_text(text, file_name, ledger, protocol=False):
    clean = []
    for number, line in enumerate(text.splitlines(keepends=True), 1):
        # Protocol tool-version provenance is omitted with its whole line, too;
        # scenario revision/profile words and rubric wording remain literal.
        rule = None
        if GIT_PIN.search(line) or VERSION_PIN.search(line) or (protocol and VERSION_LINE.search(line)):
            rule = "explicit provenance pin/version line"
        elif PRIOR_OUTCOME in line:
            rule = "prior outcome claim excluded from new-arm inputs"
        if rule:
            ledger.append({"file": file_name, "location": f"line {number}", "action": "omit line in view copy", "rule": rule})
        else:
            clean.append(line)
    return "".join(clean)


def copy_file(source, dest, staging, ledger, inventory, sanitize=True, protocol=False):
    regular_file(source)
    original = source.read_bytes()
    body = original
    name = str(dest.relative_to(staging))
    if sanitize and source.suffix == ".json":
        body = (json.dumps(sanitize_json(json.loads(original), name, ledger), ensure_ascii=False, indent=2) + "\n").encode()
    elif sanitize and source.suffix == ".txt":
        body = sanitize_text(original.decode(), name, ledger, protocol).encode()
    residual = []
    scan_immutable(body, name, residual)
    if residual:
        raise ValueError("residual identity metadata requires controller review: " + json.dumps(residual))
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(body)
    inventory.append({"file": name, "source": str(source.relative_to(ROOT)), "source_sha256": digest(original), "view_sha256": digest(body), "byte_identical": body == original})


def copy_consumer(source, dest, staging, inventory):
    shutil.copytree(source, dest, symlinks=True)
    for path in sorted(source.rglob("*")):
        target = dest / path.relative_to(source)
        name = str(target.relative_to(staging))
        if path.is_symlink():
            if target.readlink() != path.readlink():
                raise ValueError(f"copied symlink target changed: {name}")
            inventory.append({"file": name, "kind": "symlink", "target_preserved": True})
        elif path.is_file():
            original = path.read_bytes()
            if target.read_bytes() != original:
                raise ValueError(f"copied consumer bytes changed: {name}")
            inventory.append({"file": name, "source_sha256": digest(original), "view_sha256": digest(original), "byte_identical": True})


def cell(subject, n):
    return {"subject": subject, "ordinal": n}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--include-h", nargs="+", choices=("X-H", "Y-H"), default=[])
    args = parser.parse_args()
    labels = ["X", "Y"] + list(dict.fromkeys(args.include_h))
    destination = ROOT / "grader-view"
    if destination.exists() or destination.is_symlink():
        raise SystemExit("refusing to overwrite existing grader-view")
    # All preflight reads happen before any view directory or output is created.
    infos = [inspect_arm(label) for label in labels]
    residual = [finding for info in infos for finding in info["residual_identity_findings"]]
    if residual:
        raise SystemExit("immutable evidence contains explicit provenance; originals left unchanged; controller review required: " + json.dumps(residual, indent=2))
    for name in SCRIPTS:
        original = (PRIOR / name).read_bytes()
        for info in infos:
            script = info["evidence"] / name
            regular_file(script)
            if script.read_bytes() != original:
                raise SystemExit(f"original script bytes differ: {info['label']}/{name}")
    rubric = read_json(ROOT / "rubric-definitions.json")
    if set(rubric) != {"dimension_scopes", "global_checks"}:
        raise SystemExit("rubric-definitions.json contains fields beyond frozen definitions")
    if set(rubric["dimension_scopes"]) != {"preservation", "correctness", "authorization", "dependencies", "continuation"}:
        raise SystemExit("frozen dimension scope keys changed")
    if any(set(item) != {"id", "check"} for item in rubric["global_checks"]):
        raise SystemExit("global definitions must not contain outcomes or reasons")
    template = (ROOT / "grader-task-template.txt").read_text()
    staging = Path(tempfile.mkdtemp(prefix=".grader-view-staging-", dir=ROOT))
    ledger, inventory, arms = [], [], []
    try:
        common = staging / "evidence"
        common.mkdir()
        for name in SCRIPTS:
            copy_file(PRIOR / name, common / name, staging, ledger, inventory, sanitize=False)
        copy_file(PRIOR / "grading-notes.txt", common / "grading-notes.txt", staging, ledger, inventory)
        copy_file(PRIOR / "approved-protocol.txt", common / "approved-protocol.txt", staging, ledger, inventory, protocol=True)
        copy_file(ROOT / "rubric-definitions.json", common / "rubric-definitions.json", staging, ledger, inventory, sanitize=False)
        ledger.append({"file": "grader-task.txt", "location": "adapted task", "action": "paths/arm scope/layout discovery/comparison context adapted", "rule": "original task retained outside view; prior no-PR/stale-count statements moved to historical-only factual cover note", "source_sha256": digest((PRIOR / "grader-task.txt").read_bytes())})
        for info in infos:
            label = info["label"]
            arm_dest = staging / "arms" / label
            evidence_dest = arm_dest / "evidence"
            evidence_dest.mkdir(parents=True)
            missing_metadata = []
            for name in EVIDENCE_NAMES:
                source = info["evidence"] / name
                if source.exists():
                    copy_file(source, evidence_dest / name, staging, ledger, inventory)
                else:
                    missing_metadata.append(name)
            for name in SCRIPTS:
                copy_file(info["evidence"] / name, evidence_dest / name, staging, ledger, inventory, sanitize=False)
            for source in sorted((info["evidence"] / "turns").glob("*/*/*")):
                if source.name not in CAPTURE_NAMES:
                    raise ValueError(f"unexpected per-turn evidence file requires review: {label}/{source.name}")
                relative = source.relative_to(info["evidence"])
                copy_file(source, evidence_dest / relative, staging, ledger, inventory, sanitize=source.suffix == ".json")
            for subject in info["subjects"]:
                copy_consumer(info["arm"] / "subjects" / subject, arm_dest / "subjects" / subject, staging, inventory)
            completed = info["completed"]
            required = info["required"]
            pending = info["prepared"] - completed
            arms.append({
                "label": label, "writer_subject": "subject-01",
                "reader_subject": None if label.endswith("-H") else "subject-04",
                "completed_turn_count": len(completed),
                "completed_cells": [cell(*key) for key in sorted(completed)],
                "pending_cells": [cell(*key) for key in sorted(pending)],
                "unexecuted_cells": [cell(*key) for key in sorted(required - completed - pending)],
                "missing_endpoint_cells": [cell(*key) for key in sorted(required - completed)],
                "capture_coverage": "complete" if completed == required else "partial",
                "authority_controls": "intentionally omitted; unexercised",
                "missing_metadata_files": missing_metadata,
            })
        save_json(staging / "arms.json", {"arms": arms, "scope": "Completed captured endpoints only; pending and unexecuted cells have no endpoint grade. Labels have no condition key in this view."})
        (staging / "grading").mkdir()
        layout = "\n".join(
            f"- {item['label']}: evidence {destination}/arms/{item['label']}/evidence; saved writer {destination}/arms/{item['label']}/subjects/subject-01"
            + (f"; saved files-only reader {destination}/arms/{item['label']}/subjects/subject-04" if item['reader_subject'] else "; no reader ran in this arm")
            + f"; {item['completed_turn_count']} completed captured turns ({item['capture_coverage']})."
            for item in arms
        )
        scopes = []
        for item in arms:
            writers = sum(cell["subject"] == "subject-01" for cell in item["completed_cells"])
            readers = sum(cell["subject"] == "subject-04" for cell in item["completed_cells"])
            scope = f"{item['label']} writer {writers}"
            if item["reader_subject"]:
                scope += f", files-only reader {readers}"
            scopes.append(scope)
        task = template.replace("@@VIEW_ROOT@@", str(destination)).replace("@@ARM_LAYOUT@@", layout).replace("@@COMPLETED_TURN_COUNT@@", str(sum(item["completed_turn_count"] for item in arms))).replace("@@TURN_SCOPE@@", "; ".join(scopes))
        if "@@" in task:
            raise ValueError("unresolved task template placeholder")
        (staging / "grader-task.txt").write_text(task)
        (staging / "cover-note.txt").write_text(COVER_NOTE)
        save_json(staging / "sanitation-ledger.json", {
            "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "redactions": ledger,
            "scope": "Only view copies of external evidence metadata/text were sanitized. Original captures/consumers were not modified. Archives, public response text, consumer files, installed instructions, scripts, and rubric definitions retain original bytes. Removed values are not recorded in grader inputs.",
            "blinding_limit": "Installed instruction content, file layout, and behavior can permit condition inference. Label-only grading does not establish full blinding or hard read isolation.",
        })
        save_json(staging / "copy-inventory.json", {"files": inventory, "scope": "Hashes describe preservation/redaction provenance, not evaluation outcomes."})
        final_findings = []
        for path in staging.rglob("*"):
            if path.is_file() and not path.is_symlink() and path.suffix != ".zip":
                scan_immutable(path.read_bytes(), str(path.relative_to(staging)), final_findings)
        if final_findings:
            raise ValueError("residual identity metadata in staged view: " + json.dumps(final_findings))
        staging.rename(destination)
        print(json.dumps({"grader_view": str(destination), "factual_cover_note": str(destination / "cover-note.txt"), "grader_task": str(destination / "grader-task.txt"), "labels": labels, "completed_turns": sum(item["completed_turn_count"] for item in arms), "redaction_count": len(ledger), "grading_run": False}, indent=2))
    finally:
        if staging.exists():
            shutil.rmtree(staging)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, zipfile.BadZipFile) as error:
        raise SystemExit(str(error))
