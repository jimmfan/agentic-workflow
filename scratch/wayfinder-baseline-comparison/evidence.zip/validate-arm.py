#!/usr/bin/env python3
"""Controller-only endpoint validation; never run this inside a subject session.

Usage, only after the selected arm's approved endpoints are captured:
    python wayfinder-baseline-comparison/validate-arm.py X
    python wayfinder-baseline-comparison/validate-arm.py Y
    python wayfinder-baseline-comparison/validate-arm.py X-H
    python wayfinder-baseline-comparison/validate-arm.py Y-H

The unchanged audit runs against the actual arm. The unchanged legacy integrity
script runs in a validation-only adapter, with explicit aliases for its four
hardcoded slots. Those aliases are not additional evaluation sessions.
"""

from pathlib import Path
import argparse
import datetime
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent
SCRATCH = ROOT.parent
ORIGINAL_HASHES = {
    "audit.py": "de10af2940077807bcf290010912c585619f91f54c88ada40205b65adb2a51f4",
    "final-integrity.py": "f72f51e3490b5af80640a09005b4dc0ce6b558567699d5296f726b96b15dc3cc",
}
CAPTURE_FILES = (
    "request.json", "response.txt", "completion.json",
    "before.json", "before.zip", "after.json", "after.zip",
)


def read_json(path):
    return json.loads(path.read_text())


def save_json(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n")


def identity(entry):
    return {key: value for key, value in entry.items() if key != "mtime_ns"}


def changed_paths(left, right):
    return [
        name for name in sorted(left.keys() | right.keys())
        if identity(left.get(name, {})) != identity(right.get(name, {}))
    ]


def build_adapter(adapter, evidence, arm, mapping, adapter_map):
    staging = Path(tempfile.mkdtemp(prefix=f"{adapter.name}-staging-", dir=SCRATCH))
    try:
        staged_evidence = staging / "evidence"
        staged_evidence.mkdir()
        (staging / "subjects").mkdir()
        script = staged_evidence / "final-integrity.py"
        shutil.copyfile(evidence / script.name, script)
        if script.read_bytes() != (evidence / script.name).read_bytes():
            raise SystemExit("adapter script copy is not byte-identical")
        for item in mapping:
            legacy = item["legacy_slot"]
            slot = staged_evidence / "turns" / legacy["subject"] / f'{legacy["ordinal"]:02d}'
            slot.mkdir(parents=True)
            (slot / "after.json").symlink_to(arm / item["checkpoint"])
            (staging / "subjects" / legacy["subject"]).symlink_to(
                arm / item["consumer"], target_is_directory=True
            )
        save_json(staged_evidence / "adapter-map.json", adapter_map)
        staging.rename(adapter)
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    return adapter / "evidence"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("arm", choices=("X", "Y", "X-H", "Y-H"))
    args = parser.parse_args()
    label = args.arm
    arm = ROOT / "live" / label
    evidence = arm / "evidence"
    writers_only = label.endswith("-H")
    required = {("subject-01", number) for number in range(1, 32)}
    if not writers_only:
        required.add(("subject-04", 1))

    # Refuse partial, extra, or unrecorded sessions before running either script.
    if not evidence.is_dir():
        raise SystemExit(f"arm evidence missing: {evidence}")
    if evidence.resolve() != evidence:
        raise SystemExit("arm evidence must be a physical controller directory")
    for name in ("audit.json", "final-integrity.json", "integrity-adapter-map.json", "validation-execution.json"):
        output = evidence / name
        if output.is_symlink() or (output.exists() and (not output.is_file() or output.stat().st_nlink != 1)):
            raise SystemExit(f"refusing linked or non-file controller output: {output}")
    completed = set()
    for path in (evidence / "turns").glob("*/*/completion.json"):
        subject = path.parent.parent.name
        ordinal = path.parent.name
        if not ordinal.isdigit() or ordinal != f"{int(ordinal):02d}":
            raise SystemExit(f"noncanonical completed turn directory: {path.parent}")
        key = (subject, int(ordinal))
        if key in completed:
            raise SystemExit(f"duplicate completed capture: {key}")
        completed.add(key)
    if completed != required:
        raise SystemExit(
            "endpoints not ready or outside approved scope: "
            + json.dumps({"missing": sorted(required - completed),
                          "unexpected": sorted(completed - required)})
        )
    pending = [
        str(path.parent.relative_to(evidence))
        for path in (evidence / "turns").glob("*/*/request.json")
        if not (path.parent / "completion.json").is_file()
    ]
    if pending:
        raise SystemExit("unfinished prepared requests: " + json.dumps(pending))
    expected_keys = {f"{subject}:{number}" for subject, number in required}
    recorded_keys = read_json(evidence / "run.json")["completed_turns"]
    if set(recorded_keys) != expected_keys or len(recorded_keys) != len(expected_keys):
        raise SystemExit("run.json completed_turns disagrees with completed captures")
    for subject, number in sorted(required):
        turn = evidence / "turns" / subject / f"{number:02d}"
        missing = [name for name in CAPTURE_FILES if not (turn / name).is_file()]
        if missing:
            raise SystemExit(f"incomplete capture {turn}: {missing}")
        request = read_json(turn / "request.json")
        if request["subject"] != subject or request["ordinal"] != number:
            raise SystemExit(f"request identity mismatch: {turn}")
    for subject in {subject for subject, _ in required}:
        if not (arm / "subjects" / subject).is_dir():
            raise SystemExit(f"completed consumer missing: {subject}")

    hashes = {}
    for name, expected_hash in ORIGINAL_HASHES.items():
        prior_bytes = (ROOT / "prior" / "evidence" / name).read_bytes()
        arm_script = evidence / name
        if arm_script.is_symlink():
            raise SystemExit(f"arm script must be a regular copied file: {name}")
        arm_bytes = arm_script.read_bytes()
        actual_hash = hashlib.sha256(arm_bytes).hexdigest()
        if arm_bytes != prior_bytes or actual_hash != expected_hash:
            raise SystemExit(f"original script bytes changed: {name}")
        hashes[name] = actual_hash

    adapter = SCRATCH / f"integrity-{label}"
    if adapter.exists() or adapter.is_symlink():
        raise SystemExit(f"refusing to overwrite an existing validation adapter: {adapter}")

    slots = [("subject-01", 31), ("subject-02", 2),
             ("subject-03", 2), ("subject-04", 1)]
    mapping = []
    for legacy_subject, legacy_number in slots:
        actual_subject = "subject-04" if legacy_subject == "subject-04" and not writers_only else "subject-01"
        actual_number = 1 if actual_subject == "subject-04" else 31
        actual_turn = evidence / "turns" / actual_subject / f"{actual_number:02d}"
        alias_only = (legacy_subject, legacy_number) != (actual_subject, actual_number)
        mapping.append({
            "legacy_slot": {"subject": legacy_subject, "ordinal": legacy_number},
            "actual_completed_endpoint": {"subject": actual_subject, "ordinal": actual_number},
            "checkpoint": str((actual_turn / "after.json").relative_to(arm)),
            "consumer": str((arm / "subjects" / actual_subject).relative_to(arm)),
            "alias_only": alias_only,
            "scope": "validation alias only; no additional session ran" if alias_only else "actual completed endpoint",
        })

    scope = (
        "Controller-only validation adapter. N/A controls were not run. "
        + ("This H arm ran a writer only; all four legacy slots alias writer31, and no H reader ran. "
           if writers_only else
           "Writer31 is repeated in the legacy N/A slots; reader1 is the actual completed files-only reader. ")
        + "Legacy subject names and ordinals in final-integrity.json must be interpreted through this map. "
        "Repeated writer aliases are one endpoint check, not independent observations. "
        "The unchanged integrity script's source_head describes its shared source checkout, not an arm revision assignment. "
        "Checks establish captured file bytes and symlink targets only, not transient-write absence, tool order, or hard isolation."
    )
    adapter_map = {
        "arm": label,
        "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "adapter": str(adapter),
        "original_script_sha256": hashes,
        "actual_completed_turn_count": len(required),
        "scope": scope,
        "slots": mapping,
        "reader_copy_note": "The helper neither copies nor rewrites reader files or references; their usability still requires reader evidence inspection.",
    }
    if not writers_only:
        writer_after = read_json(evidence / "turns/subject-01/31/after.json")["entries"]
        reader_before = read_json(evidence / "turns/subject-04/01/before.json")["entries"]
        reader_after = read_json(evidence / "turns/subject-04/01/after.json")["entries"]
        adapter_map["reader_boundary_observations"] = {
            "writer_final_vs_reader_initial_changed_paths": changed_paths(writer_after, reader_before),
            "reader_initial_vs_final_changed_paths": changed_paths(reader_before, reader_after),
            "scope": "Byte/symlink differences only; copy exclusions or path usability require separate interpretation. No PASS or FAIL assigned here.",
        }
    adapter_evidence = build_adapter(adapter, evidence, arm, mapping, adapter_map)
    save_json(evidence / "integrity-adapter-map.json", adapter_map)
    print(json.dumps({"arm": label, "adapter_map": str(evidence / "integrity-adapter-map.json"), "scope": scope}), flush=True)

    executions = []
    for script in (evidence / "audit.py", adapter_evidence / "final-integrity.py"):
        result = subprocess.run([sys.executable, str(script)], capture_output=True, text=True)
        executions.append({"script": script.name, "returncode": result.returncode,
                           "stdout": result.stdout, "stderr": result.stderr})
        if result.stdout:
            print(result.stdout, end="", flush=True)
        if result.stderr:
            print(result.stderr, end="", file=sys.stderr, flush=True)
    final_output = adapter_evidence / "final-integrity.json"
    if final_output.is_file():
        # Preserve the legacy output bytes; mapping/scope live in a separate file.
        shutil.copyfile(final_output, evidence / "final-integrity.json")
    save_json(evidence / "validation-execution.json", {
        "arm": label, "executions": executions,
        "scope": "Original audit ran against actual captures; original integrity ran only through the documented validation aliases.",
    })
    failed = any(item["returncode"] != 0 for item in executions)
    if not failed:
        audit = read_json(evidence / "audit.json")
        integrity = read_json(evidence / "final-integrity.json")
        failed = bool(audit["violations"]) or not integrity["source_clean"] or any(
            not item["matches_captured_final_boundary"] for item in integrity["subjects"]
        )
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
