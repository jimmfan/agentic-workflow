# E2 — Corrected kiosk availability report

Source: User relaying and correcting a volunteer's report in the museum-audio-package conversation. Recorded 2026-10-03. The user identifies the unavailable device as museum-kiosk-v2 and states museum-kiosk-v3 is available for the scheduled visitor-player check.

Scope: Device availability for the r17 check on museum-kiosk-v3. The temporary unavailability applies to museum-kiosk-v2, outside that check's device boundary.

## Observation

The volunteer's reported unavailable device is museum-kiosk-v2, as corrected by the user. The user reports museum-kiosk-v3 available for the scheduled visitor-player check.
The user states the r17 manifest remains unchanged. The earlier read-only local manifest inspection found revision r17, kiosk_profile=museum-kiosk-v3, 23 clip entries, and checksum_count=23.

## Limitations

The volunteer report and its corrected device identity are user-supplied, secondhand evidence. The v3 availability statement is user-reported; no direct device observation, fresh playback test, or acceptance output was supplied or performed. Availability does not establish successful r17 playback.
The local manifest inspection establishes its listed count and declared checksum count; it does not validate checksum contents or playback. No cause, restoration owner, or return date for v2 was supplied, and those are not r17 check prerequisites.

## Consequence

The v2 downtime creates no device-availability blocker for the scheduled r17 check on v3. Local document delivery remains a prerequisite; final release still requires the r17 visitor-player acceptance result and remains unapproved.
Local FLAC packaging guidance, manifest review, and check instructions in chat can proceed. Archival originals remain WAV. Draft-only acceptance of unresolved playback risk remains limited to packaging instructions. Action authorization is maintained in the [effort scope](../map.md#scope).

- [Local manifest](../../../observations/r17-manifest.json)
- [Acceptance criteria](../../../docs/acceptance.txt)
