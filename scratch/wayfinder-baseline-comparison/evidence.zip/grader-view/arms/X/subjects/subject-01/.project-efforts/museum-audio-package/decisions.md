# Decisions

## D1 — Acceptance of unresolved playback risk for drafting

Authority: User's explicit scoped acceptance in the museum-audio-package conversation, recorded 2026-10-03.

Choice: Accept unresolved r17 playback risk only for drafting the packaging instructions. The user explicitly does not approve final release.

Boundary: Drafting packaging instructions only. Playback suitability and visitor-player acceptance remain unresolved; this is not acceptance of release, broader device compatibility, or other work.

Basis and constraints: Local document delivery is already independent of visitor-player acceptance under the [acceptance criteria](../../docs/acceptance.txt). The public sample remains FLAC and archival originals remain WAV.

Consequences: Draft instructions may proceed with playback identified as unverified. The scoped acceptance itself adds no product-file action authorization. A separate user request on 2026-10-03 authorized writing and delivering docs/export-plan.md, which is now delivered. That authorization does not approve audio export or final release. Kiosk availability is still required for the device check, and final release still requires the r17 visitor-player result. Neither a scheduled date, document delivery, nor this risk acceptance supplies that result.

Maintaining artifact: [Packaging instructions — playback risk and release gate](../../docs/export-plan.md#playback-risk-and-release-gate).
