# Museum audio package

## Objective

Prepare the offline museum audio sample and obtain visitor-player acceptance before final release.

## Scope

Local packaging guidance and later museum-kiosk-v3 visitor-player acceptance for revision r17.
The public sample format is FLAC, committed by the user on 2026-10-03. Archival originals remain WAV.
Effort-state maintenance and chat guidance remain authorized. On 2026-10-03, the user separately authorized writing and delivering docs/export-plan.md; that document delivery is complete. Product-file work beyond that delivery, audio export, and final release are not authorized by this request.

## Ready work

Review the delivered [packaging instructions](../../docs/export-plan.md), provide further guidance in chat, and maintain this effort while awaiting the user's visitor-player result. The document provides local packaging and check instructions; producing audio exports or a media bundle was not part of this delivery.

## Blockers

No device-availability blocker is reported for museum-kiosk-v3; museum-kiosk-v2 downtime is outside the r17 check boundary. Required local document delivery is complete.
Final release still awaits r17 visitor-player acceptance; no acceptance result has been supplied and the user explicitly has not approved release. Draft-only risk acceptance does not clear this gate. The corrected r16 operator report creates no r17 count blocker.
Further product-file work or audio export requires its own action authorization; the authorized packaging-document delivery is complete.

## Dependencies

The visitor-player check for r17 on museum-kiosk-v3 is confirmed for October 12, 2026, as supplied by the user on 2026-10-03. The user will supply its result and reports v3 available. Its prerequisite local document delivery is now supplied by the [packaging instructions](../../docs/export-plan.md). The corrected v2 downtime report does not block or reschedule the v3 check.
Final release also requires an accurate r17 manifest count; the local r17 count check supplies that input. The corrected r16 report is outside this count comparison.

## Current state

The local r17 manifest contains 23 clips for museum-kiosk-v3, matching its checksum count of 23; the local inspection reports playback as not tested.
On 2026-10-03, the user corrected the operator report to revision r16, with museum-kiosk-v3 unchanged: manifest_count=24 and playback=not_tested. This user-supplied report was not independently inspected; its raw output, manifest, bundle identity, and counting method were not supplied. It does not contradict the local r17 count or establish r17 playback acceptance.
Playback acceptance remains outstanding. The user accepted its unresolved risk only for drafting packaging instructions, as preserved in the [scoped acceptance](decisions.md#d1--acceptance-of-unresolved-playback-risk-for-drafting); this neither establishes successful playback nor authorizes product-file changes. A confirmed schedule is not a completed test or acceptance result. Format-support evidence establishes FLAC and WAV support, not visitor-player acceptance.
The user corrected the unavailable device to museum-kiosk-v2 and reported museum-kiosk-v3 available for the scheduled r17 check. The [corrected availability report](evidence/E2-kiosk-temporarily-unavailable.md) preserves source, device boundaries, and limitations. The r17 manifest remains unchanged; availability is not a fresh playback test or acceptance result.
The user committed and reaffirmed FLAC for the public sample on 2026-10-03; archival originals remain WAV. This removes the public-format prerequisite for local guidance.
The user relayed a volunteer report that the kiosk has no OGG decoder. [Volunteer report](evidence/E1-kiosk-ogg-decoder-report.md) preserves this secondhand evidence and the user's explicit qualification that it is not a fresh device test. It does not establish verified device capability or playback acceptance, and it adds no blocker to the retained FLAC path.
The [packaging instructions](../../docs/export-plan.md) were written and delivered on 2026-10-03 with accepted FLAC/WAV choices, the 23-clip r17 baseline, local packaging steps, inspection limitations, and the required visitor-player check. This supplies document delivery only; no audio conversion, bundle assembly, checksum-content verification, or visitor-player acceptance was performed.

## Areas and relationships

The user decides the public format and supplies the visitor-player schedule and result.
Local guidance can proceed without treating that external acceptance as complete.

## Key references

- [Local manifest](../../observations/r17-manifest.json)
- [Local count inspection](../../checks/inspect_bundle.py)
- [Delivered packaging instructions](../../docs/export-plan.md)
- [Format support](../../docs/player-format-support.txt)
- [Secondhand OGG decoder report](evidence/E1-kiosk-ogg-decoder-report.md)
- [Corrected kiosk availability report](evidence/E2-kiosk-temporarily-unavailable.md)
- [Acceptance criteria](../../docs/acceptance.txt)
- [Draft-only playback-risk acceptance](decisions.md#d1--acceptance-of-unresolved-playback-risk-for-drafting)
