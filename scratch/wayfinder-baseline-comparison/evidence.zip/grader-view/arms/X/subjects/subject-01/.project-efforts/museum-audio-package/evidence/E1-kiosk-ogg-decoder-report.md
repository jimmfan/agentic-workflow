# E1 — Secondhand kiosk OGG decoder report

Source: User relaying a volunteer's report in the museum-audio-package conversation. Recorded 2026-10-03. The user explicitly qualified the report as secondhand and not a fresh device test when resuming effort maintenance.

Scope: The museum-kiosk-v3 kiosk considered for the r17 public audio sample; a reported decoder capability, not an r17 playback observation.

## Observation

The volunteer reportedly says the kiosk has no OGG decoder.
The user reaffirmed FLAC for the public sample. Archival originals remain WAV.

## Limitations

This is secondhand, unverified evidence. No direct device inspection, device-test output, test date, decoder inventory, or OGG playback trial was supplied. It must not be represented as a fresh device test, verified device capability, or visitor-player acceptance.
The local format-support source confirms FLAC and WAV support; it does not independently verify the volunteer's negative OGG claim or establish playback acceptance.

## Consequence

The report is a reason for caution if OGG is reconsidered, but the retained FLAC path remains ready for chat guidance. No OGG conversion or decoder change is authorized or scheduled. Final release still requires r17 visitor-player acceptance.

- [Format support](../../../docs/player-format-support.txt)
- [Acceptance criteria](../../../docs/acceptance.txt)
