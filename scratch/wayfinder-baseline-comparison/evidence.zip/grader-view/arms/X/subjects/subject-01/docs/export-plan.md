# Offline audio packaging instructions — r17

## Purpose and delivery status

Prepare an offline public audio sample for revision **r17** on **museum-kiosk-v3**. These local instructions can be delivered before visitor-player acceptance.

This delivery provides the packaging document. Audio conversion, bundle assembly, checksum verification, and visitor-player testing have not been performed as part of this document delivery. Playback acceptance remains outstanding.

## Accepted format choices

The user selected and reaffirmed these choices on 2026-10-03:

| Role | Format | Requirement |
|---|---|---|
| Public sample clips | FLAC | Produce separate lossless public copies using the r17 clip identities. |
| Archival originals | WAV | Preserve the originals unchanged; public FLAC exports do not replace them. |

The [format-support source](player-format-support.txt) establishes FLAC and WAV support for museum-kiosk-v3. It is not a visitor-player test or acceptance result. OGG is outside the accepted public-format choice.

## Local manifest baseline

The [r17 manifest](../observations/r17-manifest.json) identifies museum-kiosk-v3 and lists **23 clips**, `clip-001` through `clip-023`, with archival format WAV. Its declared `checksum_count` is **23**.

Use this revision and clip list when preparing the sample. The earlier reported count of 24 was corrected by the user to revision r16 and is not an r17 count discrepancy.

## Local packaging procedure

1. Locate the authoritative WAV originals corresponding to every r17 clip ID. Reconcile missing, duplicate, or unexpected IDs against the source manifest before presenting a complete r17 sample.
2. Keep those archival originals in WAV and unchanged. Prepare public outputs separately so exporting cannot overwrite the originals.
3. Create one FLAC public copy per r17 clip, preserving the recorded audio and the clip's identity. Record the actual public filename and relative location for each ID; the source manifest's `archive_format: WAV` describes the originals, not the public exports.
4. Assemble a self-contained offline bundle containing the public FLAC files, a copy of the r17 manifest, and an index connecting each clip ID to its public file. Include local usage instructions and the checksums generated for the exported files. Refer to bundled files through paths that resolve without network access.
5. Check that the public-file index and actual exports contain the same 23 clip IDs as the manifest, with no omissions, duplicates, or extras. Verify the generated checksums against the actual public files. A declared checksum count alone is not checksum-content verification.
6. Keep the bundle identified as r17 for museum-kiosk-v3, and retain its manifest, file index, checksum information, and verification results with the sample. Document delivery and local inventory checks do not mark visitor playback as accepted.

These steps describe the packaging work to perform; this document does not claim that a media bundle already exists or has passed those checks.

## Read-only local inspection

From the project root, run the existing [local inspection](../checks/inspect_bundle.py):

```bash
python checks/inspect_bundle.py
```

The observed local result on 2026-10-03 was:

```json
{"checksum_count":23,"kiosk_profile":"museum-kiosk-v3","manifest_count":23,"playback":"not_tested","revision":"r17"}
```

The script parses the source manifest, counts its clip entries, and reads its declared checksum count and revision/profile labels. It does not inspect audio files, calculate or validate checksum contents, contact a device, or run playback. Its `playback` value is fixed to `not_tested`; successful execution is not visitor-player acceptance.

## Required visitor-player check

The user confirmed **October 12, 2026** for the r17 visitor-player check on **museum-kiosk-v3**, after local document delivery, and will supply its result. The user reports v3 available; the unavailable device was corrected to museum-kiosk-v2. Reported availability is not a fresh device test or playback result.

For the device check, identify the actual r17 sample and museum-kiosk-v3 configuration, check the public clips under offline conditions, and record what was exercised and observed. Supply the date, revision, kiosk profile, observed clip count, playback outcome, failures, and any untested coverage or other limitations. A result of `not_tested` leaves acceptance outstanding.

## Playback risk and release gate

On 2026-10-03, the user accepted unresolved playback risk **only for drafting the packaging instructions** and explicitly did not approve final release. That acceptance permits this instructional document while playback remains unverified; it does not resolve the playback question or waive the required visitor-player check.

Final release remains unapproved and requires an accurate r17 manifest count and the required visitor-player acceptance evidence on museum-kiosk-v3. FLAC format support, WAV archive labels, local count inspection, device availability, and document delivery do not establish that acceptance.

See the [acceptance criteria](acceptance.txt). The effort remains open until its required remaining work is satisfied.
