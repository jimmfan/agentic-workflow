from pathlib import Path
import json

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / "observations/r17-manifest.json").read_text())
print(json.dumps({"revision": manifest["revision"], "kiosk_profile": manifest["kiosk_profile"], "manifest_count": len(manifest["clips"]), "checksum_count": manifest["checksum_count"], "playback": "not_tested"}, sort_keys=True))
