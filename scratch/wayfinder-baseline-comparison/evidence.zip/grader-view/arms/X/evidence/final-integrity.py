from pathlib import Path
import datetime
import hashlib
import json
import subprocess

EVIDENCE = Path(__file__).resolve().parent
RUN = EVIDENCE.parent
results = []
for subject, ordinal in [('subject-01',31), ('subject-02',2), ('subject-03',2), ('subject-04',1)]:
    expected = json.loads((EVIDENCE/'turns'/subject/f'{ordinal:02d}'/'after.json').read_text())['entries']
    root = RUN/'subjects'/subject
    actual = {}
    for path in sorted(root.rglob('*')):
        name = str(path.relative_to(root))
        if path.is_symlink():
            actual[name] = {'kind':'symlink','target':str(path.readlink())}
        elif path.is_file():
            body = path.read_bytes()
            actual[name] = {'kind':'file','bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
    expected = {name:{key:value for key,value in entry.items() if key != 'mtime_ns'} for name,entry in expected.items()}
    mismatches = [name for name in sorted(expected.keys() | actual.keys()) if expected.get(name) != actual.get(name)]
    results.append({'subject':subject,'last_completed_turn':ordinal,'matches_captured_final_boundary':not mismatches,'mismatched_paths':mismatches})
source = RUN.parent/'agentic-workflow-pilot-source'
git_status = subprocess.run(['git','status','--porcelain'],cwd=source,capture_output=True,text=True,check=True)
head = subprocess.run(['git','rev-parse','HEAD'],cwd=source,capture_output=True,text=True,check=True)
data = {'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'subjects':results,'source_head':head.stdout.strip(),'source_clean':not git_status.stdout,'source_status':git_status.stdout,'scope':'File bytes and symlink targets at the final boundary; does not establish hard isolation or absence of transient modifications.'}
(EVIDENCE/'final-integrity.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data))
