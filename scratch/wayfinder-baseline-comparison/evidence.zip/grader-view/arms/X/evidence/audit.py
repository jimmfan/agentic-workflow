from pathlib import Path
import hashlib
import json
import zipfile

EVIDENCE = Path(__file__).resolve().parent
freeze = json.loads((EVIDENCE / 'preparation-freeze.json').read_text())
mutable = '.project-efforts/museum-audio-package/'
immutable_files = {x['path']: x['sha256'] for x in freeze['seed_files'] if not x['path'].startswith(mutable) and x['path'] != 'docs/export-plan.md'}
first_before = json.loads((EVIDENCE / 'turns/subject-01/01/before.json').read_text())['entries']
immutable_files['task-skill-catalog.json'] = first_before['task-skill-catalog.json']['sha256']
immutable_symlinks = {x['path']: x['target'] for x in freeze['seed_symlinks']}
rows = []
violations = []
for completed in sorted((EVIDENCE / 'turns').glob('*/*/completion.json')):
    turn = completed.parent
    request = json.loads((turn / 'request.json').read_text())
    completion = json.loads(completed.read_text())
    response = (turn / 'response.txt').read_bytes()
    errors = []
    if hashlib.sha256(response).hexdigest() != completion['response_sha256']:
        errors.append('response hash mismatch')
    for boundary in ('before', 'after'):
        entries = json.loads((turn / f'{boundary}.json').read_text())['entries']
        for name, sha in immutable_files.items():
            if entries.get(name, {}).get('sha256') != sha:
                errors.append(f'{boundary}: immutable file changed or missing: {name}')
        for name, target in immutable_symlinks.items():
            if entries.get(name, {}).get('target') != target:
                errors.append(f'{boundary}: immutable symlink changed or missing: {name}')
        with zipfile.ZipFile(turn / f'{boundary}.zip') as z:
            for name, data in entries.items():
                body = z.read(name)
                if data['kind'] == 'file' and hashlib.sha256(body).hexdigest() != data['sha256']:
                    errors.append(f'{boundary}: snapshot archive hash mismatch: {name}')
                elif data['kind'] == 'symlink' and body.decode() != data['target']:
                    errors.append(f'{boundary}: snapshot symlink mismatch: {name}')
    rows.append({'subject': request['subject'], 'turn': request['ordinal'], 'changed_paths': completion['net_changed_paths'], 'errors': errors})
    violations.extend({'turn': str(turn.relative_to(EVIDENCE)), 'error': error} for error in errors)
corpus = []
for number in range(13, 25):
    turn = EVIDENCE / 'turns' / 'subject-01' / f'{number:02d}'
    if not (turn / 'completion.json').exists():
        continue
    request = json.loads((turn / 'request.json').read_text())
    frozen = next(x for x in freeze['corpus_turns'] if x['turn'] == number)
    matches = request['frozen_request_sha256'] == frozen['sha256'] and request['frozen_request_bytes'] == frozen['bytes']
    with zipfile.ZipFile(turn / 'before.zip') as z:
        payload = z.read('current-context-request.txt')
    matches = matches and hashlib.sha256(payload).hexdigest() == frozen['sha256'] and len(payload) == frozen['bytes']
    corpus.append({'turn': number, 'bytes': len(payload), 'frozen_payload_exactly_staged': matches, 'complete_consumption_observed': False})
    if not matches:
        violations.append({'turn': f'subject-01/{number:02d}', 'error': 'corpus mismatch'})
transitions = []
def identity(entry):
    return {k:v for k,v in entry.items() if k != 'mtime_ns'}
for subject in sorted((EVIDENCE / 'turns').iterdir()):
    previous = None
    for turn in sorted(subject.glob('*/completion.json')):
        current = turn.parent
        if previous is not None:
            before = json.loads((current/'before.json').read_text())['entries']
            after = json.loads((previous/'after.json').read_text())['entries']
            changed = [name for name in sorted(before.keys() | after.keys()) if identity(before.get(name,{})) != identity(after.get(name,{}))]
            permitted = ['current-context-request.txt'] if subject.name == 'subject-01' and 13 <= int(current.name) <= 24 else []
            unexpected = [name for name in changed if name not in permitted]
            transitions.append({'subject':subject.name,'from_turn':int(previous.name),'to_turn':int(current.name),'controller_changed_paths':changed,'unexpected_changes':unexpected})
            violations.extend({'turn':f'{subject.name}/{current.name}','error':f'unexpected between-turn change: {name}'} for name in unexpected)
        previous = current
result = {'completed_turns': len(rows), 'immutable_file_count': len(immutable_files), 'immutable_symlink_count': len(immutable_symlinks), 'violations': violations, 'turns': rows, 'between_turn_transitions':transitions, 'context_corpus': corpus, 'context_payload_bytes_staged': sum(x['bytes'] for x in corpus), 'snapshot_scope': 'turn boundaries only; no transient-write or tool-order proof'}
(EVIDENCE / 'audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'completed_turns':len(rows), 'violations':violations, 'context_payload_bytes_staged':result['context_payload_bytes_staged']}))
