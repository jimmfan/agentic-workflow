from pathlib import Path
import datetime
import hashlib
import json
import stat
import sys
import zipfile

RUN = Path(__file__).resolve().parents[1]
EVIDENCE = RUN / 'evidence'
REQUESTS = json.loads((EVIDENCE / 'frozen-requests.json').read_text())

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')

def snapshot(root, prefix):
    entries = {}
    with zipfile.ZipFile(prefix.with_suffix('.zip'), 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(root.rglob('*')):
            name = str(path.relative_to(root))
            if path.is_symlink():
                target = str(path.readlink())
                entries[name] = {'kind': 'symlink', 'target': target}
                info = zipfile.ZipInfo(name)
                info.create_system = 3
                info.external_attr = (stat.S_IFLNK | 0o777) << 16
                archive.writestr(info, target)
            elif path.is_file():
                content = path.read_bytes()
                entries[name] = {'kind': 'file', 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest(), 'mtime_ns': path.stat().st_mtime_ns}
                archive.writestr(name, content)
    save_json(prefix.with_suffix('.json'), {'root': str(root), 'captured_at': now(), 'entries': entries})
    return entries

action, subject, ordinal = sys.argv[1:4]
index = int(ordinal)
root = RUN / 'subjects' / subject
lane = {'subject-01': 'writer', 'subject-02': 'no_authorization_control', 'subject-03': 'automatic_selection_control', 'subject-04': 'fresh_reader'}[subject]
turn_dir = EVIDENCE / 'turns' / subject / f'{index:02d}'
if action == 'prepare':
    if turn_dir.exists():
        raise SystemExit('checkpoint already allocated; do not overwrite')
    turn_dir.mkdir(parents=True)
    request = REQUESTS['fresh_reader'] if lane == 'fresh_reader' else REQUESTS[lane][index-1]['request']
    delivered = request
    transport = 'direct task message'
    if subject == 'subject-01' and 13 <= index <= 24:
        current_input = root / 'current-context-request.txt'
        current_input.write_text(request)
        question = request.strip().splitlines()[-1]
        delivered = f'The current request uses the attached historical catalog batch at {current_input}. Read that file as read-only context for this turn. {question}'
        transport = 'read-only current-turn fixture file; exact original corpus retained'
    save_json(turn_dir / 'request.json', {'subject': subject, 'ordinal': index, 'prepared_at': now(), 'frozen_request': request, 'delivered_task_message': delivered, 'transport': transport, 'frozen_request_bytes': len(request.encode()), 'frozen_request_sha256': hashlib.sha256(request.encode()).hexdigest()})
    snapshot(root, turn_dir / 'before')
    run = json.loads((EVIDENCE / 'run.json').read_text())
    if run['started_at'] is None:
        run['started_at'] = now()
    elapsed = datetime.datetime.now(datetime.timezone.utc) - datetime.datetime.fromisoformat(run['started_at'])
    if elapsed.total_seconds() > run['max_minutes'] * 60:
        raise SystemExit('execution time ceiling reached')
    save_json(EVIDENCE / 'run.json', run)
    print(json.dumps({'turn_path': str(turn_dir), 'consumer_root': str(root), 'delivered_task_message': delivered, 'transport': transport}, ensure_ascii=False))
elif action == 'finish':
    response = turn_dir / 'response.txt'
    if not response.is_file():
        raise SystemExit('public response capture missing')
    after = snapshot(root, turn_dir / 'after')
    before = json.loads((turn_dir / 'before.json').read_text())['entries']
    def identity(x):
        return {k:v for k,v in x.items() if k != 'mtime_ns'}
    changed = [p for p in sorted(before.keys() | after.keys()) if identity(before.get(p, {})) != identity(after.get(p, {}))]
    save_json(turn_dir / 'completion.json', {'completed_at': now(), 'response_bytes': response.stat().st_size, 'response_sha256': hashlib.sha256(response.read_bytes()).hexdigest(), 'net_changed_paths': changed, 'metadata_changed_paths': [p for p in sorted(before.keys() & after.keys()) if before[p].get('mtime_ns') != after[p].get('mtime_ns')], 'trace_order_observation': 'unavailable; snapshots are turn-boundary observations'})
    run = json.loads((EVIDENCE / 'run.json').read_text())
    key = f'{subject}:{index}'
    if key in run['completed_turns']:
        raise SystemExit('turn already completed')
    run['completed_turns'].append(key)
    run['status'] = 'running'
    save_json(EVIDENCE / 'run.json', run)
    print(json.dumps({'completed': key, 'net_changed_paths': changed, 'completed_subject_turns': len(run['completed_turns'])}))
else:
    raise SystemExit('unknown action')
