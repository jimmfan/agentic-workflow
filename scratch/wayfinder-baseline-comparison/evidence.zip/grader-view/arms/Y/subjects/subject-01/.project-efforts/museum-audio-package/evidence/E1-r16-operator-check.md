# E1 — r16 operator check report

Source: The user's pasted operator-check report and subsequent revision correction in this conversation.

Scope: The user corrected the report's revision from r17 to r16; the kiosk profile remains museum-kiosk-v3.

## Observation

The corrected r16 report has `manifest_count=24` and `playback=not_tested`.
The user's correction removes the apparent conflict with the saved [local r17 manifest](../../../observations/r17-manifest.json), which contains 23 clips and checksum_count 23.

Limitations: This is user-reported evidence, without an operator manifest, clip list, or counting method, and has not been independently rerun. It establishes no r17 count or playback result. Playback was not tested for the reported r16 check; r17 visitor-player acceptance remains pending.
