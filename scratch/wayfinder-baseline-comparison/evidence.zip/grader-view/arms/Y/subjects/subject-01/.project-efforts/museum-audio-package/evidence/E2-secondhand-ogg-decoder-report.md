# E2 — Secondhand OGG decoder report

Source: The user relayed a volunteer's report that the kiosk has no OGG decoder, then explicitly clarified that the report is secondhand and must not be treated as a fresh device test.

Scope: The kiosk discussed for the museum-kiosk-v3 public sample. The report does not identify a directly inspected device build or a fresh r17 test.

## Observation

The volunteer reportedly says the kiosk has no OGG decoder. This is a relayed capability claim, not an observed decoder inventory or playback result.

Limitations: There is no direct device-test evidence, decoder inventory, test method, or playback observation in this report. It does not establish a fresh device capability conclusion or visitor-player acceptance for r17. The existing [format-support source](../../../docs/player-format-support.txt) lists FLAC and WAV; it is also not an acceptance result. The user's chosen public format remains FLAC, with archival originals WAV; OGG was discussed but not selected.
