# Museum audio package

## Objective

Prepare the offline museum audio sample and obtain visitor-player acceptance before final release.

## Scope

Local packaging guidance and later museum-kiosk-v3 visitor-player acceptance for revision r17.
The user chose FLAC for the public sample; archival originals remain WAV.
Effort-state maintenance and the requested write to [docs/export-plan.md](../../docs/export-plan.md) are authorized. Audio exports, bundle assembly, checksum generation, other product-file writes, and final release are outside this document-write request.

## Ready work

Use the delivered [packaging instructions](../../docs/export-plan.md) to prepare the October 12 visitor-player handoff in conversation. Local document preparation and delivery are complete; no playback result has been supplied. Actual audio export and bundle assembly have not been authorized or performed and require the real WAV inputs.

## Blockers

Final release remains blocked by pending r17 visitor-player acceptance on museum-kiosk-v3 and is explicitly not approved by the user. Acceptance of playback uncertainty applies only to drafting packaging instructions. The device-availability blocker is cleared and local document delivery is complete; the manifest-count discrepancy remains resolved.
Audio export and bundle assembly remain outside the current action authorization; their execution also requires actual WAV source paths, which the manifest does not supply.

## Dependencies

The visitor-player check requires an available museum-kiosk-v3 device and local document delivery. The user will supply its result; a confirmed date does not satisfy visitor-player acceptance.
Final release requires an accurate r17 manifest count; the local manifest and requested inspector establish 23 for the current r17 source. The user's corrected r16 report creates no r17 count conflict.

## Current state

The [local packaging document](../../docs/export-plan.md) is prepared and delivered. It maintains the accepted format choices, local preparation instructions, evidence limits, and visitor-player handoff. No audio exports, cryptographic checksums, or playback results were produced by this document delivery.
The checked local r17 manifest for museum-kiosk-v3 contains 23 listed clips, 23 unique clip IDs, and checksum_count 23.
The requested read-only [bundle inspector](../../checks/inspect_bundle.py), run as `python -B checks/inspect_bundle.py`, returned revision=r17, kiosk_profile=museum-kiosk-v3, manifest_count=23, checksum_count=23, playback=not_tested. It counts the local manifest clips, copies the stored checksum_count, and hard-codes playback=not_tested; it neither hashes audio files nor runs a player.
The [corrected user-reported operator check](evidence/E1-r16-operator-check.md) concerns r16 on museum-kiosk-v3 and reports manifest_count=24, playback=not_tested. The user corrected the revision attribution; this report does not conflict with r17's count or supply r17 acceptance.
The count check does not verify audio-file checksums. The user confirmed the r17 visitor-player check on museum-kiosk-v3 for October 12 and will supply its result. Visitor-player playback acceptance remains pending; no r17 playback result has been reported. The corrected r16 operator report and secondhand decoder report do not supply that result.
The [corrected device availability report](evidence/E3-kiosk-temporary-unavailability.md) concerns temporary unavailability of museum-kiosk-v2. The user states museum-kiosk-v3 is available for the scheduled October 12 r17 visitor-player check, removing the v3 device-availability blocker. This correction is an availability report, not a fresh playback test; acceptance remains pending. The user reports the r17 manifest remains unchanged, so the count remains 23.
The format-support fixture establishes FLAC/WAV support only, not acceptance.
The user reaffirmed FLAC for the public sample, keeping WAV originals for the archive. The public-format blocker is resolved; this choice does not authorize product-file writes or establish visitor-player acceptance.
Authority: The user explicitly accepts unresolved r17 playback risk only for drafting packaging instructions and explicitly withholds final-release approval. The current request separately authorizes docs/export-plan.md. Playback remains unresolved; the scoped acceptance neither satisfies the visitor-player check nor authorizes audio exports or release.
The [secondhand volunteer report](evidence/E2-secondhand-ogg-decoder-report.md) says the kiosk has no OGG decoder. The user explicitly qualifies it as secondhand, not a fresh device test. It supplies no observed decoder or playback result, does not establish r17 acceptance, and does not block the selected FLAC guidance; OGG remains unselected.

## Areas and relationships

The user decides the public format and supplies the visitor-player result.
Local guidance can proceed without treating that external acceptance as complete.

## Key references

- [Delivered packaging instructions](../../docs/export-plan.md)
- [Local manifest](../../observations/r17-manifest.json)
- [Read-only bundle inspector](../../checks/inspect_bundle.py)
- [Corrected r16 operator report and limitations](evidence/E1-r16-operator-check.md)
- [Secondhand OGG decoder report and limitations](evidence/E2-secondhand-ogg-decoder-report.md)
- [Corrected v2/v3 availability report](evidence/E3-kiosk-temporary-unavailability.md)
- [Format support](../../docs/player-format-support.txt)
- [Acceptance criteria](../../docs/acceptance.txt)
