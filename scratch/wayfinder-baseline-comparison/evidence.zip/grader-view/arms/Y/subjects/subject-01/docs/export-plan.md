# Offline audio packaging plan — r17

## Accepted choices and current status

| Item | Accepted scope |
|---|---|
| Revision | r17 |
| Visitor-player target | museum-kiosk-v3 |
| Public sample audio | FLAC |
| Archival originals | WAV; preserve the existing originals |
| Manifest inventory | 23 clips, `clip-001` through `clip-023` |
| Visitor-player check | Confirmed for October 12; the user will supply the result |
| Playback acceptance | Pending; no r17 visitor-player result has been supplied |
| Final release | Not approved |

The user accepts unresolved playback risk only for drafting these packaging instructions. That acceptance does not waive the required visitor-player check or approve final release. Local document delivery is independent of playback acceptance.

This document supplies the local packaging instructions. Audio export, bundle assembly, checksum generation, and visitor-player acceptance have not been performed as part of this document delivery. The current request authorizes this document; other product-file writes require their own action authorization.

## Sources and evidence limits

The [r17 manifest](../observations/r17-manifest.json) lists 23 unique clip IDs with WAV archive format and stores `checksum_count=23`. It does not provide source WAV paths, audio properties, or cryptographic digests.

The previously executed [local inspector](../checks/inspect_bundle.py) returned `revision=r17`, `kiosk_profile=museum-kiosk-v3`, `manifest_count=23`, `checksum_count=23`, and `playback=not_tested`. It counts manifest entries, reads the stored checksum count, and hard-codes playback as untested. It does not inspect audio files, calculate checksums, or run a player.

The [format-support source](player-format-support.txt) lists FLAC and WAV. It supplies no visitor-player acceptance result. The corrected availability report concerns museum-kiosk-v2 being unavailable; the user reports museum-kiosk-v3 available for the scheduled check. Availability also supplies no playback result.

## Proposed offline bundle

Use a local folder such as `museum-audio-r17/`. The following names are proposed output paths, not claims that the files already exist.

| Relative path | Contents |
|---|---|
| `public/clip-001.flac` through `public/clip-023.flac` | One FLAC public export for each manifest clip ID |
| `manifest.json` | Revision, target profile, public format, clip count, and each clip's ID, relative filename, size, and SHA-256 digest |
| `checksums.sha256` | SHA-256 digests for all 23 public audio files |
| `README.txt` | Offline opening instructions, inventory, and playback acceptance status |

Keep the WAV originals in their existing archival location. The public bundle contains copies exported to FLAC; preparing it must not replace, rename, or overwrite the archival originals.

## Local preparation steps

1. **Locate the inputs.** Map every r17 clip ID to its actual WAV original. The source manifest provides IDs and archive format only; the audio assets and their paths have not been supplied in this project. Resolve missing or duplicate mappings before claiming a complete sample.
2. **Inspect each source.** Identify its encoding, sample rate, channel count, and bit depth. Confirm the available FLAC encoder can preserve the source audio without an unintended conversion. If it cannot, resolve that incompatibility before changing the accepted format or fidelity.
3. **Export public copies.** Create one FLAC file per clip in a separate output folder, using the proposed clip-ID filenames or recording any alternative filenames in the bundle manifest. Preserve the source audio properties; do not silently resample, normalize, trim, or overwrite originals.
4. **Reconcile inventory.** Confirm exactly 23 unique public clip IDs and one intended FLAC file for every source-manifest entry. Confirm there are no missing, duplicated, or unrelated clips. Keep bundle revision and target profile as r17 and museum-kiosk-v3.
5. **Validate local files.** Check that each FLAC decodes with a suitable local tool. For lossless verification, compare decoded audio samples with the corresponding source rather than comparing WAV and FLAC container bytes. Record what was actually checked; a local decoding check does not establish visitor-player acceptance.
6. **Generate checksums.** Calculate SHA-256 from the actual 23 exported FLAC files and record the results in the bundle manifest and checksum list. Do not use the source's `checksum_count=23` as a substitute for computing or verifying digests.
7. **Make the package portable.** Use relative file references and include all required public audio locally. Write the offline instructions below into the package README. After copying the complete folder to the intended delivery medium, verify its inventory and audio digests again.
8. **Hand off the sample and instructions.** Identify the revision, target profile, count, public format, and pending acceptance status. Keep local packaging results distinct from the later museum-kiosk-v3 result.

## Offline opening instructions

Copy the complete public bundle to local storage and retain its folder layout. Open the README and use a player that supports FLAC to open files from the local `public/` directory. Follow the manifest's clip order and use its relative filenames; playback must not depend on streaming links or downloading missing audio. Report a missing file, digest mismatch, or decoding problem against the affected clip ID.

These instructions describe how to use the prepared sample. Successful playback on a different local computer does not satisfy the required museum-kiosk-v3 visitor-player acceptance.

## Visitor-player handoff and release gate

The required check is for the actual r17 public sample on museum-kiosk-v3, after local document delivery, with October 12 as the confirmed date. The user will supply its result. Record the exact sample revision, profile, clips and behavior tested, actual playback observations, failures, and acceptance outcome; leave untested behavior explicitly untested.

[Acceptance requirements](acceptance.txt) still require an accurate r17 manifest count and the visitor-player check before final release. The local source count is established as 23. The actual assembled package must agree with that inventory. Playback acceptance remains pending, and final release remains unapproved. Neither the date, reported device availability, format-support notes, nor the user's drafting-only acceptance replaces the required playback evidence.
