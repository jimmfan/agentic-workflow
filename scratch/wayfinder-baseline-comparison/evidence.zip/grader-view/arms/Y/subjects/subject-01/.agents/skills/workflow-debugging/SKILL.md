---
name: workflow-debugging
description: Diagnose an existing unexplained failure through an evidence-driven feedback loop and falsifiable hypotheses. Use for an observable failure, regression, or performance symptom whose cause is unknown; distinguish diagnosis from a fix with separate action authorization.
---

# Systematic debugging workflow

Find the cause before choosing the fix.
Debugging defines causal investigation, not durable continuity.
Run it standalone when the work fits the current session.
Use Wayfinder when consequential investigation must survive session continuation or an agent handoff; resume from its map without creating separate Agent Workflow durable coordination state.

## Establish the investigation

1. Define expected and observed behavior, impact, onset, frequency, and last known good state.
2. Read relevant project diagnostics and system context.
   The workflow supplies no technology-specific commands.
3. Establish which diagnostic actions are authorized.
   Diagnosis-only work uses existing evidence and read-only observations; request action authorization before adding instrumentation or running a mutating check.
4. Gather the smallest useful evidence.
   Redact secrets and record commands and baseline results actually observed.

## Establish the feedback signal

Prefer one safe, repeatable observation that detects the reported symptom and distinguishes before from after.
Minimize the reproducer when feasible without substituting a nearby failure.

Infrastructure, intermittent, or external failures may instead need a bounded log signature, metric, trace, captured request, state comparison, or approved live check.
State the proxy's limitations.
If no reliable signal exists, stop with the evidence needed next.

## Narrow and test

1. Map the path of the failing behavior and locate the earliest divergence.
2. Form 3–5 ranked, falsifiable hypotheses when evidence permits.
   For each, state confirming and refuting evidence plus the safest discriminating test.
3. Instrument only boundaries covered by action authorization that distinguish a named hypothesis.
   Tag temporary instrumentation, change one variable at a time, and avoid broad sensitive logging.
4. Run only diagnostics documented by the project or available in the current repository environment, and update rankings from observed results; do not stack speculative changes.
5. Identify the root cause or bound the uncertainty and name the next useful check.

## Fix and verify

For diagnosis-only work, report the evidence chain, root cause or bounded uncertainty, rejected hypotheses, cleanup, and next action without editing or implying fix approval.

When action authorization covers a fix, turn the minimized reproducer into a regression check at the real failure seam when possible.
Apply the smallest causal fix, remove temporary diagnostics, and invoke Verification on the original symptom or honest proxy plus proportionate regressions.
A vanished symptom without causal evidence is a mitigation, not a proven root cause.
Do not duplicate Code Review already performed by `implement`.

Inside Wayfinder, reconcile state only within current action authorization and only for consequential evidence, conclusions, conditions blocking particular work, and next work; the selected map remains the durable coordination summary.

Within that authorized scope, when user-provided or tool-observed evidence materially supports or changes the diagnosis, selected fix, blockers, dependencies, or verification boundary, reconcile the affected Wayfinder state through its contract before further work relies on the finding or before final response or handoff.
Once those state writes are authorized, do not wait for a separate persistence request.
