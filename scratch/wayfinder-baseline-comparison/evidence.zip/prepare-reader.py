from pathlib import Path
import datetime
import hashlib
import json
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
label = sys.argv[1]
assert label in ('X', 'Y')
arm = ROOT / 'live' / label
evidence = arm / 'evidence'
source = arm / 'subjects/subject-01'
target = arm / 'subjects/subject-04'
assert not target.exists()
last = evidence / 'turns/subject-01/31'
assert (last / 'completion.json').is_file()

def entries(root):
    result = {}
    for path in sorted(root.rglob('*')):
        name = str(path.relative_to(root))
        if path.is_symlink():
            result[name] = {'kind': 'symlink', 'target': str(path.readlink())}
        elif path.is_file():
            body = path.read_bytes()
            result[name] = {'kind': 'file', 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
    return result

expected = json.loads((last / 'after.json').read_text())['entries']
expected = {name: {k: v for k, v in entry.items() if k != 'mtime_ns'} for name, entry in expected.items()}
assert entries(source) == expected, 'writer changed after its captured endpoint'
shutil.copytree(source, target, symlinks=True)
(target / 'current-context-request.txt').unlink(missing_ok=True)
expected.pop('current-context-request.txt', None)
actual = entries(target)
mismatches = [name for name in sorted(expected.keys() | actual.keys()) if expected.get(name) != actual.get(name)]
assert not mismatches, mismatches
prior = json.loads((ROOT / 'prior/evidence/session-envelopes.json').read_text())
old_root = '/workspace/scratch/7c461001dda8/wayfinder-work-pilot-20261003/subjects/subject-04'
task = prior['subject-04']['initial_task'].replace(old_root, str(target))
(evidence / 'fresh-reader-envelope.txt').write_text(task + '\n')
session_envelopes = {'subject-01': {'initial_task': (evidence / 'session-envelope.txt').read_text().rstrip('\n')}, 'subject-04': {'initial_task': task, 'followups': prior['subject-04']['followups']}}
(evidence / 'session-envelopes.json').write_text(json.dumps(session_envelopes, indent=2) + '\n')
report = {'copied_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_checkpoint': 'turns/subject-01/31/after.json and after.zip', 'target_root': str(target), 'excluded': ['current-context-request.txt'], 'received': 'Saved consumer project only, including relative references, installed framework, task-local catalog and saved effort records. No chat transcript, final chat handoff, controller summaries, rubric, future prompts or host/account resources were copied.', 'matched_entry_count': len(actual), 'mismatches': mismatches}
(evidence / 'fresh-reader-input.json').write_text(json.dumps(report, indent=2) + '\n')
subprocess.run([sys.executable, str(evidence / 'checkpoint.py'), 'prepare', 'subject-04', '1'], check=True)
print(task)
