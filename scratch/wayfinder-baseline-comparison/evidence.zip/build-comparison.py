from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent / 'wayfinder-comparison-publication/scratch/wayfinder-baseline-comparison'
grades = json.loads((ROOT / 'grader-view/grading/grades.json').read_text())
key = json.loads((ROOT / 'arm-key.json').read_text())
assert key['written_only_after_grader_returned']
assert len(grades['turns']) == 64
lookup = {(t['arm'], t['subject'], t['ordinal']): t for t in grades['turns']}
roles = {v['role']: label for label, v in key['arms'].items()}
primary = [1, 3, 5, 8, 9, 11, 12, 25, 26, 29, 31, 'reader']
dimensions = {'P': 'preservation', 'C': 'correctness', 'A': 'authorization', 'D': 'dependencies', 'K': 'continuation'}
rows = []
for number in primary:
    subject, ordinal = ('subject-04', 1) if number == 'reader' else ('subject-01', number)
    row = {'turn': 'reader' if number == 'reader' else f'W{number}', 'subject': subject, 'ordinal': ordinal}
    for role in ['B', 'R']:
        label = roles[role]
        turn = lookup[label, subject, ordinal]
        row[role] = {'label': label, 'endpoint_verdict': turn['endpoint_verdict'], 'dimensions': {short: turn['outcomes'][long]['verdict'] for short, long in dimensions.items()}, 'evidence': f'evidence.zip::live/{label}/evidence/turns/{subject}/{ordinal:02d}/'}
    rows.append(row)
candidate = [row['turn'] for row in rows if row['B']['endpoint_verdict'] == 'FAIL' and row['R']['endpoint_verdict'] == 'PASS']
assert candidate == ['W31']
assert not any(t['endpoint_verdict'] != 'PASS' for t in grades['turns'] if t['arm'] == roles['R'])
prior_grades = json.loads((ROOT / 'prior/evidence/grading/grades.json').read_text())
assert all(t['observed_endpoint_verdict'] == 'PASS' for t in prior_grades['per_turn'] if t['subject'] in ['subject-01', 'subject-04'])

# Preserve grader files unchanged; record factual controller clarifications apart.
prior_envelopes = json.loads((ROOT / 'prior/evidence/session-envelopes.json').read_text())
checks = []
for label in ['X', 'Y']:
    for subject, filename in [('subject-01', 'session-envelope.txt'), ('subject-04', 'fresh-reader-envelope.txt')]:
        original = prior_envelopes[subject]['initial_task']
        old_root = f'/workspace/scratch/7c461001dda8/wayfinder-work-pilot-20261003/subjects/{subject}'
        new_root = str(ROOT / 'live' / label / 'subjects' / subject)
        current = (ROOT / 'live' / label / 'evidence' / filename).read_text().rstrip('\n')
        assert current == original.replace(old_root, new_root)
        checks.append({'arm': label, 'subject': subject, 'matches_prior_actual_live_envelope_except_root': True})
clarifications = [
    {'location': 'grades.json global_checks G06 reason', 'clarification': '456275 bytes is the total across twelve historical batches per writer, not the size of each batch. Both audit.json outputs report that exact total. Raw independent grading is unchanged.'},
    {'location': 'grades.json infrastructure_and_coverage exposure', 'clarification': 'Normal envelopes exactly reuse the prior actual live session-envelopes.json wording apart from consumer roots. The older frozen-requests.json planning envelope already differed from that actual prior live envelope. No new normal-envelope wording change occurred.', 'verified_envelope_checks': checks},
]
(ROOT / 'grader-clarifications.json').write_text(json.dumps(clarifications, indent=2) + '\n')

comparison = {'schema_version': 1, 'comparison': 'pre-#56 versus current main', 'question': 'Does the frozen 31-turn scenario distinguish the pre-#56 framework from current main?', 'arms': key['arms'], 'primary_table': rows, 'dimension_legend': dimensions, 'decision_rule_outcome': {'candidate_evidence_turns': candidate, 'scope': 'Exact public resume prompt at delivery only; both arms preserve incident-related meaning and files-only continuation.', 'H_trigger_met': False, 'H_status': 'unexecuted; B did not pass every primary turn', 'R_failures_vs_prior_PASS': [], 'inference_limit': 'One trajectory per arm; not reliability, exclusive causality, or attribution to PR #56 alone.'}, 'global_checks': grades['global_checks'], 'controller_clarifications': clarifications, 'unexecuted': [{'arm': arm, 'turns': [f'W{i}' for i in range(1, 32)], 'reason': 'Conditional H trigger not met'} for arm in ['B-H', 'R-H']], 'controls': {'N': 'skipped', 'A': 'skipped', 'reason': 'Prior R endpoint controls passed; they do not test this maintenance comparison.'}, 'independent_grades_sha256': hashlib.sha256((ROOT / 'grader-view/grading/grades.json').read_bytes()).hexdigest()}
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'comparison.json').write_text(json.dumps(comparison, indent=2, ensure_ascii=False) + '\n')

# Exhaustive project-file differences and literal public responses, including
# harmless representation/style differences; installed revision content differs
# intentionally and remains fully available in the snapshots.
inventory = []
framework_prefixes = ('.agent-workflow/', '.agents/', '.claude/')
for subject, ordinals in [('subject-01', range(1, 32)), ('subject-04', [1])]:
    for ordinal in ordinals:
        pair = {}
        archives = {}
        for role in ['B', 'R']:
            label = roles[role]
            lane = ROOT / 'live' / label / f'evidence/turns/{subject}/{ordinal:02d}'
            captures = json.loads((lane / 'after.json').read_text())['entries']
            pair[role] = {'label': label, 'request_sha256': json.loads((lane / 'request.json').read_text())['frozen_request_sha256'], 'response': (lane / 'response.txt').read_text(), 'response_sha256': hashlib.sha256((lane / 'response.txt').read_bytes()).hexdigest(), 'snapshot': f'evidence.zip::live/{label}/evidence/turns/{subject}/{ordinal:02d}/after.zip', 'entries': captures}
            archives[role] = zipfile.ZipFile(lane / 'after.zip')
        assert pair['B']['request_sha256'] == pair['R']['request_sha256']
        files = []
        names = sorted(pair['B']['entries'].keys() | pair['R']['entries'].keys())
        for name in names:
            if name.startswith(framework_prefixes) or name in ['AGENTS.md', 'task-skill-catalog.json']:
                continue
            identities = {role: {k: v for k, v in pair[role]['entries'].get(name, {}).items() if k != 'mtime_ns'} for role in ['B', 'R']}
            if identities['B'] == identities['R']:
                continue
            files.append({'path': name, **{role: {'identity': identities[role], 'saved_file_text': archives[role].read(name).decode() if name in pair[role]['entries'] else None} for role in ['B', 'R']}})
        for archive in archives.values():
            archive.close()
        for role in ['B', 'R']:
            pair[role].pop('entries')
        inventory.append({'subject': subject, 'ordinal': ordinal, 'primary': ordinal in primary if subject == 'subject-01' else True, 'paired_frozen_request_hash_equal': True, 'public_responses': pair, 'project_file_differences': files})
(OUT / 'artifact-differences.json').write_text(json.dumps({'scope': 'All 32 paired endpoints. Literal response differences and every project-file byte/path difference, excluding installed framework/catalog differences by design. This inventory assigns no semantic failure.', 'endpoints': inventory}, indent=2, ensure_ascii=False) + '\n')
table = ['| Primary turn | B P/A/D | R P/A/D | B K | R K |', '|---|---|---|---|---|']
for row in rows:
    table.append('| ' + row['turn'] + ' | ' + ' | '.join('/'.join(row[role]['dimensions'][dim] for dim in ['P', 'A', 'D']) for role in ['B', 'R']) + ' | ' + row['B']['dimensions']['K'] + ' | ' + row['R']['dimensions']['K'] + ' |')
(ROOT / 'primary-table.md').write_text('\n'.join(table) + '\n')
print(json.dumps({'primary_rows': len(rows), 'candidate_turns': candidate, 'paired_endpoint_inventory': len(inventory), 'R_variance_failures': []}))
