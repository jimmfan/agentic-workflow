from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
OUT = Path(sys.argv[1]).resolve()
OUT.mkdir(parents=True, exist_ok=True)
for label in ['X', 'Y', 'X-H', 'Y-H']:
    evidence = ROOT / 'live' / label / 'evidence'
    if not evidence.is_dir():
        continue
    for subject, role, envelope_name in [('subject-01', 'writer', 'session-envelope.txt'), ('subject-04', 'reader', 'fresh-reader-envelope.txt')]:
        turns = evidence / 'turns' / subject
        if not turns.is_dir():
            continue
        blocks = [f'Public transcript: {label}-{role}\nPublic requests and final responses only; complete tool traces are unavailable.\n', 'SESSION ENVELOPE\n' + (evidence / envelope_name).read_text()]
        for lane in sorted(turns.iterdir()):
            request = json.loads((lane / 'request.json').read_text())
            blocks.append(f'\nTURN {request["ordinal"]}\nFROZEN USER REQUEST\n' + request['frozen_request'])
            blocks.append('\nDELIVERY TRANSPORT\n' + request['transport'] + '\nDELIVERED TASK MESSAGE\n' + request['delivered_task_message'])
            if (lane / 'completion.json').is_file():
                response = (lane / 'response.txt').read_bytes()
                completion = json.loads((lane / 'completion.json').read_text())
                assert hashlib.sha256(response).hexdigest() == completion['response_sha256']
                blocks.append('\nPUBLIC FINAL RESPONSE\n' + response.decode())
            else:
                blocks.append('\nUNEXECUTED: no completed response captured.\n')
        name = f'{label}-{role}.txt'
        (OUT / name).write_text('\n'.join(blocks), encoding='utf-8')
        print(name)
