Wayfinder Work Mode diagnostic evidence — 2026-10-03

This directory contains the controller-captured evidence for the approved preliminary current-main diagnostic. It is not a native Codex/Claude run, historical comparison, contract-split test, or repository patch.

Navigation

- run.json: approval scope, session identities, settings surfaced/unknown, turn count, limits and recorded adjustments.
- approved-protocol.txt: frozen proposal approved by the user. Its initial PREPARED status is historical; run.json and the final report contain execution status.
- preparation-freeze.json: pinned source revision, input/corpus hashes and initial artifact freeze.
- frozen-requests.json: exact frozen user-style request sequence, including full corpus text.
- session-envelopes.json: actual initial subject task envelopes, separate from the user-style request text.
- public-transcript.txt: readable aggregation of actual task messages and returned public responses; full corpus bytes remain in the per-turn captures.
- turns/<subject>/<ordinal>/request.json: frozen request, delivered current-request message, transport, timestamps, hashes.
- turns/<subject>/<ordinal>/response.txt: exact controller-captured public final response.
- turns/<subject>/<ordinal>/before.json and after.json: whole-consumer file/symlink inventories.
- turns/<subject>/<ordinal>/before.zip and after.zip: saved bytes at each captured boundary. Snapshot ZIP members are relative to that subject consumer.
- turns/<subject>/<ordinal>/completion.json: response hash and independently computed net changes. Equality is not proof of no transient writes.
- audit.py and audit.json: reproducible snapshot hash/input/continuity audit; no hidden subject trace claims.
- fresh-reader-input.json: writer-to-reader copy provenance and excluded transient input; no chat handoff was copied.
- controller-observations.txt: controller compaction, explicitly separate from unobserved subject compaction.
- source-final-verification.json: clean source checkout, pinned HEAD/VERSION, and remote main at final verification.
- grader-task.txt and grading-notes.txt: evaluator scope and expected meaning, never supplied to subjects.
- grading/: independent grading outputs and captured final response.

Subject identities

subject-01: 31-turn writer, including twelve staged context-growth inputs.
subject-02: two-turn no-authorization control.
subject-03: two-turn automatic-selection-during-authorized-work control.
subject-04: one-turn files-only fresh reader.

The consumers are synthetic museum audio projects. Account files, credentials and the source checkout are not part of this evidence package.

Evidence limits

No complete child tool trace, exact child token/context occupancy, subject compaction event, hard filesystem isolation or inherited model/effort identifier was exposed. Subject command-execution and procedural-order claims are not established by public responses. Large inputs were made available as read-only current-turn files and questions sent directly; complete corpus consumption is unobserved. Task-local skill exposure was manual. All broader causal, reliability, native-host and variant conclusions remain outside this diagnostic.
