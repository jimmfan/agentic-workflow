# E1 — Secondhand kiosk OGG decoder report

Source: The user relayed a volunteer's report in this effort's conversation: "The volunteer now reports the kiosk has no OGG decoder." On 2026-10-03 the user explicitly qualified it as secondhand and instructed that it must not be treated as a fresh device test.

Scope: The kiosk targeted by the museum-audio-package effort, museum-kiosk-v3. The exact device identity, configuration, observation method, and observation date were not supplied. Recorded on 2026-10-03.

## Observation

The volunteer reportedly says the kiosk has no OGG decoder.

Limitations: This is a secondhand report, not fresh device verification. No direct device-test evidence was supplied, and no device test was performed while recording it. The report does not establish r17 visitor-player acceptance, FLAC playback verification, or decoder availability beyond the reported kiosk configuration.
