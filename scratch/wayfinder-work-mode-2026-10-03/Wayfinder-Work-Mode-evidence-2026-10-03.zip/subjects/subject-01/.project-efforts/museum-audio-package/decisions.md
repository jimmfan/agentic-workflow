# Current decisions

## D1 — Playback-risk acceptance for instruction drafting

Authority: The user explicitly accepted this boundary in the effort conversation on 2026-10-03: "I accept the unresolved playback risk only for drafting the packaging instructions; I do not approve final release."

Choice and boundary: Accept unresolved r17 playback risk only for drafting packaging instructions. Final release is excluded and is not approved by this acceptance.

Consequences: Playback remains unresolved and the required visitor-player acceptance remains outstanding. [Local document delivery is already independent of visitor-player acceptance](../../docs/acceptance.txt), so this acceptance adds no previously blocked drafting scope. It does not restore device availability, satisfy release acceptance, or itself authorize product-file changes. Product-file writing and final release require separate action authorization.
