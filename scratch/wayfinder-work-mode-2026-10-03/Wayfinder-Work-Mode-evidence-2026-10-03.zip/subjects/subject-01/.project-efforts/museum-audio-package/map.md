# Museum audio package

## Objective

Prepare the offline museum audio sample and obtain visitor-player acceptance before final release.

## Scope

Local packaging guidance and later museum-kiosk-v3 visitor-player acceptance for revision r17.
Public FLAC or WAV is supported; archival originals must remain WAV.
The user authorized effort-state maintenance and writing docs/export-plan.md on 2026-10-03. That document is delivered; audio exports, other product-file changes, external actions, and final release are outside this document-writing authorization.

## Ready work

The [local packaging instructions](../../docs/export-plan.md) are delivered. Effort-state maintenance and read-only local inspection can continue; no additional product scope is authorized.
Visitor-result interpretation waits for the user to supply the required result.

## Blockers

Final release awaits the user's visitor-player acceptance result for r17 on museum-kiosk-v3.
Final release remains unapproved; the drafting-only playback-risk acceptance does not waive that acceptance requirement or approve release.

## Dependencies

The public format choice is committed.
The user confirmed on 2026-10-03 that the r17 visitor-player check on museum-kiosk-v3 is scheduled for 2026-10-12 and that the user will supply its result.
The visitor-player check is required after local document delivery; that prerequisite is fulfilled by the [delivered packaging instructions](../../docs/export-plan.md). The confirmed check date does not establish playback acceptance.
Execution also requires the target kiosk to be available. In the [corrected availability report](evidence/E2-device-unavailable.md), the user identifies museum-kiosk-v2 as unavailable and museum-kiosk-v3 as available for the scheduled check. The v2 outage does not block r17's v3 check; this availability report supplies no playback acceptance result.
Final release requires an accurate r17 manifest count; the inspected local r17 manifest establishes 23 entries. The corrected operator report concerns r16 and does not conflict with that r17 count.

## Current state

The user reports the r17 manifest remains unchanged. The read-only local inspection on 2026-10-03 confirms 23 clip entries for museum-kiosk-v3, with declared checksum_count 23.
The inspection script counts clip entries and copies the declared checksum_count; it does not verify checksums or perform playback, and its playback=not_tested output is a constant.
The user clarified on 2026-10-03 that the reported operator output (manifest_count=24, playback=not_tested) was from r16, with museum-kiosk-v3 unchanged. This user-reported r16 result is excluded from r17 count and visitor-player acceptance evidence; there is no remaining count conflict from that report.
Visitor-player acceptance for r17 remains pending.
The user's [drafting-only playback-risk acceptance](decisions.md#d1--playback-risk-acceptance-for-instruction-drafting) leaves that question unresolved and excludes final-release approval. The document write was authorized separately.
The user committed and reaffirmed FLAC for the public sample on 2026-10-03, keeping WAV originals for the archive.
The user's [secondhand volunteer report](evidence/E1-ogg-decoder-report.md) says the kiosk has no OGG decoder. Its device identity, configuration, method, and observation date are unspecified; it is not a fresh device test or visitor-player acceptance result. OGG remains unselected, and this report does not block FLAC preparation guidance.
The packaging document was delivered on 2026-10-03 with the accepted formats, 23-clip inventory, source-file mapping and checksum procedures, local inspection limits, and visitor-player handoff. Document delivery is complete; it supplies no evidence that audio exports or visitor-player acceptance have been performed.

## Areas and relationships

The user decides the public format and supplies the visitor-player result.
The packaging document maintains the local instructions; the effort map maintains the outstanding check and release boundary. Local document delivery does not complete visitor-player acceptance.

## Key references

- [Manifest](../../observations/r17-manifest.json)
- [Format support](../../docs/player-format-support.txt)
- [Acceptance criteria](../../docs/acceptance.txt)
- [Delivered packaging instructions](../../docs/export-plan.md)
- [Read-only local inspection](../../checks/inspect_bundle.py)
- [Secondhand OGG decoder report](evidence/E1-ogg-decoder-report.md)
- [Corrected kiosk availability report](evidence/E2-device-unavailable.md)
- [Drafting-only playback-risk acceptance](decisions.md#d1--playback-risk-acceptance-for-instruction-drafting)
