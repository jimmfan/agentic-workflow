# Offline audio packaging instructions — r17

These instructions prepare the local offline sample for museum-kiosk-v3. Local preparation and document delivery can precede visitor-player acceptance. This document does not certify an exported audio package or approve final release.

## Accepted choices and inventory

| Item | Accepted value |
| --- | --- |
| Revision | r17 |
| Target player | museum-kiosk-v3 |
| Public clips | FLAC |
| Archival originals | WAV, preserved unchanged |
| Source inventory | 23 unique clip IDs: clip-001 through clip-023 |

Use the [r17 source manifest](../observations/r17-manifest.json) as the inventory. Its declared `checksum_count` is 23; it does not contain actual checksum values or audio-file paths. The [format-support note](player-format-support.txt) lists FLAC and WAV as supported, but supplies no visitor-player acceptance result.

## Local packaging steps

1. **Resolve the source files.** Match every manifest clip ID to its existing original WAV file and record that mapping. Obtain any missing source or ambiguous mapping before exporting that clip; do not substitute an unrelated recording or silently omit an ID.
2. **Protect the archive.** Keep the WAV originals separate from the public staging folder. Leave their filenames and audio bytes unchanged; make public derivatives from copies without replacing or resaving the originals.
3. **Export public copies as FLAC.** Use a lossless FLAC encoder profile that preserves the source sample rate, bit depth, and channel count.
4. **Keep the ID association explicit.** A suggested staging layout is `r17/public/clip-001.flac` through `r17/public/clip-023.flac`. If an established local naming convention differs, retain a clear inventory mapping from each source clip ID to its public filename.
5. **Create the package inventory.** Record r17, museum-kiosk-v3, each clip ID, its public relative path, and the SHA-256 computed from the actual exported FLAC file. The current manifest's declared checksum count is not a substitute for hashing those files. Keep this exported inventory alongside the public files; preserve the source manifest as the input reference.
6. **Audit the local package.** Confirm exactly one public FLAC exists for each of the 23 IDs, with no missing or duplicate IDs. Confirm the inventory resolves to the actual local files and its hashes match their bytes. Preserve the separate WAV archive, and include this document with the handoff so the public assets and their inventory can be used offline.

The staging paths above are instructions, not a claim that those audio files already exist or were exported during document preparation.

## Local inspection and its limits

From the repository root, run:

```sh
python checks/inspect_bundle.py
```

For the inspected r17 source, the expected metadata output is:

```json
{
  "revision": "r17",
  "kiosk_profile": "museum-kiosk-v3",
  "manifest_count": 23,
  "checksum_count": 23,
  "playback": "not_tested"
}
```

The script counts manifest entries and copies the declared checksum count. It does not verify audio-file existence, actual checksums, FLAC decoding, or device playback. Its `playback=not_tested` value is a constant, not an observed visitor-player result. Compare its inventory count with the actual prepared package; retain any discrepancy for resolution before release.

## Visitor-player handoff and release

As of document delivery on 2026-10-03, the required r17 visitor-player acceptance has not happened. The check is confirmed for **October 12, 2026**, after local document delivery, and the user will supply its result. The user reports museum-kiosk-v3 is available; the corrected unavailability report concerns museum-kiosk-v2 and does not block this target.

Use the actual prepared offline sample for the museum-kiosk-v3 check. Record the tested revision, player profile, public format, package inventory count, playback observations, outcome, and any untested parts or limitations. Local metadata output, reported availability, and a simulated playback result do not satisfy visitor-player acceptance.

The user's acceptance of unresolved playback risk applies only to drafting these instructions. Playback remains unresolved, and **final release is not approved**. Final release requires the accurate r17 inventory and the required visitor-player acceptance under the [acceptance criteria](acceptance.txt), plus separate authorization to release.
