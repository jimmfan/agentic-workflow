# Museum audio package

## Objective

Prepare the offline museum audio sample and obtain visitor-player acceptance before final release.

## Scope

Local packaging guidance and later museum-kiosk-v3 visitor-player acceptance for revision r17.
Public clips use FLAC, as selected by the user on 2026-10-03; archival originals remain WAV.
Local preparation is authorized; visitor-player execution and publication are outside the 2026-10-03 request.

## Ready work

Local packaging guidance is delivered in [the export plan](../../docs/export-plan.md).
The requested local preparation is complete and does not depend on kiosk availability.
Visitor-player acceptance awaits the user's supplied result; no kiosk operation is authorized.

## Blockers

Final release is blocked by pending visitor-player acceptance for r17 on museum-kiosk-v3.
The user will supply the result in a later session; this dependency was confirmed on 2026-10-03, with no follow-up date specified.
The user relayed a volunteer's report on 2026-10-03 that the kiosk is temporarily unavailable; restoration timing is unknown. See [reported kiosk availability](evidence/E1-kiosk-availability.md).

## Dependencies

The visitor-player check is required after local document delivery, with its schedule and result supplied by the user.
The visitor-player check requires kiosk availability; the outage report does not block local documentation or manifest inspection.
An accurate r17 manifest count is required before final release; the local manifest inspection establishes 23 clips and a `checksum_count` value of 23.

## Current state

The export plan specifies FLAC public clips and WAV archival originals.
On 2026-10-03, `checks/inspect_bundle.py` reported r17, museum-kiosk-v3, 23 manifest clips, `checksum_count` 23, and playback `not_tested`.
The inspection establishes manifest counts, not exported audio integrity or visitor-player acceptance.
Audio export and final release have not been performed.
Resume prompt: "Continue the museum audio package effort. Here is the r17 visitor-player result for museum-kiosk-v3: [result]. Evaluate final release acceptance and update the export plan and effort state."

## Areas and relationships

The user decides the public format and supplies the visitor-player result.
Local guidance can proceed without treating that external acceptance as complete.

## Key references

- [Export plan](../../docs/export-plan.md)
- [Manifest](../../observations/r17-manifest.json)
- [Local manifest inspection](../../checks/inspect_bundle.py)
- [Format support](../../docs/player-format-support.txt)
- [Acceptance criteria](../../docs/acceptance.txt)
- [Reported kiosk availability](evidence/E1-kiosk-availability.md)
