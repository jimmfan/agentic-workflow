# Offline audio packaging plan

Revision: r17. Visitor-player profile: museum-kiosk-v3.

## Export formats

The user selected FLAC public clips on 2026-10-03. Archival originals remain WAV.
Export public clips as FLAC while retaining the WAV archival originals and the
clip identifiers from the [r17 manifest](../observations/r17-manifest.json).
The [format-support evidence](player-format-support.txt) reports support for
FLAC and WAV on museum-kiosk-v3; it does not establish visitor-player acceptance.

## Local preparation

The r17 manifest lists 23 clips, all with WAV archival format, and a checksum
count of 23. Running `python checks/inspect_bundle.py` on 2026-10-03 confirmed
those counts and reported playback as `not_tested`. This check establishes the
manifest count, not the contents or checksums of exported audio files.

This document is ready for local delivery independently of visitor-player
acceptance. It specifies the export plan; audio export and final release have
not been performed.

## Final release acceptance

Final release requires an accurate r17 manifest count and a visitor-player
check on museum-kiosk-v3, as specified in the [acceptance criteria](acceptance.txt).
The local manifest count is established as 23. Visitor-player acceptance remains
pending, with its schedule and result supplied by the user in a later session.
Evaluate that result for revision r17 and museum-kiosk-v3 before recording
acceptance or declaring final release ready.

Resume prompt: "Continue the museum audio package effort. Here is the r17
visitor-player result for museum-kiosk-v3: [result]. Evaluate final release
acceptance and update the export plan and effort state."
