# Museum audio package

## Objective

Prepare the offline museum audio sample and obtain visitor-player acceptance before final release.

## Scope

Local packaging guidance and later museum-kiosk-v3 visitor-player acceptance for revision r17.
Public FLAC or WAV is supported; archival originals must remain WAV.

## Ready work

Prepare packaging guidance independently of visitor-player acceptance once the public format choice is committed.

## Blockers

Final release needs visitor-player acceptance and an accurate r17 manifest count.
The public format choice is uncommitted.

## Dependencies

The visitor-player check is required after local document delivery, with its schedule and result supplied by the user.
An accurate r17 manifest count is required before final release.

## Current state

The recorded r17 manifest count is 24 clips for museum-kiosk-v3.
Playback acceptance has not happened.
The public format remains uncommitted; archived originals must remain WAV.

## Areas and relationships

The user decides the public format and supplies the visitor-player result.
Local guidance can proceed without treating that external acceptance as complete.

## Key references

- [Manifest](../../observations/r17-manifest.json)
- [Format support](../../docs/player-format-support.txt)
- [Acceptance criteria](../../docs/acceptance.txt)
