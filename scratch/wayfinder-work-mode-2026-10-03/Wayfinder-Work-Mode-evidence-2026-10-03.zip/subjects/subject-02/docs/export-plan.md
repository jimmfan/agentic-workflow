# Offline audio packaging plan

Public sample format has not yet been chosen.
Archival originals remain WAV.
Visitor-player acceptance remains required for final release.
