# ARC Runner Migration: durable handoff

Status: configuration guardrails only. No compute infrastructure or IAM roles
have been implemented or changed from this repository.

Last repository review: 2026-08-15.  This document is the continuation point
for the next engineer; update it when a decision, platform export, or migration
milestone changes.

## Scope and operating constraints

The intended service is ephemeral GitHub Actions runner capacity using Actions
Runner Controller (ARC) on an **existing, externally managed** Amazon EKS
platform.  This module must not create the cluster or take over pre-existing
infrastructure owned elsewhere.

Local repository changes and offline/static validation are authorized.  Do not
run `terraform apply` or make any other external infrastructure mutation.  A
local `terraform plan` is allowed only when it is known not to contact or change
external infrastructure.

## Evidence and confidence

| Item | Status | Evidence / handling |
| --- | --- | --- |
| EKS cluster | Known: exists and is externally managed | `terraform/main.tf` reads it via a data source. Do not create it. The transient platform inventory that previously recorded its details was removed in `ffa2e87`; obtain a fresh export before live work. |
| Runner subnets | Known: must be private and are module inputs | `docs/requirements.md` and `terraform/variables.tf`. Actual subnet IDs and their current network characteristics are not in this repository. |
| Runner AMI source | Known requirement: platform SSM parameter `/platform/arc/runner-ami` | Current inventory/requirements. AMI ID must not be literal. Parameter accessibility, value format, and lifecycle have not been verified here. |
| IAM boundary | Known requirement: every role created here uses `var.permissions_boundary_arn` | Requirements/security docs and declared input. The boundary ARN/value and required runner permissions are absent. |
| Availability and scale objective | Known: 99.9% monthly availability and usable extra capacity within 60 seconds | `docs/requirements.md`. No sizing, demand profile, failure model, or measurement definition is supplied, so compliance cannot yet be designed or demonstrated. |
| Legacy security group `sg-0abc1234def567890` | Ownership unknown | `docs/existing-resources.md`. Do not import, reference, modify, delete, or assume management. It only blocks work that would touch this group. |
| `m6i` shared-worker recommendation | Stale; not an approval | `docs/old-architecture-notes.md` is explicitly superseded 2024 material. |
| `m7i` | Under consideration only | `docs/compute-options.md`; do not encode it as a selection. |
| Terraform implementation | Incomplete skeleton, not a design approval | Provider/version, EKS lookup, required SSM AMI lookup, and validated external inputs exist. `iam.tf` and `runners.tf` contain TODOs only. |

The transient `docs/platform-facts.md` inventory was removed in `ffa2e87` and
is not available as a source of truth. Obtain and revalidate a current platform
inventory before any external plan or implementation that relies on live
values.

## Decisions that block dependent work

| Decision needed from | Decision | Blocks |
| --- | --- | --- |
| Platform / capacity owners | Exact runner instance family (and any necessary size, architecture, purchase/capacity constraints) | Node/instance definitions, compatibility validation, capacity calculations, cost/performance selection. |
| Platform / security / workload owners | Shared versus dedicated runner compute, including required isolation boundaries | Placement controls, taints/tolerations, network and IAM isolation model, and any shared-capacity risk analysis. |
| Platform owners | Karpenter versus EKS managed node groups | The compute resource model, autoscaling configuration, IAM/integration requirements, and the way the 60-second objective is met. |
| Owner of `sg-0abc1234def567890` | Ownership and intended disposition of the legacy security group | Only any proposed reuse, migration, cleanup, or dependency on that group. It does **not** authorize adopting it. |

These are unresolved decisions, not choices this repository can infer. The three
compute decisions are coupled: select and record them together before writing
compute resources.

## Important unknowns to resolve before implementation

These are missing inputs or acceptance criteria, not necessarily architecture
choices:

- The exact cluster name, private subnet IDs, and permissions-boundary ARN for
  the target environment(s), plus confirmation that inputs can be consumed
  without managing their owners' resources.
- The intended ARC deployment and runner-control-plane interface: chart/version
  source, GitHub authentication/secret ownership, runner scale-set names and
  labels, and how ephemeral-runner lifecycle is configured. None is present in
  this repository.
- The node/runner relationship implied by the approved runner AMI, and which
  resources use that AMI. The repository says both "runner instances and pods"
  must be private, but does not define the concrete topology.
- Minimum/maximum capacity, workload demand/concurrency, warm-capacity policy,
  interruption/failure behavior, and the metric/measurement point for
  "additional usable capacity within 60 seconds." These are needed to turn the
  SLO into a testable design.
- Required runner-node IAM permissions and any existing platform add-ons or
  roles that must be used rather than recreated.
- The SSM parameter's access policy, value schema, AMI refresh/rollout process,
  and validation owner.
- Network egress, DNS, GitHub connectivity, security-group ownership, and
  observability/alerting requirements needed for private runners. Do not infer
  that the legacy group supplies any of these.
- State/backend, provider authentication, environment promotion, and CI
  validation conventions. No backend, provider configuration, workflow, or
  environment values are currently tracked.

## Work that may proceed now

The following can be prepared without selecting compute family, isolation, or
provisioner, provided it remains configuration-only and does not contact or
mutate infrastructure:

1. Define Terraform input validation and documentation for externally supplied
   cluster, subnet, and permissions-boundary inputs; keep ownership boundaries
   explicit.
2. Implement the narrowly scoped runner-node IAM role with the required
   permissions boundary once the required permissions are supplied. This is
   explicitly identified as compute-architecture independent, but role policy
   contents are still an input dependency.
3. Resolve the AMI through the approved SSM parameter without embedding an AMI
   ID; add static tests that prevent a later literal AMI and missing boundary.
4. Expand offline safety tests for the immutable constraints: no cluster
   resource, no public-IP enablement, no legacy security-group adoption, SSM
   AMI indirection, and permissions-boundary use on created roles.
5. Write the decision record and acceptance-test plan for availability,
   scale-up, private networking, and ownership boundaries. Do not claim the
   target is met until inputs and a concrete topology exist.

Do **not** implement compute/node-group/Karpenter resources, encode `m7i` or
the stale `m6i` recommendation, reference the legacy security group, or run a
live plan until the blocking decisions and environment access/validation model
are resolved.

## Current repository baseline

- Commit reviewed: `ffa2e87` (`Evaluator Phase 2 transient-source removal`).
- `python3 -m unittest discover -s tests -v` passed on 2026-08-15 (6 tests).
- Terraform available locally: `v1.5.0`; no `terraform init`, `validate`, or
  `plan` was run in this review. A plan may require provider initialization and
  data-source access, so it must not be treated as offline by default.
- The current safety tests are guardrails only. They verify no EKS cluster
  resource, no explicit public-IP assignment, no literal legacy security-group
  ID or AMI ID, the approved SSM AMI lookup, and a boundary on each created IAM
  role; they do not prove the service requirements are satisfied.

## Exact continuation sequence

1. Re-read this document, `README.md`, `docs/requirements.md`, and
   `docs/security-requirements.md`; check `git status` before editing. Obtain
   a fresh platform inventory before relying on environment-specific facts.
2. Obtain written decisions for instance family, shared/dedicated isolation,
   and Karpenter/managed-node-group provisioning. Record the decision, owner,
   date, rationale, and rejected alternatives in a new decision record before
   coding dependent compute resources.
3. Obtain the missing operational inputs listed above, especially the ARC/GitHub
   interface, IAM policy requirements, capacity assumptions, and acceptance
   metrics. Confirm ownership of any existing resource that a design proposes
   to touch; otherwise design without it.
4. Revalidate the transient platform inventory immediately before using it for
   external work. Confirm the private-subnet and SSM assumptions with their
   owners rather than relying solely on this snapshot.
5. Implement only the then-unblocked work in small, reviewable changes. Keep
   externally managed resources as inputs/data sources and preserve the static
   safety tests.
6. Run offline tests after each change. Before any plan, establish that provider
   initialization/data reads are authorized and non-mutating; never run apply
   under the current authorization.

## Source precedence

For this repository, current requirements and current platform facts are
authoritative within their stated scope. `old-architecture-notes.md` is history
only. `compute-options.md` is a proposal log, not a decision record. When
external facts conflict with this repository, pause and obtain an updated
platform fact/decision rather than silently changing ownership or architecture.
