variable "cluster_name" {
  description = "Name of the externally managed EKS cluster."
  type        = string

  validation {
    condition     = trimspace(var.cluster_name) != ""
    error_message = "cluster_name must not be empty."
  }
}

variable "private_subnet_ids" {
  description = "Private subnet IDs supplied by the platform."
  type        = list(string)

  validation {
    condition = length(var.private_subnet_ids) > 0 && alltrue([
      for subnet_id in var.private_subnet_ids : trimspace(subnet_id) != ""
    ])
    error_message = "private_subnet_ids must contain at least one non-empty subnet ID."
  }
}

variable "permissions_boundary_arn" {
  description = "Required IAM permissions boundary for roles created here."
  type        = string

  validation {
    condition     = trimspace(var.permissions_boundary_arn) != ""
    error_message = "permissions_boundary_arn must not be empty."
  }
}
