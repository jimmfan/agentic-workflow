terraform {
  required_version = ">= 1.5"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
  }
}

# The cluster is owned by the platform repository. This module reads it only.
data "aws_eks_cluster" "existing" {
  name = var.cluster_name
}

# The platform owns both the AMI lifecycle and the parameter. Compute resources
# may consume this value only after the remaining architecture decisions are
# approved; no AMI ID belongs in this module.
data "aws_ssm_parameter" "runner_ami" {
  name = "/platform/arc/runner-ami"
}
