# ARC Runner Migration: durable handoff

Status: the architecture and bounded runner-compute slice are approved for
repository implementation and offline/static validation. No external
infrastructure mutation is authorized. The repository currently has guardrails
and input/data-source scaffolding only; it does not yet define the node role,
launch template, or managed node group.

Last reconciled: 2026-08-15. This is the continuation point for the next
implementation agent. Update it when a decision, benchmark, platform fact, or
migration milestone changes.

## Scope and non-negotiable boundaries

The target service is ephemeral GitHub Actions runner capacity using Actions
Runner Controller (ARC) on an existing, externally managed EKS platform. This
module must not create the cluster or adopt pre-existing infrastructure owned
elsewhere.

Repository changes and offline/static validation are authorized. Do not run
`terraform init`, `terraform plan`, `terraform apply`, or any other operation
that downloads providers, reads live infrastructure, or mutates external
infrastructure. `terraform validate` is allowed only when it is already
possible without either provider download or external contact.

## Reconciled facts and decisions

| Topic | Current conclusion | Evidence and implementation effect |
| --- | --- | --- |
| EKS platform | Existing and externally managed | `data.aws_eks_cluster.existing` is the only permitted cluster relationship. Do not add an `aws_eks_cluster` resource. |
| Runner networking | Use the supplied private subnets; no public IPs | `private_subnet_ids` is the approved input. Do not enable public-IP assignment in new resources. |
| AMI | Use platform-owned SSM parameter `/platform/arc/runner-ami` | `data.aws_ssm_parameter.runner_ami` already exists in `terraform/main.tf`. The launch template must use its value; never embed an AMI ID. |
| IAM boundary | Mandatory for every role created here | Set `permissions_boundary = var.permissions_boundary_arn` on the new node role. |
| Compute architecture | Resolved: dedicated runner capacity on an EKS managed node group | D1 approves managed node groups, excludes Karpenter, and supersedes the formerly open shared/dedicated and provisioner choices. |
| Instance selection | Resolved: `m7i.large`, on demand | D1 selects the approved `m7i` family; the stale `m6i` shared-worker recommendation remains historical only. |
| Initial capacity | Resolved: two warm nodes | The frozen node-group scaling contract is min 2, desired 2, max 6. |
| Legacy security group `sg-0abc1234def567890` | Still ownership-unknown, but not a blocker for this slice | Do not import, reference, modify, delete, or assume ownership. The approved isolated resources do not need it. |

The removed transient platform inventory is not a source of truth. A fresh
platform export is required before any later live validation or external work,
but is not a prerequisite for the authorized repository-only slice because its
inputs are already modeled as externally supplied values.

## Benchmark evidence and its consequence

The requirement is additional usable runner capacity within 60 seconds.
`docs/benchmarks/runner-startup.md` records:

| Capacity state | p50 | p95 | p99 | Conclusion |
| --- | ---: | ---: | ---: | --- |
| Cold capacity | 49 sec | 86 sec | 103 sec | Does not meet the objective at p95 or p99. |
| Two warm nodes | 18 sec | 41 sec | 54 sec | Meets the recorded objective through p99. |

Cold-node availability alone takes 55--75 seconds before the additional 5--8
seconds of pod scheduling and 7--12 seconds of runner registration. Therefore,
the initial two-node warm floor is an SLO-control measure, not merely a
cost/capacity preference. The implementation must preserve minimum and desired
capacity of two; it must not represent cold scale-out as compliant with the
60-second objective.

The benchmark is evidence for this bounded configuration, not proof of the
99.9% monthly availability target or a complete production acceptance test. Its
workload profile, sample size, environment parity, and definition of “usable”
are not documented here. Keep those as operational validation work; do not
change the approved compute slice to fill those gaps by inference.

## Exact next implementation slice

Implement only the resources authorized in
`docs/implementation-readiness.md`, using the existing variables and data
sources:

1. In `terraform/iam.tf`, create one EC2 node IAM role with trust principal
   `ec2.amazonaws.com`, the required permissions boundary, and exactly these
   AWS-managed policy attachments:
   `AmazonEKSWorkerNodePolicy`, `AmazonEC2ContainerRegistryPullOnly`, and
   `AmazonEKS_CNI_Policy`.
2. In `terraform/runners.tf`, create one EC2 launch template whose image ID is
   `data.aws_ssm_parameter.runner_ami.value`. Do not set public-IP assignment
   or use the legacy security group.
3. Create one `aws_eks_node_group` connected to
   `data.aws_eks_cluster.existing`, with supplied private subnet IDs,
   `m7i.large`, `ON_DEMAND`, scaling min/desired/max of 2/2/6, label
   `workload = "arc-runner"`, and taint `dedicated=arc-runner:NO_SCHEDULE`.
   Make its creation depend on the required role-policy attachments and use the
   new launch template.
4. Extend the offline safety tests only where needed to lock in this contract:
   no cluster creation, no public-IP enablement, no literal AMI, required SSM
   indirection, permissions boundary on the created role, and no legacy
   security-group use. Run `terraform fmt -check` and
   `python3 -m unittest discover -s tests -v`.

Do not add ARC Helm/controller resources, GitHub credentials, Karpenter,
autoscaler changes, new security groups, external networking, or an apply/plan
workflow in this slice. Keep the implementation small and leave externally
owned values as inputs or read-only data sources.

## Still unresolved and deliberately out of scope

- Ownership and disposition of `sg-0abc1234def567890`.
- ARC control-plane details: chart/version source, GitHub authentication and
  secret ownership, runner scale-set names/labels, and ephemeral lifecycle
  configuration.
- Production operating model: workload/concurrency assumptions, node-to-runner
  density, failure/interruption handling, observability, alerting, and the
  acceptance method for 99.9% availability and the 60-second SLO.
- Live-environment facts and controls: actual cluster/subnet/boundary values,
  SSM parameter access/value schema and AMI rollout process, DNS/egress/GitHub
  connectivity, state/backend, provider authentication, promotion, and CI
  conventions.

These do not block the exact compute slice above unless an implementation tries
to add a dependency on them. Pause for an updated decision or platform fact if
that boundary would need to expand.

## Current repository baseline and fresh-agent checklist

- Decision: `docs/decisions/D1-runner-compute-architecture.md` is approved.
- Readiness contract: `docs/implementation-readiness.md` is the normative
  resource-level specification for the next slice.
- Benchmark: `docs/benchmarks/runner-startup.md` supports the two-node warm
  floor and rules out reliance on cold scale-out for the target.
- Existing guardrails include input validation and the SSM AMI data source;
  `terraform/iam.tf` and `terraform/runners.tf` remain TODO-only.
- Before editing, run `git status --short`: the workspace may contain
  intentionally uncommitted guardrail/documentation changes. Preserve unrelated
  work and do not overwrite it.

Start by re-reading this document, D1, and the readiness contract. Then make
the bounded Terraform/test change above, run only the authorized offline
checks, and record any newly discovered incompatibility as a blocker rather
than contacting or changing live infrastructure.

## Source precedence

Within their stated scope, the approved decision record and implementation
readiness contract supersede the older proposal/architecture material.
`docs/old-architecture-notes.md` is history only;
`docs/compute-options.md` is a pre-decision proposal log. Current requirements
and newly supplied platform facts remain authoritative for constraints not
covered by D1. If they conflict, pause and obtain an updated decision rather
than silently changing architecture or ownership.

