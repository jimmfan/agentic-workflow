from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
TERRAFORM = "\n".join(
    path.read_text(encoding="utf-8")
    for path in sorted((ROOT / "terraform").glob("*.tf"))
)


class RepositorySafetyTests(unittest.TestCase):
    def test_externally_managed_cluster_is_not_recreated(self) -> None:
        self.assertIsNone(
            re.search(r'resource\s+"aws_eks_cluster"', TERRAFORM, re.IGNORECASE)
        )

    def test_public_ip_assignment_is_not_enabled(self) -> None:
        self.assertIsNone(
            re.search(
                r"(?:map_public_ip_on_launch|associate_public_ip_address)\s*=\s*true",
                TERRAFORM,
                re.IGNORECASE,
            )
        )

    def test_legacy_security_group_is_not_managed(self) -> None:
        self.assertNotIn("sg-0abc1234def567890", TERRAFORM)

    def test_runner_ami_uses_the_approved_ssm_parameter(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'data\s+"aws_ssm_parameter"\s+"runner_ami"\s*\{[^}]*'
            r'name\s*=\s*"/platform/arc/runner-ami"',
        )

    def test_no_literal_ami_is_embedded(self) -> None:
        self.assertIsNone(
            re.search(r'\bami-[0-9a-f]{8,}\b', TERRAFORM, re.IGNORECASE)
        )

    def test_created_iam_roles_use_the_required_boundary(self) -> None:
        role_blocks = re.findall(
            r'resource\s+"aws_iam_role"\s+"[^"]+"\s*\{(.*?)\n\}',
            TERRAFORM,
            re.DOTALL,
        )
        for role_block in role_blocks:
            self.assertRegex(
                role_block,
                r'permissions_boundary\s*=\s*var\.permissions_boundary_arn',
            )


if __name__ == "__main__":
    unittest.main()
