from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
TERRAFORM = "\n".join(
    path.read_text(encoding="utf-8")
    for path in sorted((ROOT / "terraform").glob("*.tf"))
)


class RepositorySafetyTests(unittest.TestCase):
    def test_externally_managed_cluster_is_not_recreated(self) -> None:
        self.assertIsNone(
            re.search(r'resource\s+"aws_eks_cluster"', TERRAFORM, re.IGNORECASE)
        )

    def test_public_ip_assignment_is_not_enabled(self) -> None:
        self.assertIsNone(
            re.search(
                r"(?:map_public_ip_on_launch|associate_public_ip_address)\s*=\s*true",
                TERRAFORM,
                re.IGNORECASE,
            )
        )

    def test_legacy_security_group_is_not_managed(self) -> None:
        self.assertNotIn("sg-0abc1234def567890", TERRAFORM)

    def test_runner_ami_uses_the_approved_ssm_parameter(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'data\s+"aws_ssm_parameter"\s+"runner_ami"\s*\{[^}]*'
            r'name\s*=\s*"/platform/arc/runner-ami"',
        )

    def test_no_literal_ami_is_embedded(self) -> None:
        self.assertIsNone(
            re.search(r'\bami-[0-9a-f]{8,}\b', TERRAFORM, re.IGNORECASE)
        )

    def test_created_iam_roles_use_the_required_boundary(self) -> None:
        role_blocks = re.findall(
            r'resource\s+"aws_iam_role"\s+"[^"]+"\s*\{(.*?)\n\}',
            TERRAFORM,
            re.DOTALL,
        )
        for role_block in role_blocks:
            self.assertRegex(
                role_block,
                r'permissions_boundary\s*=\s*var\.permissions_boundary_arn',
            )

    def test_runner_node_role_has_only_the_approved_managed_policies(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'(?s)resource\s+"aws_iam_role"\s+"arc_runner_node"\s*\{.*?'
            r'Service\s*=\s*"ec2\.amazonaws\.com"',
        )
        attachment_block = re.search(
            r'resource\s+"aws_iam_role_policy_attachment"\s+"arc_runner_node"'
            r'\s*\{(.*?)\n\}',
            TERRAFORM,
            re.DOTALL,
        )
        self.assertIsNotNone(attachment_block)
        policies = re.findall(
            r'"(arn:aws:iam::aws:policy/[^"]+)"', attachment_block.group(1)
        )
        self.assertEqual(
            policies,
            [
                "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy",
                "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryPullOnly",
                "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy",
            ],
        )

    def test_runner_node_group_preserves_the_frozen_compute_contract(self) -> None:
        node_group_block = re.search(
            r'resource\s+"aws_eks_node_group"\s+"arc_runner"\s*\{(.*?)\n\}',
            TERRAFORM,
            re.DOTALL,
        )
        self.assertIsNotNone(node_group_block)
        node_group = node_group_block.group(1)
        for expected in (
            'cluster_name    = data.aws_eks_cluster.existing.name',
            'subnet_ids      = var.private_subnet_ids',
            'ami_type       = "CUSTOM"',
            'capacity_type  = "ON_DEMAND"',
            'instance_types = ["m7i.large"]',
            'min_size     = 2',
            'desired_size = 2',
            'max_size     = 6',
            'workload = "arc-runner"',
            'key    = "dedicated"',
            'value  = "arc-runner"',
            'effect = "NO_SCHEDULE"',
            'id      = aws_launch_template.arc_runner.id',
            'depends_on = [aws_iam_role_policy_attachment.arc_runner_node]',
        ):
            self.assertIn(expected, node_group)

    def test_launch_template_uses_the_ssm_resolved_ami(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'resource\s+"aws_launch_template"\s+"arc_runner"\s*\{[^}]*'
            r'image_id\s*=\s*data\.aws_ssm_parameter\.runner_ami\.value',
        )


if __name__ == "__main__":
    unittest.main()
