resource "aws_launch_template" "arc_runner" {
  name_prefix = "arc-runner-"
  image_id    = data.aws_ssm_parameter.runner_ami.value

  metadata_options {
    http_tokens = "required"
  }
}

resource "aws_eks_node_group" "arc_runner" {
  cluster_name    = data.aws_eks_cluster.existing.name
  node_group_name = "arc-runner"
  node_role_arn   = aws_iam_role.arc_runner_node.arn
  subnet_ids      = var.private_subnet_ids

  ami_type       = "CUSTOM"
  capacity_type  = "ON_DEMAND"
  instance_types = ["m7i.large"]

  scaling_config {
    min_size     = 2
    desired_size = 2
    max_size     = 6
  }

  labels = {
    workload = "arc-runner"
  }

  taint {
    key    = "dedicated"
    value  = "arc-runner"
    effect = "NO_SCHEDULE"
  }

  launch_template {
    id      = aws_launch_template.arc_runner.id
    version = aws_launch_template.arc_runner.latest_version
  }

  depends_on = [aws_iam_role_policy_attachment.arc_runner_node]
}
