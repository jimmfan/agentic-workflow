# T2: Build the approved dedicated runner compute slice

- Status: ready
- Blocked by: none
- Related: [D1 — Approve dedicated managed runner capacity](../decisions/D1-approve-dedicated-managed-runner-capacity.md), [T1 — Resolve the approved runner AMI through SSM](T1-resolve-approved-runner-ami-through-ssm.md)

## Outcome

Implement the repository-only Terraform slice for dedicated ARC runner compute:
the specified EC2 node role and policy attachments, SSM-backed EC2 launch
template, and EKS managed node group attached to the existing cluster.

## Acceptance

- The existing EKS cluster is consumed only through `data.aws_eks_cluster.existing`; no cluster resource is created.
- The new EC2 node role trusts only `ec2.amazonaws.com`, sets `var.permissions_boundary_arn`, and has exactly the three AWS-managed policies named in `docs/implementation-readiness.md`.
- The launch template uses `data.aws_ssm_parameter.runner_ami.value`; no AMI literal is added.
- The managed node group uses the supplied private subnet IDs, `m7i.large`, `ON_DEMAND`, scaling 2/2/6, label `workload = "arc-runner"`, and taint `dedicated=arc-runner:NO_SCHEDULE`.
- The node group depends on the required policy attachments and uses the new launch template.
- No public-IP setting, Karpenter resource, legacy security-group reference, external-state adoption, or external infrastructure operation is introduced.
- Run `terraform fmt -check` when Terraform is available and `python3 -m unittest discover -s tests -v`; run `terraform validate` only when it works without initialization, provider download, or external contact.

## Continuation

Start from `docs/implementation-readiness.md` as the authoritative slice
contract. U2, U3, and U4 are deliberately not blockers for this ticket; do not
expand the slice to controller, runner-pod, security-group, secret, or
Karpenter work.
