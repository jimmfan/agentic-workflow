# U2: Define runner identity and IAM policy

- Status: open
- Resolution mode: human clarification
- Blocked by: none
- Related: [U3 — Define runner network policy and resource ownership](U3-define-runner-network-policy-and-resource-ownership.md), [T2 — Build the approved dedicated runner compute slice](../tickets/T2-build-approved-dedicated-runner-compute-slice.md)

## Question

What AWS identities are required by the ARC controller, runner pods, and any
node/provisioning components, and what least-privilege policies and trust
relationships should each use? The answer must state how every created IAM role
uses `var.permissions_boundary_arn` and whether existing platform identities are
consumed rather than recreated.

## Evidence

- [Implementation readiness](../../../../docs/implementation-readiness.md)
  completely specifies the node-role portion of T2: an `ec2.amazonaws.com`
  trust principal, the required permissions boundary, and exactly three managed
  policy attachments. It does not specify controller or runner-pod identities.

## Resolution

Open for controller, runner-pod, and future provisioning identities. It does
not block T2: the only identity created by that bounded slice is fully
specified in implementation readiness.
