# U1: Select the runner capacity model

- Status: resolved
- Resolution mode: direct
- Blocked by: none
- Related: [U4 — Define ARC controller and GitHub integration](U4-define-arc-controller-and-github-integration.md), [T1 — Resolve the approved runner AMI through SSM](../tickets/T1-resolve-approved-runner-ami-through-ssm.md)

## Question

Which approved capacity model will supply ephemeral runner pods while meeting
the 99.9% monthly availability target and making additional usable capacity
available within 60 seconds? The decision must explicitly select the runner
instance family, shared versus dedicated compute isolation, and Karpenter versus
EKS managed node groups (or another approved provisioning mechanism).

## Evidence

- [D1 — Runner compute architecture](../../../../docs/decisions/D1-runner-compute-architecture.md)
  approves dedicated `m7i.large` capacity in an EKS managed node group, with a
  warm minimum and desired capacity of two nodes and no Karpenter.
- [Runner startup benchmark](../../../../docs/benchmarks/runner-startup.md)
  reports p99 startup of 54 seconds with two warm nodes; cold capacity p99 is
  103 seconds, so the warm capacity is material to the 60-second requirement.
- [Implementation readiness](../../../../docs/implementation-readiness.md)
  freezes the resource and scaling contract for repository implementation.

## Resolution

Resolved by [D1 — Approve dedicated managed runner capacity](../decisions/D1-approve-dedicated-managed-runner-capacity.md).
The decision makes [T2 — Build the approved dedicated runner compute slice](../tickets/T2-build-approved-dedicated-runner-compute-slice.md)
actionable. It does not resolve controller autoscaling configuration.
