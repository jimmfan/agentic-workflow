# D1: Approve dedicated managed runner capacity

- Related: [U1 — Select the runner capacity model](../unknowns/U1-select-runner-capacity-model.md), [T2 — Build the approved dedicated runner compute slice](../tickets/T2-build-approved-dedicated-runner-compute-slice.md)

## Decision

For the initial ARC rollout, use dedicated `m7i.large` runner capacity in an
EKS managed node group, with `ON_DEMAND` capacity and a minimum/desired/maximum
of 2/2/6 nodes. Do not use Karpenter in this slice.

## Why

The approved repository decision fixes the isolation, provisioning mechanism,
instance family, and scaling contract. The startup benchmark shows cold capacity
misses the 60-second p99 requirement (103 seconds), while two warm nodes meet
it (54 seconds p99). The warm minimum is therefore part of the accepted design,
not a tuning detail.

## Consequences

The isolated IAM role, launch template, and EKS managed node group are now a
single actionable repository implementation slice. Controller/GitHub
integration and the legacy security group's ownership remain unresolved, but
neither is needed to create the explicitly authorized new compute resources.
No external infrastructure operation is authorized.
