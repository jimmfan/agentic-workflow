# ARC runner migration

## Destination

Produce a repository-grounded route for migrating ephemeral GitHub Actions
runner capacity onto the existing EKS platform. The route is clear when each
authorized implementation slice has explicit inputs, ownership boundaries, and
acceptance criteria, without treating later ARC controller integration as a
blocker for independently safe compute work.

## Notes

This is a planning-only effort: do not apply or otherwise mutate external
infrastructure. Repository requirements and platform facts are authoritative
within their stated scope; [the 2024 architecture notes](../../../docs/old-architecture-notes.md)
are explicitly stale and are not approval. The configured external tracker and
domain files are absent, so this local map is the canonical durable artifact.

Known, durable constraints: use the existing EKS cluster as read-only input;
runner subnets are supplied private inputs; resolve the AMI from
`/platform/arc/runner-ami`; apply the supplied IAM permissions boundary; and do
not manage the legacy security group with unresolved ownership. [T1 — Resolve
the approved runner AMI through SSM](tickets/T1-resolve-approved-runner-ami-through-ssm.md)
is complete and independently covered by the offline safety suite. The approved
bounded compute slice is specified in
[implementation readiness](../../../docs/implementation-readiness.md); it is
repository-only work with local/static validation, never an external apply.

## Decisions so far

- [D1 — Approve dedicated managed runner capacity](decisions/D1-approve-dedicated-managed-runner-capacity.md) — Use two warm `m7i.large` nodes in an EKS managed node group, scaling from 2 to 6; benchmark evidence supports the 60-second requirement only with warm capacity.

## Not yet specified

- Controller deployment, GitHub authentication and secret ownership, runner
  scale-set scope, and controller-to-runner autoscaling integration need their
  own later implementation slice once their operational owner is known.
- Observability, availability measurement, rollout/rollback, image lifecycle,
  and operational ownership should be specified with that controller slice.

## Out of scope

- Applying, importing, deleting, adopting, or modifying external infrastructure
  during this planning effort, including the existing EKS cluster and the legacy
  `component=arc-legacy` security group.
- Treating the stale 2024 recommendation for shared `m6i` workers as a current
  design option or approval.
- ARC implementation beyond the authorized, repository-only
  [T2 — Build the approved dedicated runner compute slice](tickets/T2-build-approved-dedicated-runner-compute-slice.md),
  including controller deployment, GitHub credentials, runner scale sets, and
  production operations.
- Karpenter for the initial rollout; the approved slice explicitly uses an EKS
  managed node group.
