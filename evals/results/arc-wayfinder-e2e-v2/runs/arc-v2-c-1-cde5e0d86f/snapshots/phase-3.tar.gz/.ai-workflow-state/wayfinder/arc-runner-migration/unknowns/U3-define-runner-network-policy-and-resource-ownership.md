# U3: Define runner network policy and resource ownership

- Status: open
- Resolution mode: human clarification
- Blocked by: none
- Related: [U2 — Define runner identity and IAM policy](U2-define-runner-identity-and-iam-policy.md), [U4 — Define ARC controller and GitHub integration](U4-define-arc-controller-and-github-integration.md), [T2 — Build the approved dedicated runner compute slice](../tickets/T2-build-approved-dedicated-runner-compute-slice.md)

## Question

What subnet, security-group, egress, endpoint, and ownership model will runner
nodes and pods use to remain private while reaching the services they require?
The answer must identify which resources are safely created by this module and
which are supplied by the platform, without adopting the unresolved legacy
security group.

## Evidence

- [Requirements](../../../../docs/requirements.md) require private networking and
  prohibit public IP addresses.
- [Implementation readiness](../../../../docs/implementation-readiness.md)
  approves use of the supplied private subnet IDs and expressly states that the
  legacy security group is not required by T2.
- [Existing ARC-related resources](../../../../docs/existing-resources.md) records
  the legacy security group's unresolved ownership and forbids importing,
  deleting, modifying, or assuming control of it.
- [Repository safety tests](../../../../tests/test_repository_safety.py) currently
  guard against enabling public IPs and managing the observed legacy security
  group, but do not define an allowed network design.

## Resolution

Open for the future controller and pod connectivity contract. It does not block
T2, which must consume only supplied private subnets and must neither reference
nor manage the legacy security group.
