# U4: Define ARC controller and GitHub integration

- Status: open
- Resolution mode: human clarification
- Blocked by: none
- Related: [U2 — Define runner identity and IAM policy](U2-define-runner-identity-and-iam-policy.md), [U3 — Define runner network policy and resource ownership](U3-define-runner-network-policy-and-resource-ownership.md)

## Question

Which ARC deployment and GitHub integration shape is approved: controller
placement, runner scale-set ownership/scope, authentication mechanism and secret
ownership, and the autoscaling settings that turn the selected capacity model
into usable runners within 60 seconds?

## Evidence

- [README](../../../../README.md) establishes the target as ephemeral GitHub
  Actions runners on the existing EKS platform.
- No repository file describes an ARC chart/version, controller installation,
  GitHub organization or repository scope, credential source, secret owner, or
  runner scale-set configuration.
- [D1 — Runner compute architecture](../../../../docs/decisions/D1-runner-compute-architecture.md)
  resolves the selected capacity model, while [implementation readiness](../../../../docs/implementation-readiness.md)
  limits T2 to runner compute and supporting resources only.

## Resolution

Open and no longer blocked by capacity selection. It does not block T2 because
that slice deliberately excludes the controller, GitHub credentials, runner
scale sets, and their autoscaling configuration. Its answer may expose further
specific questions for secrets, deployment ownership, and operations.
