from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
TERRAFORM = "\n".join(
    path.read_text(encoding="utf-8")
    for path in sorted((ROOT / "terraform").glob("*.tf"))
)


class RepositorySafetyTests(unittest.TestCase):
    def test_runner_ami_is_resolved_from_platform_ssm_parameter(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'data\s+"aws_ssm_parameter"\s+"runner_ami"\s*\{[^}]*'
            r'name\s*=\s*"/platform/arc/runner-ami"',
        )
        self.assertIsNone(re.search(r'ami-[0-9a-f]{8,}', TERRAFORM, re.IGNORECASE))

    def test_externally_managed_cluster_is_not_recreated(self) -> None:
        self.assertRegex(
            TERRAFORM, r'data\s+"aws_eks_cluster"\s+"existing"\s*\{'
        )
        self.assertIsNone(
            re.search(r'resource\s+"aws_eks_cluster"', TERRAFORM, re.IGNORECASE)
        )

    def test_runner_node_role_has_required_boundary_trust_and_policies(self) -> None:
        role = TERRAFORM.split('resource "aws_iam_role" "arc_runner_node"', 1)[1]
        role = role.split('resource "aws_iam_role_policy_attachment"', 1)[0]
        self.assertRegex(
            role, r'permissions_boundary\s*=\s*var\.permissions_boundary_arn'
        )
        self.assertEqual(
            re.findall(r'Service\s*=\s*"([^"]+)"', role), ["ec2.amazonaws.com"]
        )
        self.assertEqual(
            sorted(re.findall(r'arn:aws:iam::aws:policy/[A-Za-z0-9_]+', TERRAFORM)),
            sorted(
                [
                    "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy",
                    "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryPullOnly",
                    "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy",
                ]
            ),
        )

    def test_runner_node_group_uses_approved_compute_contract(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'resource\s+"aws_eks_node_group"\s+"arc_runner"\s*\{[\s\S]*?'
            r'cluster_name\s*=\s*data\.aws_eks_cluster\.existing\.name',
        )
        for expression in (
            r'subnet_ids\s*=\s*var\.private_subnet_ids',
            r'capacity_type\s*=\s*"ON_DEMAND"',
            r'instance_types\s*=\s*\["m7i\.large"\]',
            r'min_size\s*=\s*2',
            r'desired_size\s*=\s*2',
            r'max_size\s*=\s*6',
            r'workload\s*=\s*"arc-runner"',
            r'key\s*=\s*"dedicated"',
            r'value\s*=\s*"arc-runner"',
            r'effect\s*=\s*"NO_SCHEDULE"',
            r'id\s*=\s*aws_launch_template\.arc_runner\.id',
        ):
            with self.subTest(expression=expression):
                self.assertRegex(TERRAFORM, expression)

    def test_node_group_waits_for_all_required_role_policies(self) -> None:
        node_group = TERRAFORM.split('resource "aws_eks_node_group" "arc_runner"', 1)[1]
        for attachment in (
            "arc_runner_node_worker",
            "arc_runner_node_ecr",
            "arc_runner_node_cni",
        ):
            with self.subTest(attachment=attachment):
                self.assertIn(
                    f"aws_iam_role_policy_attachment.{attachment}", node_group
                )

    def test_launch_template_uses_ssm_resolved_ami(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'resource\s+"aws_launch_template"\s+"arc_runner"\s*\{[^}]*'
            r'image_id\s*=\s*data\.aws_ssm_parameter\.runner_ami\.value',
        )

    def test_public_ip_assignment_is_not_enabled(self) -> None:
        self.assertIsNone(
            re.search(
                r"(?:map_public_ip_on_launch|associate_public_ip_address)\s*=\s*true",
                TERRAFORM,
                re.IGNORECASE,
            )
        )

    def test_legacy_security_group_is_not_managed(self) -> None:
        self.assertNotIn("sg-0abc1234def567890", TERRAFORM)

    def test_out_of_scope_resources_are_not_introduced(self) -> None:
        self.assertIsNone(re.search(r'\bkarpenter\b', TERRAFORM, re.IGNORECASE))


if __name__ == "__main__":
    unittest.main()
