# The platform owns the approved runner image. Keep the AMI lookup independent
# of runner compute until the capacity model is approved.
data "aws_ssm_parameter" "runner_ami" {
  name = "/platform/arc/runner-ami"
}
