# U1: Select the runner capacity model

- Status: open
- Resolution mode: human clarification
- Blocked by: none
- Related: [U4 — Define ARC controller and GitHub integration](U4-define-arc-controller-and-github-integration.md), [T1 — Resolve the approved runner AMI through SSM](../tickets/T1-resolve-approved-runner-ami-through-ssm.md)

## Question

Which approved capacity model will supply ephemeral runner pods while meeting
the 99.9% monthly availability target and making additional usable capacity
available within 60 seconds? The decision must explicitly select the runner
instance family, shared versus dedicated compute isolation, and Karpenter versus
EKS managed node groups (or another approved provisioning mechanism).

## Evidence

- [Current requirements](../../../../docs/requirements.md) set the availability,
  60-second capacity, private-networking, and ownership constraints.
- [Current platform facts](../../../../docs/platform-facts.md) expressly withhold
  approval for an instance family, isolation model, and Karpenter versus managed
  node groups.
- [Compute options](../../../../docs/compute-options.md) says `m7i` is only under
  consideration; it is not approval.
- [Stale architecture notes](../../../../docs/old-architecture-notes.md) reject the
  2024 shared-`m6i` proof-of-concept recommendation as a current decision.

## Resolution

Open. Obtain platform-owner approval with capacity evidence and record the
selected model as a durable decision. This answer gates compute resources and
the detailed autoscaling configuration, but not the SSM AMI lookup.
