# U4: Define ARC controller and GitHub integration

- Status: open
- Resolution mode: human clarification
- Blocked by: [U1 — Select the runner capacity model](U1-select-runner-capacity-model.md)
- Related: [U2 — Define runner identity and IAM policy](U2-define-runner-identity-and-iam-policy.md), [U3 — Define runner network policy and resource ownership](U3-define-runner-network-policy-and-resource-ownership.md)

## Question

Which ARC deployment and GitHub integration shape is approved: controller
placement, runner scale-set ownership/scope, authentication mechanism and secret
ownership, and the autoscaling settings that turn the selected capacity model
into usable runners within 60 seconds?

## Evidence

- [README](../../../../README.md) establishes the target as ephemeral GitHub
  Actions runners on the existing EKS platform.
- No repository file describes an ARC chart/version, controller installation,
  GitHub organization or repository scope, credential source, secret owner, or
  runner scale-set configuration.
- The 60-second requirement in [requirements](../../../../docs/requirements.md)
  makes this decision dependent on the selected capacity model.

## Resolution

Open. It is deliberately blocked by U1 because the capacity and provisioning
answer is needed to judge autoscaling behavior. The answer may expose further
specific questions for secrets, deployment ownership, and operations.
