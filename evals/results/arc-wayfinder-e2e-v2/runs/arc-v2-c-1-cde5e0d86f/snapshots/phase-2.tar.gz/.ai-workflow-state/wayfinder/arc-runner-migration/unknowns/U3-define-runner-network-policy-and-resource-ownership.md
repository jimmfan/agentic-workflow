# U3: Define runner network policy and resource ownership

- Status: open
- Resolution mode: human clarification
- Blocked by: none
- Related: [U2 — Define runner identity and IAM policy](U2-define-runner-identity-and-iam-policy.md), [U4 — Define ARC controller and GitHub integration](U4-define-arc-controller-and-github-integration.md)

## Question

What subnet, security-group, egress, endpoint, and ownership model will runner
nodes and pods use to remain private while reaching the services they require?
The answer must identify which resources are safely created by this module and
which are supplied by the platform, without adopting the unresolved legacy
security group.

## Evidence

- [Requirements](../../../../docs/requirements.md) require private networking and
  prohibit public IP addresses.
- [Platform facts](../../../../docs/platform-facts.md) says runner subnets are
  private inputs but provides no security-group, egress, endpoint, or ownership
  contract.
- [Existing ARC-related resources](../../../../docs/existing-resources.md) records
  the legacy security group's unresolved ownership and forbids importing,
  deleting, modifying, or assuming control of it.
- [Repository safety tests](../../../../tests/test_repository_safety.py) currently
  guard against enabling public IPs and managing the observed legacy security
  group, but do not define an allowed network design.

## Resolution

Open. Platform/security owners must provide the approved connectivity and
ownership contract. It blocks networking and security-group implementation,
while the SSM AMI lookup remains independent.
