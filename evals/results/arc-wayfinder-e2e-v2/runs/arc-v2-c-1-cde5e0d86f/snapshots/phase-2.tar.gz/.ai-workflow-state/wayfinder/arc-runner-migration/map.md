# ARC runner migration

## Destination

Produce a decision-ready, repository-grounded route for migrating ephemeral GitHub
Actions runner capacity onto the existing EKS platform. The route is clear when
the remaining infrastructure work can be scoped without guessing about platform
ownership, runner compute, controller integration, identity, or network policy.

## Notes

This is a planning-only effort: do not apply or otherwise mutate external
infrastructure. Repository requirements and platform facts are authoritative
within their stated scope; [the 2024 architecture notes](../../../docs/old-architecture-notes.md)
are explicitly stale and are not approval. The configured external tracker and
domain files are absent, so this local map is the canonical durable artifact.

Known, durable constraints: use the existing EKS cluster as read-only input;
runner subnets are supplied private inputs; resolve the AMI from
`/platform/arc/runner-ami`; apply the supplied IAM permissions boundary; and do
not manage the legacy security group with unresolved ownership. [T1 — Resolve
the approved runner AMI through SSM](tickets/T1-resolve-approved-runner-ami-through-ssm.md)
is complete and independently covered by the offline safety suite. The remaining
implementation work is gated by the open architecture decisions.

## Decisions so far

None. Repository facts constrain the route but do not settle the outstanding
architecture decisions.

## Not yet specified

- The detailed runner-controller deployment, GitHub authentication/secret
  handling, and autoscaling configuration should be decomposed after the
  integration and capacity-model decisions are made.
- Observability, availability measurement, rollout/rollback, image lifecycle,
  and operational ownership need concrete questions after the target runtime
  topology is known.
- The exact Terraform module interface and safe plan/validation strategy depend
  on the identity, networking, and controller integration answers.

## Out of scope

- Applying, importing, deleting, adopting, or modifying external infrastructure
  during this planning effort, including the existing EKS cluster and the legacy
  `component=arc-legacy` security group.
- Treating the stale 2024 recommendation for shared `m6i` workers as a current
  design option or approval.
- Implementing the ARC infrastructure itself; that begins only after the route
  is sufficiently settled and separately authorized.
