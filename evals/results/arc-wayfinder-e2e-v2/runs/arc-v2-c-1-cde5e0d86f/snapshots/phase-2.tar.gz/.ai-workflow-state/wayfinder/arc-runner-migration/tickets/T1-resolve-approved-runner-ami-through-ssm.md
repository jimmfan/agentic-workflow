# T1: Resolve the approved runner AMI through SSM

- Status: done
- Blocked by: none
- Related: [U1 — Select the runner capacity model](../unknowns/U1-select-runner-capacity-model.md)

## Outcome

Terraform resolves the runner AMI through the platform-owned SSM parameter
`/platform/arc/runner-ami`, without hard-coding an AMI ID or creating/modifying
external platform resources.

## Acceptance

- The Terraform configuration uses the approved SSM parameter as the AMI source.
- No literal AMI ID is introduced.
- Existing safety constraints continue to prohibit recreating the EKS cluster,
  enabling public IP assignment, or managing the unresolved legacy security
  group.
- The repository's offline safety test command passes after the change.

## Evidence

[Platform facts](../../../../docs/platform-facts.md), [requirements](../../../../docs/requirements.md),
and [security requirements](../../../../docs/security-requirements.md) agree on
this source of truth; [terraform/runners.tf](../../../../terraform/runners.tf)
already identifies it as independent of the compute architecture.

Implemented with `data.aws_ssm_parameter.runner_ami` using the approved path.
`python3 -m unittest discover -s tests -v` passed, including the regression
check for the SSM source and absence of a literal AMI ID.
