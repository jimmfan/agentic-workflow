# U2: Define runner identity and IAM policy

- Status: open
- Resolution mode: human clarification
- Blocked by: none
- Related: [U3 — Define runner network policy and resource ownership](U3-define-runner-network-policy-and-resource-ownership.md)

## Question

What AWS identities are required by the ARC controller, runner pods, and any
node/provisioning components, and what least-privilege policies and trust
relationships should each use? The answer must state how every created IAM role
uses `var.permissions_boundary_arn` and whether existing platform identities are
consumed rather than recreated.

## Evidence

- [Requirements](../../../../docs/requirements.md) and [security requirements](../../../../docs/security-requirements.md)
  require the supplied permissions boundary for runner roles.
- [terraform/iam.tf](../../../../terraform/iam.tf) is only a TODO for a narrowly
  scoped runner-node role, so it does not supply a policy or identity model.
- [Platform facts](../../../../docs/platform-facts.md) confirms the boundary
  requirement but contains no permission or trust-policy inventory.

## Resolution

Open. This is independent of selecting an instance family, but it blocks a
complete IAM implementation and the Terraform inputs needed for identity
integration.
