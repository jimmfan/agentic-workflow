# T2: Resolve the runner AMI through SSM

- Status: done
- Blocked by: none
- Related: [U1](../unknowns/U1-runner-compute-architecture.md), [U3](../unknowns/U3-capacity-slo-proof.md)

## Outcome

Add Terraform data lookup of the approved runner AMI through the platform-owned
SSM parameter `/platform/arc/runner-ami`, without creating compute resources.

## Acceptance

- Terraform refers to the approved SSM parameter rather than a literal AMI ID.
- The data lookup is usable by later, approved compute resources but does not
  force a compute-model choice.
- Offline checks prevent reintroduction of a hard-coded AMI ID where practical.
- No external infrastructure mutation occurs during implementation or
  validation.

## Evidence

- Added `data.aws_ssm_parameter.approved_runner_ami` in
  [terraform/runners.tf](../../../terraform/runners.tf), pointing to
  `/platform/arc/runner-ami` without adding compute resources.
- `python3 -m unittest discover -s tests -v` passed on 2026-08-15 (6 tests).
