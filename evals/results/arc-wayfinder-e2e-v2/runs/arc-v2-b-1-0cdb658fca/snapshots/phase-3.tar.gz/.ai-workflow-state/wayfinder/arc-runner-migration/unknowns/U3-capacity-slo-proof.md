# U3: Define 60-second capacity proof

- Status: open
- Resolution mode: human clarification
- Blocked by: [U2](U2-arc-control-plane-and-github-integration.md)
- Related: [T2](../tickets/T2-runner-ami-ssm-lookup.md)

## Question

How will the migration demonstrate that additional *usable* runner capacity is
available within 60 seconds, while supporting the 99.9% monthly availability
target? Define the measurement start/end events, load profile, capacity unit,
warm-capacity policy, acceptable percentile/error budget, and test environment.

## Evidence

- [Requirements](../../../docs/requirements.md) state the 60-second and 99.9%
  targets but provide no operational definition or validation method.
- [Runner startup benchmark](../../../docs/benchmarks/runner-startup.md) shows
  cold capacity at p95 86 seconds and p99 103 seconds, but two warm nodes at
  p95 41 seconds and p99 54 seconds. This supports the approved two-node warm
  baseline; it does not define the workload, measurement boundary, production
  sample, or availability calculation.
- [D1 runner compute architecture](../../../docs/decisions/D1-runner-compute-architecture.md)
  fixes dedicated managed-node-group capacity with min/desired/max 2/2/6, so
  compute selection no longer blocks the proof definition.
- The source tree has only static safety tests; it has no performance tests,
  observability configuration, or deployment environment definition.

## Resolution

Open. Resolve after ARC integration makes the usable-runner registration path
concrete. The resulting decision should drive a separately specified validation
work item rather than treating the current startup benchmark or node
provisioning alone as the measurement boundary.
