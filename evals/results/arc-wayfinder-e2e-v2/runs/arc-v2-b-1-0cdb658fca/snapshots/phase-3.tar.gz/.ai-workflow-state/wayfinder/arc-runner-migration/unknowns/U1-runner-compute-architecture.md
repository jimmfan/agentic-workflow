# U1: Select runner compute architecture

- Status: resolved
- Resolution mode: direct
- Blocked by: none
- Related: [U3](U3-capacity-slo-proof.md), [T1](../tickets/T1-boundary-constrained-runner-iam-role.md), [T2](../tickets/T2-runner-ami-ssm-lookup.md)

## Question

Which approved runner compute architecture will satisfy the target: exact EC2
instance family, shared versus dedicated runner compute, and Karpenter versus
EKS managed node groups? This decision blocks actual compute resources and
capacity behavior.

## Evidence

- The approved [D1 runner compute architecture](../../../docs/decisions/D1-runner-compute-architecture.md)
  selects dedicated `m7i.large` runner capacity on an EKS managed node group;
  Karpenter is out of scope and the initial scaling contract is 2/2/6.
- [Implementation readiness](../../../docs/implementation-readiness.md) makes
  that compute slice repository implementation work and fixes its private
  networking, labels, taint, and launch-template constraints.
- The [startup benchmark](../../../docs/benchmarks/runner-startup.md) found
  two warm nodes at p99 54 seconds, supporting the selected initial warm
  capacity; cold capacity was slower than the target.

## Resolution

Resolved by the approved [D1 runner compute architecture](../../../docs/decisions/D1-runner-compute-architecture.md).
The decision does not prove the production SLO; retain that work in [U3](U3-capacity-slo-proof.md).
