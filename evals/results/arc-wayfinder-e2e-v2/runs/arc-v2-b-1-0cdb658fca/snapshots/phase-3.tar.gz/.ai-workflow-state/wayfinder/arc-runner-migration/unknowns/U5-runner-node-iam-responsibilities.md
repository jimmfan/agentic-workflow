# U5: Define runner-node IAM responsibilities

- Status: resolved
- Resolution mode: direct
- Blocked by: none
- Related: [T1](../tickets/T1-boundary-constrained-runner-iam-role.md)

## Question

Which AWS API actions and resource scopes must the runner-node role have? An
approved least-privilege policy is required before this module can create that
role with the mandatory permissions boundary.

## Evidence

- [Implementation readiness](../../../docs/implementation-readiness.md) names
  the exact node-role trust principal (`ec2.amazonaws.com`) and the only three
  fixture policy attachments: `AmazonEKSWorkerNodePolicy`,
  `AmazonEC2ContainerRegistryPullOnly`, and `AmazonEKS_CNI_Policy`.
- The same contract requires `var.permissions_boundary_arn` and makes the
  managed node group depend on those attachments. It authorizes no inline
  broad policy and no additional AWS permissions for this slice.

## Resolution

Resolved for the bounded infrastructure slice by the approved
[implementation-readiness contract](../../../docs/implementation-readiness.md).
T1 must attach only the listed managed policies and the required permissions
boundary. ARC/GitHub credential ownership remains separately unresolved in U2.
