# ARC Runner Migration

## Destination

Establish a decision-ready, implementation-safe route for migrating ephemeral
GitHub Actions runner capacity onto the existing Amazon EKS platform. The route
is clear when the architecture, ownership, security, and 60-second capacity
validation decisions are sufficiently settled to sequence implementation work
without recreating or taking control of external infrastructure.

## Notes

- Repository evidence is authoritative over chat recollection. The current
  sources are [requirements](../../../docs/requirements.md), [security
  requirements](../../../docs/security-requirements.md), the approved
  [compute decision](../../../docs/decisions/D1-runner-compute-architecture.md),
  and the [implementation-readiness contract](../../../docs/implementation-readiness.md).
- This map is planning only. It does not authorize infrastructure mutation;
  `terraform apply` and all other external infrastructure changes remain out of
  scope and unauthorized.
- The existing EKS cluster remains data-only in [main.tf](../../../terraform/main.tf).
  The approved AMI is already read from SSM in [runner compute](../../../terraform/runners.tf);
  [IAM](../../../terraform/iam.tf) and the launch-template/node-group resources
  are intentionally still absent.
- The startup benchmark establishes that cold capacity does not meet the target
  (p95 86 seconds; p99 103 seconds), while two warm nodes did meet it in the
  observed run (p99 54 seconds). It supports the approved initial warm capacity
  of two; it is not an end-to-end 99.9% availability or production-SLO proof.
- [U2 — Specify ARC control-plane and GitHub integration](unknowns/U2-arc-control-plane-and-github-integration.md)
  and [U3 — Define 60-second capacity proof](unknowns/U3-capacity-slo-proof.md)
  remain open, but do not block the frozen infrastructure slice. [U4 — Establish
  legacy security-group ownership](unknowns/U4-legacy-security-group-ownership.md)
  blocks only work that would use or alter that group.
- [T2 — Resolve the runner AMI through SSM](tickets/T2-runner-ami-ssm-lookup.md)
  and [T3 — Extend offline safety guards](tickets/T3-offline-safety-guards.md)
  are complete. The readiness contract resolves [U5 — Define runner-node IAM
  responsibilities](unknowns/U5-runner-node-iam-responsibilities.md), making
  [T1 — Implement frozen dedicated runner-compute slice](tickets/T1-boundary-constrained-runner-iam-role.md)
  the ready continuation point.

## Decisions so far

- [D1 — Runner compute architecture](../../../docs/decisions/D1-runner-compute-architecture.md)
  — the initial rollout uses dedicated `m7i.large` capacity through an EKS
  managed node group, with min/desired/max 2/2/6; Karpenter is out of scope.
- The approved [implementation-readiness contract](../../../docs/implementation-readiness.md)
  fixes the node-role trust principal, three managed policy attachments,
  permissions boundary, private subnets, launch-template use, labels, and taint
  for the bounded repository-only slice.

## Not yet specified

- The exact ARC release/package, runner scale-set topology, GitHub
  authentication/credential ownership, namespace/RBAC boundaries, and
  observability/operational ownership may surface further questions after U2.
- Network-policy, egress, image-registry, DNS, logging, and secrets details
  are not documented. They should be sharpened only once the selected control
  plane and compute model reveal which are material.
- The end-to-end capacity measurement, acceptable percentiles/error budget,
  disruption handling, and availability calculations remain to be specified in
  U3. The existing benchmark is evidence for the two-node baseline, not a
  replacement for that work.

## Out of scope

- Creating, importing, deleting, modifying, or silently adopting the existing
  EKS cluster or any other externally owned infrastructure.
- Using the observed `component=arc-legacy` security group until its ownership
  and intended relationship to this migration are established.
- Terraform apply, account changes, or other external infrastructure mutation.
- Reviving the 2024 `m6i` shared-worker proof of concept as a current design.

## Exact continuation context

Start with [T1 — Implement frozen dedicated runner-compute slice](tickets/T1-boundary-constrained-runner-iam-role.md).
Implement only the frozen repository slice in the readiness contract: the
dedicated node IAM role and its three exact managed-policy attachments, then
the SSM-AMI launch template and the private-subnet EKS managed node group with
the approved 2/2/6 `m7i.large` contract, label, and taint. Preserve the
existing data-only EKS cluster and do not reference the legacy security group.
Run only offline/local checks allowed by the readiness contract; do not run
`terraform init`, `plan`, `apply`, or any external infrastructure operation.
Afterward, return to U2 and U3 for ARC integration and the production capacity
proof. Do not claim that the benchmark alone proves the SLO.
