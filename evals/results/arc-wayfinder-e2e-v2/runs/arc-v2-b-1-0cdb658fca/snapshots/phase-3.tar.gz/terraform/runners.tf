# Runner compute resources must wait for approved instance-family, isolation,
# and provisioning decisions. Resolve the platform-owned AMI now so later,
# approved compute resources can consume it without hard-coding an AMI ID.
data "aws_ssm_parameter" "approved_runner_ami" {
  name = "/platform/arc/runner-ami"
}
