data "aws_ssm_parameter" "approved_runner_ami" {
  name = "/platform/arc/runner-ami"
}

resource "aws_launch_template" "arc_runner" {
  name_prefix            = "arc-runner-"
  image_id               = data.aws_ssm_parameter.approved_runner_ami.value
  update_default_version = true
}

resource "aws_eks_node_group" "arc_runner" {
  cluster_name    = data.aws_eks_cluster.existing.name
  node_group_name = "arc-runner"
  node_role_arn   = aws_iam_role.arc_runner_node.arn
  subnet_ids      = var.private_subnet_ids

  capacity_type  = "ON_DEMAND"
  instance_types = ["m7i.large"]

  scaling_config {
    min_size     = 2
    desired_size = 2
    max_size     = 6
  }

  labels = {
    workload = "arc-runner"
  }

  taint {
    key    = "dedicated"
    value  = "arc-runner"
    effect = "NO_SCHEDULE"
  }

  launch_template {
    id      = aws_launch_template.arc_runner.id
    version = "$Latest"
  }

  depends_on = [
    aws_iam_role_policy_attachment.arc_runner_node_eks_worker,
    aws_iam_role_policy_attachment.arc_runner_node_ecr_pull,
    aws_iam_role_policy_attachment.arc_runner_node_cni,
  ]
}
