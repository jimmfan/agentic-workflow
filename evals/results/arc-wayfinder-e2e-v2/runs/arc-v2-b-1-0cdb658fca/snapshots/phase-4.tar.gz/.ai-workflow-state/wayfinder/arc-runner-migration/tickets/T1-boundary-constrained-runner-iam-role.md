# T1: Implement frozen dedicated runner-compute slice

- Status: done
- Blocked by: none
- Related: [U1](../unknowns/U1-runner-compute-architecture.md), [U5](../unknowns/U5-runner-node-iam-responsibilities.md)

## Outcome

Implement the bounded repository-only runner-compute slice authorized by
[implementation readiness](../../../docs/implementation-readiness.md): the
dedicated runner-node IAM role and exact attachments, an SSM-AMI launch
template, and the private-subnet EKS managed node group. Do not add ARC,
GitHub-facing, or external-infrastructure work.

## Acceptance

- Every new `aws_iam_role` in the module sets
  `permissions_boundary = var.permissions_boundary_arn`.
- The trust principal is exactly `ec2.amazonaws.com`.
- Attach exactly `AmazonEKSWorkerNodePolicy`,
  `AmazonEC2ContainerRegistryPullOnly`, and `AmazonEKS_CNI_Policy`; do not add
  inline broad permissions or infer ARC/GitHub credentials.
- The launch template consumes only the existing approved SSM AMI lookup; no
  literal AMI ID is introduced.
- The managed node group uses the existing cluster and private subnet inputs,
  depends on all three attachments, uses `m7i.large` and `ON_DEMAND`, has
  min/desired/max 2/2/6, and sets `workload = "arc-runner"` plus the
  `dedicated=arc-runner:NO_SCHEDULE` taint.
- No external resource is imported, modified, or assumed to be owned.
- The legacy security group is neither referenced nor managed, and the
  existing cluster remains data-only.
- The offline repository safety suite and Terraform formatting check pass.

## Evidence

- Added the dedicated `aws_iam_role.arc_runner_node` with the required
  permissions boundary, EC2 trust principal, and exactly the three approved
  AWS-managed policy attachments in [iam.tf](../../../terraform/iam.tf).
- Added the SSM-backed `aws_launch_template.arc_runner` and private-subnet
  `aws_eks_node_group.arc_runner` with the approved `m7i.large`, `ON_DEMAND`,
  2/2/6, label, taint, and attachment dependencies in
  [runners.tf](../../../terraform/runners.tf).
- Extended offline repository guards for the policy set, compute contract, and
  launch-template AMI source. `python3 -m unittest discover -s tests -v`,
  `terraform fmt -check -diff terraform`, and `terraform validate -no-color`
  passed on 2026-08-15. No Terraform initialization, planning, apply, or
  external infrastructure action was run.
