from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
TERRAFORM = "\n".join(
    path.read_text(encoding="utf-8")
    for path in sorted((ROOT / "terraform").glob("*.tf"))
)


class RepositorySafetyTests(unittest.TestCase):
    def test_externally_managed_cluster_is_not_recreated(self) -> None:
        self.assertIsNone(
            re.search(r'resource\s+"aws_eks_cluster"', TERRAFORM, re.IGNORECASE)
        )

    def test_public_ip_assignment_is_not_enabled(self) -> None:
        self.assertIsNone(
            re.search(
                r"(?:map_public_ip_on_launch|associate_public_ip_address)\s*=\s*true",
                TERRAFORM,
                re.IGNORECASE,
            )
        )

    def test_legacy_security_group_is_not_managed(self) -> None:
        self.assertNotIn("sg-0abc1234def567890", TERRAFORM)

    def test_runner_ami_uses_the_platform_ssm_parameter(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'data\s+"aws_ssm_parameter"\s+"approved_runner_ami"\s*\{'
            r'[^}]*name\s*=\s*"/platform/arc/runner-ami"',
        )

    def test_literal_ami_ids_are_not_introduced(self) -> None:
        self.assertIsNone(
            re.search(r'\bami-[0-9a-f]{8,17}\b', TERRAFORM, re.IGNORECASE)
        )

    def test_iam_roles_use_the_required_permissions_boundary(self) -> None:
        role_blocks = re.findall(
            r'resource\s+"aws_iam_role"\s+"[^"]+"\s*\{(.*?)^\}',
            TERRAFORM,
            re.IGNORECASE | re.MULTILINE | re.DOTALL,
        )
        for role_block in role_blocks:
            self.assertRegex(
                role_block,
                r'permissions_boundary\s*=\s*var\.permissions_boundary_arn',
            )

    def test_runner_node_role_uses_only_approved_managed_policies(self) -> None:
        policy_arns = re.findall(
            r'resource\s+"aws_iam_role_policy_attachment"\s+"arc_runner_node_[^"]+"'
            r'\s*\{.*?policy_arn\s*=\s*"([^"]+)"',
            TERRAFORM,
            re.DOTALL,
        )
        self.assertCountEqual(
            policy_arns,
            [
                "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy",
                "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryPullOnly",
                "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy",
            ],
        )

    def test_runner_node_role_trusts_only_ec2(self) -> None:
        role = re.search(
            r'resource\s+"aws_iam_role"\s+"arc_runner_node"\s*\{(.*?)^\}',
            TERRAFORM,
            re.MULTILINE | re.DOTALL,
        )
        self.assertIsNotNone(role)
        assert role is not None
        self.assertEqual(
            re.findall(r'Service\s*=\s*"([^"]+)"', role.group(1)),
            ["ec2.amazonaws.com"],
        )

    def test_runner_node_group_uses_the_frozen_compute_contract(self) -> None:
        node_group = re.search(
            r'resource\s+"aws_eks_node_group"\s+"arc_runner"\s*\{(.*?)^\}',
            TERRAFORM,
            re.MULTILINE | re.DOTALL,
        )
        self.assertIsNotNone(node_group)
        assert node_group is not None
        self.assertRegex(
            node_group.group(1),
            r'cluster_name\s*=\s*data\.aws_eks_cluster\.existing\.name',
        )
        self.assertRegex(node_group.group(1), r'subnet_ids\s*=\s*var\.private_subnet_ids')
        self.assertRegex(node_group.group(1), r'instance_types\s*=\s*\["m7i\.large"\]')
        self.assertRegex(node_group.group(1), r'capacity_type\s*=\s*"ON_DEMAND"')
        self.assertRegex(node_group.group(1), r'min_size\s*=\s*2')
        self.assertRegex(node_group.group(1), r'desired_size\s*=\s*2')
        self.assertRegex(node_group.group(1), r'max_size\s*=\s*6')
        self.assertRegex(node_group.group(1), r'workload\s*=\s*"arc-runner"')
        self.assertRegex(node_group.group(1), r'key\s*=\s*"dedicated"')
        self.assertRegex(node_group.group(1), r'value\s*=\s*"arc-runner"')
        self.assertRegex(node_group.group(1), r'effect\s*=\s*"NO_SCHEDULE"')
        self.assertRegex(
            node_group.group(1),
            r'(?s)depends_on\s*=\s*\['
            r'.*arc_runner_node_eks_worker'
            r'.*arc_runner_node_ecr_pull'
            r'.*arc_runner_node_cni',
        )

    def test_runner_launch_template_uses_the_ssm_resolved_ami(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'resource\s+"aws_launch_template"\s+"arc_runner"\s*\{'
            r'[^}]*image_id\s*=\s*data\.aws_ssm_parameter\.approved_runner_ami\.value',
        )


if __name__ == "__main__":
    unittest.main()
