# T3: Extend offline safety guards

- Status: ready
- Blocked by: none
- Related: [T1](T1-boundary-constrained-runner-iam-role.md), [T2](T2-runner-ami-ssm-lookup.md), [U4](../unknowns/U4-legacy-security-group-ownership.md)

## Outcome

Extend the repository's static/offline safety tests to protect the accepted
non-negotiables while the architecture decisions remain open.

## Acceptance

- Tests continue to reject creation of an EKS cluster, public-IP enablement,
  and management of `sg-0abc1234def567890`.
- Add focused checks for indirect approved-AMI lookup and permissions boundaries
  on any IAM roles introduced by this module.
- The checks run with `python3 -m unittest discover -s tests -v` and require no
  cloud credentials or external infrastructure access.
- Tests do not encode an unapproved instance family, isolation model, or
  provisioning mechanism.
