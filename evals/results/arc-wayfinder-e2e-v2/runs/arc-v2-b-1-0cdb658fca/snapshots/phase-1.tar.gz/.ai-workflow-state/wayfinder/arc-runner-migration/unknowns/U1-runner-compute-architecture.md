# U1: Select runner compute architecture

- Status: open
- Resolution mode: human clarification
- Blocked by: none
- Related: [U3](U3-capacity-slo-proof.md), [T1](../tickets/T1-boundary-constrained-runner-iam-role.md), [T2](../tickets/T2-runner-ami-ssm-lookup.md)

## Question

Which approved runner compute architecture will satisfy the target: exact EC2
instance family, shared versus dedicated runner compute, and Karpenter versus
EKS managed node groups? This decision blocks actual compute resources and
capacity behavior.

## Evidence

- [Compute options](../../../docs/compute-options.md) names all three as
  unresolved. `m7i` is only under consideration.
- [Platform facts](../../../docs/platform-facts.md) repeats that none of these
  choices is approved.
- [Requirements](../../../docs/requirements.md) require usable additional
  runner capacity within 60 seconds and 99.9% monthly availability.
- [Old architecture notes](../../../docs/old-architecture-notes.md) label the
  2024 `m6i` shared-worker recommendation stale and non-approved.

## Resolution

Open. Obtain an explicit platform-owner decision with the rationale and any
constraints (availability zones, capacity reservations, taints/labels,
autoscaling limits, and maintenance/disruption expectations). Create a D-item
only from that approved answer.
