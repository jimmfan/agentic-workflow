# U4: Establish legacy security-group ownership

- Status: open
- Resolution mode: human clarification
- Blocked by: none
- Related: none

## Question

Who owns security group `sg-0abc1234def567890`, tagged `component=arc-legacy`,
and is it relevant to this migration? This must be known before any proposal
uses, imports, modifies, or deletes it.

## Evidence

- [Existing resources](../../../docs/existing-resources.md) records the
  observed ID but explicitly says ownership and relationship to this module are
  unresolved.
- [Requirements](../../../docs/requirements.md) and [security
  requirements](../../../docs/security-requirements.md) prohibit taking control
  of unestablished external resources.
- The current safety test confirms the ID is not presently managed.

## Resolution

Open. Ask the platform account owner for ownership and intended use. Until then,
leave the security group entirely outside this module. This does not block a
new, approved security design that does not reference it.
