# U2: Specify ARC control-plane and GitHub integration

- Status: open
- Resolution mode: human clarification
- Blocked by: none
- Related: [U1](U1-runner-compute-architecture.md)

## Question

What ARC deployment model is approved: controller and runner-scale-set release,
GitHub scope, authentication mechanism and credential owner, namespace/RBAC
boundary, and the platform team responsible for operating it? These facts are
necessary before safely creating Kubernetes or GitHub-facing resources.

## Evidence

- [Requirements](../../../docs/requirements.md) identify ephemeral GitHub
  Actions runners on existing EKS, but do not specify ARC components, versions,
  scale sets, GitHub organization/repository scope, or credentials.
- No Kubernetes manifests, Helm configuration, GitHub authentication inputs, or
  ARC resources exist in the repository as of the 2026-08-15 inventory.

## Resolution

Open. Request an approved integration contract from the service/GitHub and EKS
owners. Capture a D-item with the named components, ownership boundaries, and
secret-handling approach; do not infer these from the migration title.
