# U3: Define 60-second capacity proof

- Status: open
- Resolution mode: human clarification
- Blocked by: [U1](U1-runner-compute-architecture.md), [U2](U2-arc-control-plane-and-github-integration.md)
- Related: [T2](../tickets/T2-runner-ami-ssm-lookup.md)

## Question

How will the migration demonstrate that additional *usable* runner capacity is
available within 60 seconds, while supporting the 99.9% monthly availability
target? Define the measurement start/end events, load profile, capacity unit,
warm-capacity policy, acceptable percentile/error budget, and test environment.

## Evidence

- [Requirements](../../../docs/requirements.md) state the 60-second and 99.9%
  targets but provide no operational definition or validation method.
- The source tree has only static safety tests; it has no performance tests,
  observability configuration, or deployment environment definition.

## Resolution

Open. Resolve after the selected compute and ARC integration model make the
capacity path concrete. The resulting decision should drive a separately
specified validation work item rather than assuming node provisioning alone is
the measurement boundary.
