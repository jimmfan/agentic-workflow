# ARC Runner Migration

## Destination

Establish a decision-ready, implementation-safe route for migrating ephemeral
GitHub Actions runner capacity onto the existing Amazon EKS platform. The route
is clear when the architecture, ownership, security, and 60-second capacity
validation decisions are sufficiently settled to sequence implementation work
without recreating or taking control of external infrastructure.

## Notes

- Repository evidence is authoritative over chat recollection. The starting
  sources are [requirements](../../../docs/requirements.md), [existing
  resources](../../../docs/existing-resources.md), and [security
  requirements](../../../docs/security-requirements.md).
- This map is planning only. It does not authorize infrastructure mutation;
  `terraform apply` and all other external infrastructure changes remain out of
  scope and unauthorized.
- [IAM](../../../terraform/iam.tf) remains incomplete. The approved AMI is
  now read from SSM in [runner compute](../../../terraform/runners.tf), while
  compute resources remain intentionally absent. The existing EKS cluster is
  data-only in [main.tf](../../../terraform/main.tf).
- On 2026-08-15, the repository safety suite passed (6 tests) with
  `python3 -m unittest discover -s tests -v`; `terraform fmt -check -recursive`
  also passed. No provider initialization, plan, or external access was
  performed.
- [U1 — Select runner compute architecture](unknowns/U1-runner-compute-architecture.md),
  [U2 — Specify ARC control-plane and GitHub integration](unknowns/U2-arc-control-plane-and-github-integration.md),
  and [U3 — Define 60-second capacity proof](unknowns/U3-capacity-slo-proof.md)
  block compute implementation. [U4 — Establish legacy security-group
  ownership](unknowns/U4-legacy-security-group-ownership.md) blocks only work
  that would use or alter that group.
- [T2 — Resolve the runner AMI through SSM](tickets/T2-runner-ami-ssm-lookup.md)
  and [T3 — Extend offline safety guards](tickets/T3-offline-safety-guards.md)
  are complete. [U5 — Define runner-node IAM
  responsibilities](unknowns/U5-runner-node-iam-responsibilities.md) blocks
  [T1 — Create boundary-constrained runner IAM
  role](tickets/T1-boundary-constrained-runner-iam-role.md).

## Decisions so far

No migration architecture decisions have been approved in repository evidence.
The constraints in the current requirements are binding inputs, not evidence of
an approved compute or ARC deployment design.

## Not yet specified

- The exact ARC release/package, runner scale-set topology, GitHub
  authentication/credential ownership, namespace/RBAC boundaries, and
  observability/operational ownership may surface further questions after U2.
- Network-policy, egress, image-registry, DNS, logging, and secrets details
  are not documented. They should be sharpened only once the selected control
  plane and compute model reveal which are material.
- Capacity sizing, warm capacity, disruption handling, and availability
  calculations may create further decisions after U1 and U3.

## Out of scope

- Creating, importing, deleting, modifying, or silently adopting the existing
  EKS cluster or any other externally owned infrastructure.
- Using the observed `component=arc-legacy` security group until its ownership
  and intended relationship to this migration are established.
- Terraform apply, account changes, or other external infrastructure mutation.
- Reviving the 2024 `m6i` shared-worker proof of concept as a current design.

## Exact continuation context

Start the next session by reading this map, then choose one open U-item. The
highest-leverage frontier is U1: obtain a platform-owner decision on instance
family, shared versus dedicated runner compute, and Karpenter versus EKS
managed node groups. Do not select `m6i` from historical notes or infer `m7i`
approval from consideration alone. Resolve U5 before implementing T1; resolve
U1, U2, and U3 before adding runner compute or claiming the capacity target is
met.
