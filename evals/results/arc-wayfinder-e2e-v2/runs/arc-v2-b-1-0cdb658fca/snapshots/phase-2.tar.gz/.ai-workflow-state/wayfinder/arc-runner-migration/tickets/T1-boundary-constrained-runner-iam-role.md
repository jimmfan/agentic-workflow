# T1: Create boundary-constrained runner IAM role

- Status: blocked
- Blocked by: [U5](../unknowns/U5-runner-node-iam-responsibilities.md)
- Related: [U1](../unknowns/U1-runner-compute-architecture.md), [U5](../unknowns/U5-runner-node-iam-responsibilities.md)

## Outcome

Add the narrowly scoped runner-node IAM role in Terraform, applying
`var.permissions_boundary_arn` to every IAM role this module creates. This is
explicitly identified as compute-architecture-independent in
[terraform/iam.tf](../../../terraform/iam.tf).

## Acceptance

- Every new `aws_iam_role` in the module sets
  `permissions_boundary = var.permissions_boundary_arn`.
- The role policy is limited to the documented runner-node responsibilities;
  if those responsibilities are not yet sufficiently specified, stop and add a
  focused unknown rather than granting broad permissions.
- No external resource is imported, modified, or assumed to be owned.
- The offline repository safety suite passes.
