# U5: Define runner-node IAM responsibilities

- Status: open
- Resolution mode: human clarification
- Blocked by: none
- Related: [T1](../tickets/T1-boundary-constrained-runner-iam-role.md)

## Question

Which AWS API actions and resource scopes must the runner-node role have? An
approved least-privilege policy is required before this module can create that
role with the mandatory permissions boundary.

## Evidence

- [T1](../tickets/T1-boundary-constrained-runner-iam-role.md) requires a policy
  limited to documented runner-node responsibilities and explicitly forbids
  granting broad permissions when those responsibilities are unspecified.
- [Requirements](../../../docs/requirements.md) and [security
  requirements](../../../docs/security-requirements.md) require the boundary
  but do not define any IAM actions, resources, or credential model.
- [U2](U2-arc-control-plane-and-github-integration.md) leaves the ARC
  integration and credential ownership unspecified, so it cannot safely supply
  the missing policy scope by inference.

## Resolution

Open. Obtain an approved runner-node responsibility matrix from the platform
and ARC owners, including AWS actions, resource ARNs or permitted wildcards,
and any conditions. Then refine T1 without assuming control of external
resources or granting wildcard administration.
