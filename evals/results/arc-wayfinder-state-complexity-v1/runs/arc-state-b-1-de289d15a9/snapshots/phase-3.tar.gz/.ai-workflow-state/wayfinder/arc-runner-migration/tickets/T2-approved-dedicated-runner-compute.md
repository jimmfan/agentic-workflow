# T2: Implement the approved dedicated runner compute slice

- Status: ready
- Blocked by: none
- Related: [D1 — Keep the runner node role and image lookup independent of compute selection](../decisions/D1-keep-identity-and-image-lookup-independent.md), [D2 — Use dedicated m7i managed-node-group runner capacity with two warm nodes](../decisions/D2-dedicated-m7i-managed-node-group.md)

## Outcome

Define the authorized dedicated ARC runner compute resources: a launch template
using the settled SSM AMI lookup and an EKS managed node group attached to the
existing cluster and supplied private subnets.

## Acceptance

- The node group uses on-demand `m7i.large` capacity with minimum 2, desired 2,
  and maximum 6.
- Nodes carry `workload = "arc-runner"` and the
  `dedicated=arc-runner:NoSchedule` taint.
- The new launch template consumes the existing SSM-resolved AMI; it contains no
  literal AMI ID.
- The node group uses the existing cluster input and private subnet IDs, depends
  on the three settled runner-node policy attachments, and creates no EKS
  cluster, Karpenter configuration, public-IP configuration, or reference to
  `sg-0abc1234def567890`.
- Terraform formatting and the repository offline safety suite pass. Run
  `terraform validate` only if already available without provider download or
  external contact; do not run `terraform init`, `plan`, or `apply`.
