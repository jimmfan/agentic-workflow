resource "aws_cloudwatch_metric_alarm" "failed_runner_jobs" {
  alarm_name          = "arc-failed-runner-jobs"
  alarm_description   = "Alerts when an ARC runner job fails."
  comparison_operator = "GreaterThanOrEqualToThreshold"
  evaluation_periods  = 1
  metric_name         = "FailedRunnerJobs"
  namespace           = "ARC/Runner"
  period              = 60
  statistic           = "Sum"
  threshold           = 1
  treat_missing_data  = "notBreaching"

  alarm_actions = ["arn:aws:sns:us-east-1:123456789012:arc-runner-alerts"]
}
