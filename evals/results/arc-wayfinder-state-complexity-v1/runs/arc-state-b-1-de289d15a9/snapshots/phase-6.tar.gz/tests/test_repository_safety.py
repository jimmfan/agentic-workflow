from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
TERRAFORM = "\n".join(
    path.read_text(encoding="utf-8")
    for path in sorted((ROOT / "terraform").glob("*.tf"))
)


class RepositorySafetyTests(unittest.TestCase):
    def test_runner_node_role_uses_the_approved_ec2_trust_and_boundary(self) -> None:
        role_match = re.search(
            r'resource\s+"aws_iam_role"\s+"runner_node"\s*\{(?P<body>.*?)^\}',
            TERRAFORM,
            re.MULTILINE | re.DOTALL,
        )
        self.assertIsNotNone(role_match)
        role = role_match.group("body")

        self.assertEqual(
            re.findall(r'Service\s*=\s*"([^"]+)"', role),
            ["ec2.amazonaws.com"],
        )
        self.assertIn("permissions_boundary = var.permissions_boundary_arn", role)

    def test_runner_node_role_attaches_exactly_the_approved_managed_policies(self) -> None:
        attachments = re.findall(
            r'resource\s+"aws_iam_role_policy_attachment"\s+"runner_node_[^"]+"\s*\{(?P<body>.*?)^\}',
            TERRAFORM,
            re.MULTILINE | re.DOTALL,
        )
        policies = {
            re.search(r'policy_arn\s*=\s*"([^"]+)"', attachment).group(1)
            for attachment in attachments
        }

        self.assertEqual(
            policies,
            {
                "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy",
                "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryPullOnly",
                "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy",
            },
        )

    def test_runner_ami_uses_the_approved_ssm_parameter(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'data\s+"aws_ssm_parameter"\s+"runner_ami"\s*\{\s*'
            r'name\s*=\s*"/platform/arc/runner-ami"\s*\}',
        )

    def test_externally_managed_cluster_is_not_recreated(self) -> None:
        self.assertIsNone(
            re.search(r'resource\s+"aws_eks_cluster"', TERRAFORM, re.IGNORECASE)
        )

    def test_public_ip_assignment_is_not_enabled(self) -> None:
        self.assertIsNone(
            re.search(
                r"(?:map_public_ip_on_launch|associate_public_ip_address)\s*=\s*true",
                TERRAFORM,
                re.IGNORECASE,
            )
        )

    def test_legacy_security_group_is_not_managed(self) -> None:
        self.assertNotIn("sg-0abc1234def567890", TERRAFORM)

    def test_karpenter_is_not_introduced(self) -> None:
        self.assertIsNone(re.search(r"karpenter\.sh|helm_release.*karpenter", TERRAFORM, re.IGNORECASE | re.DOTALL))

    def test_ami_is_not_hard_coded(self) -> None:
        self.assertIsNone(re.search(r"\bami-[0-9a-f]{8,17}\b", TERRAFORM, re.IGNORECASE))

    def test_runner_compute_uses_the_approved_dedicated_capacity(self) -> None:
        node_group_match = re.search(
            r'resource\s+"aws_eks_node_group"\s+"runner"\s*\{(?P<body>.*?)^\}',
            TERRAFORM,
            re.MULTILINE | re.DOTALL,
        )
        self.assertIsNotNone(node_group_match)
        node_group = node_group_match.group("body")

        self.assertIn('capacity_type  = "ON_DEMAND"', node_group)
        self.assertIn('instance_types = ["m7i.xlarge"]', node_group)
        self.assertIn("subnet_ids      = var.private_subnet_ids", node_group)
        self.assertRegex(
            node_group,
            r"scaling_config\s*\{\s*min_size\s*=\s*2\s*"
            r"desired_size\s*=\s*2\s*max_size\s*=\s*6\s*\}",
        )
        self.assertIn('workload = "arc-runner"', node_group)
        self.assertRegex(
            node_group,
            r'taint\s*\{\s*key\s*=\s*"dedicated"\s*'
            r'value\s*=\s*"arc-runner"\s*effect\s*=\s*"NO_SCHEDULE"\s*\}',
        )

    def test_runner_compute_uses_the_settled_inputs_and_iam_dependencies(self) -> None:
        launch_template_match = re.search(
            r'resource\s+"aws_launch_template"\s+"runner"\s*\{(?P<body>.*?)^\}',
            TERRAFORM,
            re.MULTILINE | re.DOTALL,
        )
        self.assertIsNotNone(launch_template_match)
        self.assertIn(
            "image_id      = data.aws_ssm_parameter.runner_ami.value",
            launch_template_match.group("body"),
        )

        node_group_match = re.search(
            r'resource\s+"aws_eks_node_group"\s+"runner"\s*\{(?P<body>.*?)^\}',
            TERRAFORM,
            re.MULTILINE | re.DOTALL,
        )
        self.assertIsNotNone(node_group_match)
        node_group = node_group_match.group("body")
        self.assertIn("cluster_name    = data.aws_eks_cluster.existing.name", node_group)
        self.assertIn("node_role_arn   = aws_iam_role.runner_node.arn", node_group)
        self.assertIn("id      = aws_launch_template.runner.id", node_group)
        self.assertIn("aws_iam_role_policy_attachment.runner_node_eks_worker", node_group)
        self.assertIn("aws_iam_role_policy_attachment.runner_node_ecr_pull", node_group)
        self.assertIn("aws_iam_role_policy_attachment.runner_node_eks_cni", node_group)

    def test_failed_runner_job_alarm_uses_the_approved_notification_destination(self) -> None:
        alarm_match = re.search(
            r'resource\s+"aws_cloudwatch_metric_alarm"\s+"failed_runner_jobs"\s*\{(?P<body>.*?)^\}',
            TERRAFORM,
            re.MULTILINE | re.DOTALL,
        )
        self.assertIsNotNone(alarm_match)
        alarm = alarm_match.group("body")

        self.assertIn('metric_name         = "FailedRunnerJobs"', alarm)
        self.assertIn('namespace           = "ARC/Runner"', alarm)
        self.assertIn(
            'alarm_actions = ["arn:aws:sns:us-east-1:123456789012:arc-runner-alerts"]',
            alarm,
        )


if __name__ == "__main__":
    unittest.main()
