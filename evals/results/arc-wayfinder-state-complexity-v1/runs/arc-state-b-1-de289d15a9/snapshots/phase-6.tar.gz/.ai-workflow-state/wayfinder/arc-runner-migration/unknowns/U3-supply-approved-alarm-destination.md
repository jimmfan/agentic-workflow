# U3: Supply the approved failed-runner-job alarm destination

- Status: resolved
- Resolution mode: human clarification
- Blocked by: none
- Related: [T3 — Implement the approved failed-runner-job alarm notification](../tickets/T3-approved-failed-runner-job-alarm-notification.md)

## Question

What project-approved destination ARN must receive the CloudWatch alarm for
failed runner jobs?

## Evidence

- `docs/observability-requirements.md` requires the alarm and originally
  identified the absent destination as a blocker.
- `docs/observability-destination.md` now approves exactly
  `arn:aws:sns:us-east-1:123456789012:arc-runner-alerts` for repository
  implementation and static validation.

## Resolution

Resolved by the approved destination in `docs/observability-destination.md`.
W4 is ready as T3. Repository implementation and static validation are
authorized; external infrastructure mutation remains unauthorized. W3 remains
independently blocked by U2.
