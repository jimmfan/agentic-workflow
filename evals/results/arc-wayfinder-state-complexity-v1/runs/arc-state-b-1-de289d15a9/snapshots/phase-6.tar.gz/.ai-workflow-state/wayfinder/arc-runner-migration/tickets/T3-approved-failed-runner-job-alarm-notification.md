# T3: Implement the approved failed-runner-job alarm notification

- Status: done
- Blocked by: none
- Related: [U3 — Supply the approved failed-runner-job alarm destination](../unknowns/U3-supply-approved-alarm-destination.md)

## Outcome

Implement the W4 CloudWatch metric alarm for failed runner jobs and configure
its notification action to the approved ARC runner alerts SNS destination.

## Acceptance

- The failed-runner-job CloudWatch metric alarm is defined in repository code.
- Its notification action targets exactly
  `arn:aws:sns:us-east-1:123456789012:arc-runner-alerts`.
- The implementation does not invent a different destination or mutate external
  infrastructure.
- Repository-local and static validation covers the approved notification
  destination; no external Terraform operation is run.

## Verification

- `terraform fmt -check -recursive` passed.
- `python3 -m unittest discover -s tests -v` passed (11 tests), including the
  exact approved SNS notification destination.
- `terraform validate` passed without initialization. No external Terraform
  operation was run.
