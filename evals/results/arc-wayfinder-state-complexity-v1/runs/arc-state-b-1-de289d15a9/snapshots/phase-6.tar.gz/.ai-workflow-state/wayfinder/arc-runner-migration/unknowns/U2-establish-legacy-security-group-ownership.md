# U2: Establish ownership and authorized disposition of the legacy ARC security group

- Status: open
- Resolution mode: human clarification
- Blocked by: none
- Related: none

## Question

Who owns security group `sg-0abc1234def567890` tagged `component=arc-legacy`,
and what (if any) authorized action should this migration take after ownership
is confirmed?

## Evidence

`docs/existing-resources.md` says repository history cannot establish whether
the group belongs to the platform team, a retired experiment, or another
Terraform state. It explicitly prohibits importing, deleting, modifying, or
assuming control until ownership and authorization are established.

## Resolution

Open. This prevents only W3 legacy-resource cleanup. It does not block W1, W2,
or W4 planning or implementation.
