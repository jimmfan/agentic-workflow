# D2: Use dedicated m7i.xlarge managed-node-group runner capacity with two warm nodes

- Related: [U1 — Approve the runner compute architecture](../unknowns/U1-approve-runner-compute-architecture.md), [T2 — Update the dedicated runner compute instance size](../tickets/T2-approved-dedicated-runner-compute.md)

## Decision

For the initial ARC rollout, use dedicated on-demand `m7i.xlarge` runner
capacity in an EKS managed node group. Keep two warm nodes, with minimum 2,
desired 2, and maximum 6. Use the existing private subnets, label nodes
`workload = "arc-runner"`, and taint them `dedicated=arc-runner:NoSchedule`.
The node group uses the settled SSM-resolved AMI through a new launch template.
Karpenter is not part of this initial rollout.

## Why

`docs/decisions/D1-runner-compute-architecture.md` remains the approved
architecture decision for dedicated placement, EKS managed node groups, no
Karpenter, and the 2/2/6 scaling contract. The later approved
`docs/decisions/D2-runner-instance-size.md` supersedes only its `m7i.large`
instance-size portion. `docs/benchmarks/runner-capacity-update.md` establishes
that `m7i.xlarge` provides the required CPU and memory headroom while retaining
the validated two-warm-node startup behavior. `docs/implementation-readiness.md`
continues to authorize the repository-local resources and safeguards for this
bounded slice, except where its older instance-size literal conflicts with the
later approved decision.

## Consequences

- W1 needs only the T2 instance-size correction; the existing dedicated
  managed-node-group implementation remains valid otherwise. It does not await
  discovery, a further compute decision, or disposition of the legacy security
  group.
- The implementation must attach to the existing read-only EKS cluster and
  approved private subnets, retain the W2 IAM and SSM-AMI contract, and create
  no cluster, public-IP configuration, Karpenter resources, or legacy-security-
  group reference.
- Repository implementation and local/static validation are authorized. External
  Terraform operations, including `init`, `plan`, and `apply`, remain outside
  the current authorization.

## Change note

Updated after `docs/decisions/D2-runner-instance-size.md` and
`docs/benchmarks/runner-capacity-update.md` superseded only the instance-size
literal: `m7i.large` is replaced by `m7i.xlarge`. Dedicated placement, EKS
managed node groups, no Karpenter, two warm nodes, and 2/2/6 scaling remain
unchanged.
