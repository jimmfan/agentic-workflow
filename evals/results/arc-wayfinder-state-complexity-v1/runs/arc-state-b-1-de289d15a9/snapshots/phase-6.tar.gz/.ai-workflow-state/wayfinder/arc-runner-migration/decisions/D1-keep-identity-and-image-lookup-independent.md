# D1: Keep the runner node role and image lookup independent of compute selection

- Related: [T1 — Implement the safe runner identity and AMI lookup slice](../tickets/T1-safe-runner-identity-and-ami-lookup.md)

## Decision

Implement the W2 runner-node IAM role and approved SSM AMI lookup as a
repository-local slice before W1 compute architecture is selected. The role
trust principal is `ec2.amazonaws.com`; it attaches the three AWS-managed EKS
node policies named in `docs/security-requirements.md`; and it sets
`permissions_boundary = var.permissions_boundary_arn`.

## Why

`docs/security-requirements.md` explicitly settles this W2 contract and says it
does not depend on W1 compute selection. The approved AMI source is the
platform-owned SSM parameter `/platform/arc/runner-ami`; no literal AMI ID is
permitted.

## Consequences

- W2 is the sole immediately executable implementation workstream.
- W1 remains free to choose instance family, isolation model, and provisioning
  mechanism later without reopening this identity/image contract.
- No external apply, discovery, or resource mutation is authorized by this
  decision.
