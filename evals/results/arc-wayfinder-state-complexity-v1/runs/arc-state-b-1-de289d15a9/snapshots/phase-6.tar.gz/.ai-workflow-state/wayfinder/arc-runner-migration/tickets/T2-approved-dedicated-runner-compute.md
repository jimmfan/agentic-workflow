# T2: Update the dedicated runner compute instance size

- Status: done
- Blocked by: none
- Related: [D1 — Keep the runner node role and image lookup independent of compute selection](../decisions/D1-keep-identity-and-image-lookup-independent.md), [D2 — Use dedicated m7i.xlarge managed-node-group runner capacity with two warm nodes](../decisions/D2-dedicated-m7i-managed-node-group.md)

## Outcome

Update the existing dedicated ARC runner launch template and EKS managed node
group from `m7i.large` to the newly approved `m7i.xlarge`, preserving the
otherwise-complete W1/W2 implementation.

## Acceptance

- The launch template and node group use `m7i.xlarge`; the node group remains
  on-demand with minimum 2, desired 2, and maximum 6.
- Nodes carry `workload = "arc-runner"` and the
  `dedicated=arc-runner:NoSchedule` taint.
- The existing launch template continues to consume the SSM-resolved AMI and
  contains no literal AMI ID.
- The node group uses the existing cluster input and private subnet IDs, depends
  on the three settled runner-node policy attachments, and creates no EKS
  cluster, Karpenter configuration, public-IP configuration, or reference to
  `sg-0abc1234def567890`.
- Terraform formatting and the repository offline safety suite pass. Run
  `terraform validate` only if already available without provider download or
  external contact; do not run `terraform init`, `plan`, or `apply`.

## Re-entry

The original W1/W2 implementation and its prior offline verification remain
valid except where they assert `m7i.large`. Update only those instance-type
literals and the associated static checks; do not rebuild unrelated resources.

## Verification

- `terraform fmt -check -recursive` passed.
- `python3 -m unittest discover -s tests -v` passed (11 tests).
- `terraform validate` passed without initialization. No `terraform init`,
  `plan`, or `apply` was run.
