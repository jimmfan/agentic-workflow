# U1: Approve the runner compute architecture

- Status: resolved
- Resolution mode: direct
- Blocked by: none
- Related: [D2 — Use dedicated m7i.xlarge managed-node-group runner capacity with two warm nodes](../decisions/D2-dedicated-m7i-managed-node-group.md), [T2 — Update the dedicated runner compute instance size](../tickets/T2-approved-dedicated-runner-compute.md)

## Question

Which compute architecture is approved for W1: the runner instance family,
shared versus dedicated runner compute, and Karpenter versus EKS managed node
groups? The approved combination must meet the 99.9% availability and
60-second additional-capacity targets while retaining private networking.

## Evidence

- [D1 runner compute architecture](../../../../docs/decisions/D1-runner-compute-architecture.md)
  established dedicated EKS managed-node-group capacity, two warm nodes, a
  2/2/6 minimum/desired/maximum scaling contract, and no Karpenter. Its
  original `m7i.large` instance-size literal is superseded by
  [D2 runner instance size](../../../../docs/decisions/D2-runner-instance-size.md),
  which approves `m7i.xlarge` only; the other D1 choices remain active.
- [Runner startup benchmark](../../../../docs/benchmarks/runner-startup.md) records
  a 54-second p99 with two warm nodes, satisfying the <=60-second additional
  usable-runner-capacity requirement. Cold capacity has an 86-second p95 and
  103-second p99, so it cannot serve as the initial capacity strategy.
- [Implementation readiness](../../../../docs/implementation-readiness.md) fixes
  the repository implementation boundary: use existing private subnets and
  read-only EKS cluster input, consume the settled SSM AMI lookup, and make no
  external mutation.

## Resolution

Resolved by D2. W1 design uncertainty is cleared; T2 is ready for the narrow
`m7i.xlarge` correction to the otherwise-valid implementation. U2 remains the
independent unresolved blocker for W3, while U3 is resolved and W4 is ready as
T3.
