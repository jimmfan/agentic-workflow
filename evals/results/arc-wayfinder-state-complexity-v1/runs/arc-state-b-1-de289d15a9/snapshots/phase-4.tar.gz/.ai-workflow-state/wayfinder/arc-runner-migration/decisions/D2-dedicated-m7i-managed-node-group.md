# D2: Use dedicated m7i managed-node-group runner capacity with two warm nodes

- Related: [U1 — Approve the runner compute architecture](../unknowns/U1-approve-runner-compute-architecture.md), [T2 — Implement the approved dedicated runner compute slice](../tickets/T2-approved-dedicated-runner-compute.md)

## Decision

For the initial ARC rollout, use dedicated on-demand `m7i.large` runner
capacity in an EKS managed node group. Keep two warm nodes, with minimum 2,
desired 2, and maximum 6. Use the existing private subnets, label nodes
`workload = "arc-runner"`, and taint them `dedicated=arc-runner:NoSchedule`.
The node group uses the settled SSM-resolved AMI through a new launch template.
Karpenter is not part of this initial rollout.

## Why

`docs/decisions/D1-runner-compute-architecture.md` is the approved architecture
decision. `docs/benchmarks/runner-startup.md` shows that two warm nodes provide
54-second p99 additional usable capacity, meeting the 60-second objective;
cold capacity misses it at both p95 and p99. `docs/implementation-readiness.md`
authorizes exactly the repository-local resources and safeguards needed to
implement this bounded slice.

## Consequences

- W1 is now actionable as T2; it does not await discovery, a further compute
  decision, or disposition of the legacy security group.
- The implementation must attach to the existing read-only EKS cluster and
  approved private subnets, retain the W2 IAM and SSM-AMI contract, and create
  no cluster, public-IP configuration, Karpenter resources, or legacy-security-
  group reference.
- Repository implementation and local/static validation are authorized. External
  Terraform operations, including `init`, `plan`, and `apply`, remain outside
  the current authorization.
