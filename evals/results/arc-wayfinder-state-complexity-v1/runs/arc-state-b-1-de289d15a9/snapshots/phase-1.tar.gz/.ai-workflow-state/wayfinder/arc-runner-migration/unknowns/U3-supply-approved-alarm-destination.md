# U3: Supply the approved failed-runner-job alarm destination

- Status: open
- Resolution mode: human clarification
- Blocked by: none
- Related: none

## Question

What project-approved destination ARN must receive the CloudWatch alarm for
failed runner jobs?

## Evidence

`docs/observability-requirements.md` requires the alarm but says the destination
ARN is absent and must not be invented.

## Resolution

Open. This prevents only W4 alarm/integration implementation. It is independent
of W1, W2, and W3.
