# T1: Implement the safe runner identity and AMI lookup slice

- Status: ready
- Blocked by: none
- Related: [D1 — Keep the runner node role and image lookup independent of compute selection](../decisions/D1-keep-identity-and-image-lookup-independent.md)

## Outcome

The Terraform module defines the approved runner-node IAM role and resolves the
runner AMI through the platform SSM parameter, without selecting or creating
W1 compute resources.

## Acceptance

- The role trusts exactly `ec2.amazonaws.com` and applies
  `var.permissions_boundary_arn`.
- The role attaches `AmazonEKSWorkerNodePolicy`,
  `AmazonEC2ContainerRegistryPullOnly`, and `AmazonEKS_CNI_Policy`.
- The AMI is retrieved from `/platform/arc/runner-ami`, with no literal AMI ID.
- No EKS cluster resource, public-IP configuration, Karpenter configuration, or
  reference to the legacy security group is introduced.
- The repository's offline safety suite passes; external `terraform apply` is
  not run.
