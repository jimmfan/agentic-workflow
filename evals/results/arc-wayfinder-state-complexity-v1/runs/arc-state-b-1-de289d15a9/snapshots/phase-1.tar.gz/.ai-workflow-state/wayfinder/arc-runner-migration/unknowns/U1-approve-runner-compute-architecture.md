# U1: Approve the runner compute architecture

- Status: open
- Resolution mode: human clarification
- Blocked by: none
- Related: none

## Question

Which compute architecture is approved for W1: the runner instance family,
shared versus dedicated runner compute, and Karpenter versus EKS managed node
groups? The approved combination must meet the 99.9% availability and
60-second additional-capacity targets while retaining private networking.

## Evidence

- `docs/compute-options.md` lists all three choices as unresolved and identifies
  `m7i` only as under consideration.
- `docs/platform-facts.md` confirms that the inventory approves none of the
  three choices.
- `docs/old-architecture-notes.md` explicitly marks the 2024 `m6i` shared-group
  recommendation stale.
- `docs/requirements.md` supplies the availability, capacity, and private-network
  constraints.

## Resolution

Open. This prevents only W1 compute-resource design and implementation; it does
not prevent T1/W2 or resolution of U2 and U3.
