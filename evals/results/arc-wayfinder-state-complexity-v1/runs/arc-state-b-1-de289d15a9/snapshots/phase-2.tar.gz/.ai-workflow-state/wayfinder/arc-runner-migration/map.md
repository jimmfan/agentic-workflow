# ARC runner migration

## Destination

Establish a decision-complete, dependency-aware route for migrating ephemeral
GitHub Actions runner capacity to the existing EKS platform, so each workstream
can be implemented and validated without recreating, adopting, or mutating
external infrastructure by accident.

## Notes

- Repository sources are the project-specific authority. `docs/old-architecture-notes.md`
  is stale history, not an approved input.
- No infrastructure execution belongs to this effort. Repository-local changes and
  offline checks are authorized; every external infrastructure mutation is not.
- W2 is complete through [T1 — Implement the safe runner identity and AMI lookup slice](tickets/T1-safe-runner-identity-and-ami-lookup.md); it remains independent of W1 compute selection.
- W1 is blocked only by [U1 — Approve the runner compute architecture](unknowns/U1-approve-runner-compute-architecture.md).
- W3 is blocked only by [U2 — Establish ownership and authorized disposition of the legacy ARC security group](unknowns/U2-establish-legacy-security-group-ownership.md).
- W4 is blocked only by [U3 — Supply the approved failed-runner-job alarm destination](unknowns/U3-supply-approved-alarm-destination.md).
- The 2026-08-14 platform inventory is current evidence for planning but explicitly
  transient; revalidate it before any external apply, not before repository-local W2 work.

## Decisions so far

- [D1 — Keep the runner node role and image lookup independent of compute selection](decisions/D1-keep-identity-and-image-lookup-independent.md) — W2 uses the settled EC2 trust, AWS-managed policies, permissions boundary, and SSM AMI mechanism without choosing W1 compute.

## Not yet specified

- Once W1 compute architecture is approved, the exact ARC/EKS resources, capacity
  model, and measurable proof of the 60-second scale-up target must be specified.
- Once the legacy security group's owner and disposition are established, determine
  whether any repository cleanup work remains at all.
- Once the alarm destination is supplied, specify the metric namespace/dimensions,
  threshold, alarm policy, and integration validation appropriate to the approved
  receiver.

## Out of scope

- Creating, importing, modifying, deleting, or adopting the externally managed
  EKS cluster or the unowned legacy security group; these are not migration work
  unless ownership and separate authorization are established.
- Treating the 2024 `m6i` shared-worker-group recommendation as a current option
  or approval.
