# The platform owns image selection; this module only consumes the approved
# parameter value in the dedicated runner launch template below.
data "aws_ssm_parameter" "runner_ami" {
  name = "/platform/arc/runner-ami"
}

resource "aws_launch_template" "runner_node" {
  name_prefix = "arc-runner-node-"

  image_id      = data.aws_ssm_parameter.runner_ami.value
  instance_type = "m7i.large"

  # Require IMDSv2 for nodes that will execute CI workloads.
  metadata_options {
    http_tokens = "required"
  }
}

resource "aws_eks_node_group" "runner" {
  cluster_name    = data.aws_eks_cluster.existing.name
  node_group_name = "arc-runner"
  node_role_arn   = aws_iam_role.runner_node.arn
  subnet_ids      = var.private_subnet_ids
  capacity_type   = "ON_DEMAND"

  scaling_config {
    min_size     = 2
    desired_size = 2
    max_size     = 6
  }

  labels = {
    workload = "arc-runner"
  }

  taint {
    key    = "dedicated"
    value  = "arc-runner"
    effect = "NO_SCHEDULE"
  }

  launch_template {
    id      = aws_launch_template.runner_node.id
    version = aws_launch_template.runner_node.latest_version
  }

  # EKS must not attempt to create nodes before their role permissions exist.
  depends_on = [aws_iam_role_policy_attachment.runner_node_managed]
}
