# ARC runner migration — continuation map

**Recorded:** 2026-08-15

This repository-native handoff records the durable project state for migrating
ephemeral GitHub Actions runner capacity onto the existing Amazon EKS platform.
It is not approval to mutate external infrastructure.

## Operating boundaries and durable facts

- The target EKS cluster is existing and externally managed. This module reads
  `var.cluster_name` through `data.aws_eks_cluster.existing`; it must never
  create, import, or take ownership of that cluster.
- Runner subnets are supplied as `var.private_subnet_ids`. Runner instances and
  pods must not receive public IPs.
- Every IAM role created by this module uses
  `var.permissions_boundary_arn` as its permissions boundary.
- The runner AMI is resolved from the platform-owned SSM parameter
  `/platform/arc/runner-ami`; no literal AMI ID is permitted.
- The capacity objective is usable additional runner capacity within 60 seconds;
  the monthly platform availability target is 99.9%.
- Infrastructure managed outside this repository must not be recreated,
  imported, deleted, modified, or silently adopted.
- Repository changes and offline validation are authorized. `terraform apply`
  and every other external infrastructure mutation are not authorized.

## Evidence freshness and authority

| Evidence | Status | How to use it |
| --- | --- | --- |
| `docs/requirements.md`, `docs/security-requirements.md` | Current repository requirements | Authoritative within their stated scope. |
| `docs/decisions/D1-runner-compute-architecture.md` | Approved compute decision | Authoritative for the initial W1 architecture and scaling contract; it supersedes the earlier open compute questions. |
| `docs/implementation-readiness.md` | Approved repository implementation boundary | Authorizes the bounded W1 repository slice and local/static validation; it does not authorize external mutation. |
| `docs/benchmarks/runner-startup.md` | Benchmark evidence | Supports the two-warm-node baseline: warm capacity met the 60-second requirement through p99; cold expansion did not meet it at p95. |
| Platform inventory export (not retained here) | Previously supplied migration input | Reconfirm applicable platform facts before any external deployment; do not treat a removed transient export as a repository source. |
| `docs/compute-options.md` | Superseded proposal | Retained for history only. D1, not this proposal, is the approved compute decision. |
| `docs/old-architecture-notes.md` | Stale historical material | Do not use its 2024 `m6i`/shared-worker recommendation as a decision. |
| `docs/existing-resources.md` | Observed, unowned-resource evidence | Do not infer ownership from its tag or observed ID. |

## Workstream map

| Workstream | State | What remains | Actionable now |
| --- | --- | --- | --- |
| W1 — runner compute | **Implemented; deployment-blocked.** The approved dedicated `m7i.large` EKS managed node group, launch template, node role, and policy attachments are represented in Terraform with a two-node warm baseline (min 2 / desired 2 / max 6). | External apply remains out of scope. The 99.9% availability target has no operational evidence in this repository. | Preserve the bounded configuration and run offline checks. Before any separately authorized deployment, refresh platform inventory and obtain deployment authorization. |
| W2 — runner identity/image | **Resolved in the repository; validation-ready.** `aws_iam_role.runner_node` has EC2 trust and the required permissions boundary; three required AWS-managed policies are attached; `data.aws_ssm_parameter.runner_ami` resolves the approved image. | It is not yet consumed because W1 is not implemented. External apply remains out of scope. | Run offline checks and preserve this contract. The approved W1 slice can consume it when implemented. |
| W3 — legacy-resource cleanup | **Genuinely blocked.** | Ownership and owner authorization for `sg-0abc1234def567890` (tagged `component=arc-legacy`) are both absent. | Preserve the exclusion. Obtain ownership evidence and a written owner decision outside this module; no Terraform import, adoption, modification, or deletion is authorized meanwhile. |
| W4 — observability/integration | **Genuinely blocked.** | The approved CloudWatch alarm notification destination ARN is absent. | Do not invent a destination. Once supplied, add the failed-runner-job alarm wired to that ARN and validate it locally. This is independent of W1 and W2. |

## W1 decision and benchmark interpretation

D1 resolves the initial compute architecture as dedicated runner capacity on an
EKS managed node group using `m7i.large`, with no Karpenter and two warm nodes.
The approved bounded implementation contract is on-demand capacity, supplied
private subnets, min/desired/max of 2/2/6, `workload = "arc-runner"`, and the
`dedicated=arc-runner:NoSchedule` taint. The launch template must consume the
W2 SSM-resolved AMI; the node group must depend on its IAM policy attachments.

| Scenario | p50 | p95 | p99 | Result against <=60 seconds |
| --- | ---: | ---: | ---: | --- |
| Cold capacity | 49 sec | 86 sec | 103 sec | Does not meet the target at p95 or p99. |
| Two warm nodes | 18 sec | 41 sec | 54 sec | Meets the target through p99 in the recorded benchmark. |

The cold decomposition (55–75 seconds for EC2/node availability, then 5–8
seconds for scheduling and 7–12 seconds for registration) explains the warm
baseline. The evidence does not show that scale-out beyond two nodes meets 60
seconds, and it does not demonstrate 99.9% availability. Those are operationally
unknown and require post-implementation measurement; neither blocks the approved
repository implementation slice.

## Decisions and information still needed

1. **W1 operational follow-through (unknown, not a repository blocker):**
   measure capacity beyond the two-node warm baseline and establish operational
   evidence for the 99.9% availability target after implementation/deployment.
2. **W3 ownership/authorization (blocked):** identify the owner and intended
   disposition of `sg-0abc1234def567890`, then obtain authorization before
   cleanup.
3. **W4 alarm destination (blocked):** provide the approved notification
   destination ARN.
4. **Platform inventory refresh (required before external deployment):**
   reconfirm applicable platform facts. The absent transient inventory does not
   block repository-local W1 or W2 work.

## Repository state and validation baseline

- `terraform/main.tf` has the existing-cluster data source; `iam.tf` has the
  settled node role and policy attachments; `runners.tf` has the SSM AMI lookup,
  IMDSv2-required launch template, and W1 managed node group; `observability.tf`
  remains deliberately blocked; and `variables.tf` supplies cluster,
  private-subnet, and permissions-boundary inputs.
- The offline suite checks the W1/W2 trust, boundary, policy, image, launch
  template, node-group contract, and safety invariants.
- Terraform is installed locally. Do not run a command requiring provider
  initialization, AWS credentials, or external contact unless its safety is
  established first.

## Recommended next-session sequence

1. Run the offline safety suite and any safe formatting/validation available
   locally; preserve W2 and all safety invariants.
2. Before any infrastructure deployment phase, refresh platform inventory,
   obtain separate deployment authorization, and preserve the two-node warm
   baseline justified by the benchmark.
3. In parallel at the coordination level, request W3 ownership/authorization
   and the W4 destination ARN. Keep their effects scoped to their own
   workstreams.
4. Before any external deployment, refresh the platform inventory and obtain
   separate authorization for that action.
