# ARC runner migration — continuation map

**Recorded:** 2026-08-15

This is the repository-native handoff for the in-progress migration of
ephemeral GitHub Actions runner capacity onto the existing Amazon EKS platform.
It records repository evidence as of this date; it is not approval to mutate
external infrastructure.

## Operating boundaries and durable facts

- The target is ephemeral GitHub Actions runners on an **existing**, externally
  managed EKS cluster. The module accepts `var.cluster_name` and has a read-only
  `data.aws_eks_cluster.existing` lookup; it must never create, import, or take
  ownership of that cluster.
- Runner subnets are private inputs (`var.private_subnet_ids`). Runner instances
  and pods must not receive public IPs.
- Every IAM role created by this module must use
  `var.permissions_boundary_arn` as its permissions boundary.
- The runner AMI must be resolved indirectly from the platform-owned SSM
  parameter `/platform/arc/runner-ami`; no literal AMI ID is permitted.
- New capacity must become usable within 60 seconds and the monthly platform
  availability target is 99.9%. These are acceptance constraints for the
  compute architecture, not evidence that a particular architecture is chosen.
- Infrastructure managed outside this repository must not be recreated,
  imported, deleted, modified, or silently adopted.
- Repository changes and offline validation are authorized. `terraform apply`
  and every other external infrastructure mutation are not authorized. A local
  `terraform plan` is permitted only when it can safely run without external
  contact or change.

## Evidence freshness and authority

| Evidence | Status | How to use it |
| --- | --- | --- |
| `docs/requirements.md`, `docs/security-requirements.md` | Current repository requirements | Authoritative within their stated scope. |
| `docs/platform-facts.md` | Current inventory export, dated 2026-08-14 | Use as the current platform input, but treat it as transient; it may be replaced after migration starts. |
| `docs/compute-options.md` | Open proposal | `m7i` is under consideration only; it is not approval. |
| `docs/old-architecture-notes.md` | Stale historical material | Do not use its 2024 `m6i`/shared-worker recommendation as a decision. |
| `docs/existing-resources.md` | Observed but unowned-resource evidence | Do not infer ownership from its tag or observed ID. |

## Workstream map

| Workstream | Current state | Exact blockers / dependencies | Actionable now |
| --- | --- | --- | --- |
| W1 — runner compute | Not started; intentionally deferred in `terraform/runners.tf`. | Requires an approved runner instance family, a shared-versus-dedicated compute decision, and a Karpenter-versus-EKS-managed-node-groups decision. The 60-second capacity requirement must be shown compatible with the selected design. | Document/prepare acceptance and implementation shape without selecting a compute design. Do **not** introduce Karpenter or compute resources until all three decisions are explicitly approved. |
| W2 — runner identity/image | Actionable; no implementation yet (`terraform/iam.tf` and AMI portion of `terraform/runners.tf` are TODOs). | No W1 decision is a dependency. Requires only the settled node-role contract and existing module inputs. External apply remains out of scope. | Implement repository-local IAM role and SSM AMI lookup, then run local/offline checks. |
| W3 — legacy-resource cleanup | Blocked. | Ownership of security group `sg-0abc1234def567890` (tagged `component=arc-legacy`) is unknown. Establishing ownership and obtaining owner authorization are both required before any import, modification, or deletion. | Preserve the exclusion. Gather ownership evidence or obtain a written owner decision outside this module; no Terraform resource/import/adoption work is authorized meanwhile. |
| W4 — observability/integration | Blocked. | The project-approved CloudWatch alarm notification destination ARN is absent. The required failed-runner-job alarm cannot be completed without it. | Define no destination and do not invent an ARN. Once supplied, add the alarm wired to that ARN and validate it locally. This blocker is independent of W1 and W2. |

## Settled W2 implementation contract

When W2 is picked up, create only the narrowly scoped runner-node identity and
the approved-image lookup:

- Trust principal: `ec2.amazonaws.com`.
- Required AWS-managed policy attachments:
  - `arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy`
  - `arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryPullOnly`
  - `arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy`
- Set `permissions_boundary = var.permissions_boundary_arn`.
- Resolve the AMI from `/platform/arc/runner-ami` through SSM rather than a
  hard-coded `ami-...` value.

This slice is intentionally independent of instance family, compute isolation,
and provisioner selection. It may proceed while W1 remains undecided.

## Decisions and information still needed

1. **W1 architecture approval:** exact instance family; shared or dedicated
   runner compute; and Karpenter or EKS managed node groups. These three are
   real blockers only for W1 compute implementation. Neither the consideration
   of `m7i` nor the historical `m6i` suggestion resolves any of them.
2. **W3 ownership/authorization:** identify the owner and intended disposition
   of `sg-0abc1234def567890`, then obtain authorization before cleanup. This is
   a real blocker only for W3.
3. **W4 alarm destination:** provide the approved notification destination ARN.
   This is a real blocker only for W4.
4. **Platform-facts refresh timing:** the 2026-08-14 export is usable current
   input now but is marked transient. Refresh/reconfirm it before a later
   external deployment; this does not block repository-local W2 work.

## Repository state and validation baseline

- Current Terraform is skeletal: `terraform/main.tf` has the existing-cluster
  data source; `iam.tf`, `runners.tf`, and `observability.tf` contain deliberate
  TODO/blocker comments; `variables.tf` provides cluster, private-subnet, and
  permissions-boundary inputs.
- The branch is `main`, at `b72bee6` (`Initial ARC evaluation fixture`) when
  this note was recorded. There were no pre-existing tracked worktree changes.
- `python3 -m unittest discover -s tests -v` passes: 5 tests. The safety suite
  currently guards against cluster creation, enabling public IP assignment,
  managing the unknown legacy security group, adding Karpenter, and hard-coded
  AMI IDs.
- Terraform is installed locally. Do not run a plan that requires provider
  initialization, AWS credentials, or other external contact unless its safety
  is established first.

## Recommended next-session sequence

1. Take W2 first: implement the settled IAM/SSM slice without choosing W1
   compute architecture or performing an apply.
2. Run the offline safety suite and any safe formatting/validation available
   locally; preserve all five safety invariants above.
3. In parallel at the coordination level, request the three W1 approvals, W3
   ownership/authorization, and W4 destination ARN. Keep their effects scoped
   to their own workstreams.
4. Before any future external deployment, reconfirm the transient platform
   inventory and separately obtain the authorization required for that action.
