# The platform owns the image selection. W1 compute resources may consume this
# value only after their instance-family, isolation, and provisioning decisions
# have been approved.
data "aws_ssm_parameter" "runner_ami" {
  name = "/platform/arc/runner-ami"
}
