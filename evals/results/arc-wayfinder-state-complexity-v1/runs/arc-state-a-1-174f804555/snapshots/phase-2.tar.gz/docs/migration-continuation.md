# ARC runner migration — continuation map

**Recorded:** 2026-08-15

This is the repository-native handoff for the in-progress migration of
ephemeral GitHub Actions runner capacity onto the existing Amazon EKS platform.
It records repository evidence as of this date; it is not approval to mutate
external infrastructure.

## Operating boundaries and durable facts

- The target is ephemeral GitHub Actions runners on an **existing**, externally
  managed EKS cluster. The module accepts `var.cluster_name` and has a read-only
  `data.aws_eks_cluster.existing` lookup; it must never create, import, or take
  ownership of that cluster.
- Runner subnets are private inputs (`var.private_subnet_ids`). Runner instances
  and pods must not receive public IPs.
- Every IAM role created by this module must use
  `var.permissions_boundary_arn` as its permissions boundary.
- The runner AMI must be resolved indirectly from the platform-owned SSM
  parameter `/platform/arc/runner-ami`; no literal AMI ID is permitted.
- New capacity must become usable within 60 seconds and the monthly platform
  availability target is 99.9%. These are acceptance constraints for the
  compute architecture, not evidence that a particular architecture is chosen.
- Infrastructure managed outside this repository must not be recreated,
  imported, deleted, modified, or silently adopted.
- Repository changes and offline validation are authorized. `terraform apply`
  and every other external infrastructure mutation are not authorized. A local
  `terraform plan` is permitted only when it can safely run without external
  contact or change.

## Evidence freshness and authority

| Evidence | Status | How to use it |
| --- | --- | --- |
| `docs/requirements.md`, `docs/security-requirements.md` | Current repository requirements | Authoritative within their stated scope. |
| Platform inventory export (not retained in this repository) | Previously supplied migration input | Reconfirm the platform facts before any external deployment; do not treat a removed transient export as a repository source. |
| `docs/compute-options.md` | Open proposal | `m7i` is under consideration only; it is not approval. |
| `docs/old-architecture-notes.md` | Stale historical material | Do not use its 2024 `m6i`/shared-worker recommendation as a decision. |
| `docs/existing-resources.md` | Observed but unowned-resource evidence | Do not infer ownership from its tag or observed ID. |

## Workstream map

| Workstream | Current state | Exact blockers / dependencies | Actionable now |
| --- | --- | --- | --- |
| W1 — runner compute | Not started; compute resources remain intentionally deferred. | Requires an approved runner instance family, a shared-versus-dedicated compute decision, and a Karpenter-versus-EKS-managed-node-groups decision. The 60-second capacity requirement must be shown compatible with the selected design. | Document/prepare acceptance and implementation shape without selecting a compute design. Do **not** introduce Karpenter or compute resources until all three decisions are explicitly approved. |
| W2 — runner identity/image | Implemented repository-locally: `aws_iam_role.runner_node` has EC2 trust and the required permissions boundary; the three required AWS-managed policies are attached; `data.aws_ssm_parameter.runner_ami` resolves the approved image. | No W1 decision is a dependency. External apply remains out of scope. The role and AMI data source are intentionally not attached to compute until W1 is approved. | Run offline checks; W1 can consume these identifiers after its architecture is approved. |
| W3 — legacy-resource cleanup | Blocked. | Ownership of security group `sg-0abc1234def567890` (tagged `component=arc-legacy`) is unknown. Establishing ownership and obtaining owner authorization are both required before any import, modification, or deletion. | Preserve the exclusion. Gather ownership evidence or obtain a written owner decision outside this module; no Terraform resource/import/adoption work is authorized meanwhile. |
| W4 — observability/integration | Blocked. | The project-approved CloudWatch alarm notification destination ARN is absent. The required failed-runner-job alarm cannot be completed without it. | Define no destination and do not invent an ARN. Once supplied, add the alarm wired to that ARN and validate it locally. This blocker is independent of W1 and W2. |

## Settled W2 implementation contract

W2 creates only the narrowly scoped runner-node identity and the approved-image
lookup:

- Trust principal: `ec2.amazonaws.com`.
- Required AWS-managed policy attachments:
  - `arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy`
  - `arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryPullOnly`
  - `arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy`
- Set `permissions_boundary = var.permissions_boundary_arn`.
- Resolve the AMI from `/platform/arc/runner-ami` through SSM rather than a
  hard-coded `ami-...` value.

This slice is intentionally independent of instance family, compute isolation,
and provisioner selection. It may proceed while W1 remains undecided.

## Decisions and information still needed

1. **W1 architecture approval:** exact instance family; shared or dedicated
   runner compute; and Karpenter or EKS managed node groups. These three are
   real blockers only for W1 compute implementation. Neither the consideration
   of `m7i` nor the historical `m6i` suggestion resolves any of them.
2. **W3 ownership/authorization:** identify the owner and intended disposition
   of `sg-0abc1234def567890`, then obtain authorization before cleanup. This is
   a real blocker only for W3.
3. **W4 alarm destination:** provide the approved notification destination ARN.
   This is a real blocker only for W4.
4. **Platform inventory refresh:** the prior inventory export was transient and
   is no longer retained here. Reconfirm the applicable platform facts before a
   later external deployment; this does not block repository-local W2 work.

## Repository state and validation baseline

- `terraform/main.tf` has the existing-cluster data source; `iam.tf` has the
  settled W2 node role and managed-policy attachments; `runners.tf` has the W2
  SSM AMI lookup; `observability.tf` remains deliberately blocked; and
  `variables.tf` provides cluster, private-subnet, and permissions-boundary
  inputs.
- The offline suite now checks the W2 trust, boundary, policy, and SSM
  requirements in addition to the original safety invariants.
- Terraform is installed locally. Do not run a plan that requires provider
  initialization, AWS credentials, or other external contact unless its safety
  is established first.

## Recommended next-session sequence

1. Run the offline safety suite and any safe formatting/validation available
   locally; preserve the W2 contract and all safety invariants.
2. In parallel at the coordination level, request the three W1 approvals, W3
   ownership/authorization, and W4 destination ARN. Keep their effects scoped
   to their own workstreams.
3. Before any future external deployment, reconfirm the applicable platform
   inventory and separately obtain the authorization required for that action.
