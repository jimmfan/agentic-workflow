# ARC runner migration — continuation map

**Recorded:** 2026-08-15

This repository-native handoff records the durable project state for migrating
ephemeral GitHub Actions runner capacity onto the existing Amazon EKS platform.
It is not approval to mutate external infrastructure.

## Operating boundaries and durable facts

- The target EKS cluster is existing and externally managed. This module reads
  `var.cluster_name` through `data.aws_eks_cluster.existing`; it must never
  create, import, or take ownership of that cluster.
- Runner subnets are supplied as `var.private_subnet_ids`. Runner instances and
  pods must not receive public IPs.
- Every IAM role created by this module uses
  `var.permissions_boundary_arn` as its permissions boundary.
- The runner AMI is resolved from the platform-owned SSM parameter
  `/platform/arc/runner-ami`; no literal AMI ID is permitted.
- The capacity objective is usable additional runner capacity within 60 seconds;
  the monthly platform availability target is 99.9%.
- Infrastructure managed outside this repository must not be recreated,
  imported, deleted, modified, or silently adopted.
- Repository changes and offline validation are authorized. `terraform apply`
  and every other external infrastructure mutation are not authorized.

## Evidence freshness and authority

| Evidence | Status | How to use it |
| --- | --- | --- |
| `docs/requirements.md`, `docs/security-requirements.md` | Current repository requirements | Authoritative within their stated scope. |
| `docs/decisions/D1-runner-compute-architecture.md` | Partially superseded approved compute decision | Authoritative for dedicated placement, EKS managed node groups, no Karpenter, and the 2/2/6 scaling contract. Its `m7i.large` size is superseded by D2. |
| `docs/decisions/D2-runner-instance-size.md`, `docs/benchmarks/runner-capacity-update.md` | Current approved size decision and supporting evidence | Use `m7i.xlarge` for W1. The production replay showed that `m7i.large` lacks required CPU/memory headroom; `m7i.xlarge` retains the validated two-warm-node startup behavior. This changes no other D1 decision. |
| `docs/implementation-readiness.md` | Approved repository implementation boundary | Authorizes the bounded W1 repository slice and local/static validation; it does not authorize external mutation. |
| `docs/benchmarks/runner-startup.md` | Benchmark evidence | Supports the two-warm-node baseline: warm capacity met the 60-second requirement through p99; cold expansion did not meet it at p95. |
| `docs/observability-destination.md` | Current approved W4 implementation input | Authorizes repository/static implementation of the failed-runner CloudWatch alarm using its exact SNS destination ARN. It supersedes the missing-destination blocker in `docs/observability-requirements.md`. |
| Platform inventory export (not retained here) | Previously supplied migration input | Reconfirm applicable platform facts before any external deployment; do not treat a removed transient export as a repository source. |
| `docs/compute-options.md` | Superseded proposal | Retained for history only. D1, not this proposal, is the approved compute decision. |
| `docs/old-architecture-notes.md` | Stale historical material | Do not use its 2024 `m6i`/shared-worker recommendation as a decision. |
| `docs/existing-resources.md` | Observed, unowned-resource evidence | Do not infer ownership from its tag or observed ID. |

## Workstream map

| Workstream | State | What remains | Actionable now |
| --- | --- | --- | --- |
| W1 — runner compute | **Partially implemented; repository reconciliation actionable.** The dedicated EKS managed node group, launch template, node role, policy attachments, and two-node warm baseline are represented in Terraform, but the launch template still specifies the now-superseded `m7i.large`. | Change only the W1 instance-type literal to approved `m7i.xlarge`, then update/add local safety coverage as needed. External apply remains out of scope. The 99.9% availability target has no operational evidence in this repository. | Implement the narrow D2 size reconciliation and run offline checks. Before any separately authorized deployment, refresh platform inventory and obtain deployment authorization. |
| W2 — runner identity/image | **Resolved in the repository; valid and ready to consume.** `aws_iam_role.runner_node` has EC2 trust and the required permissions boundary; three required AWS-managed policies are attached; `data.aws_ssm_parameter.runner_ami` resolves the approved image. | No D2 or W4 change affects this contract. External apply remains out of scope. | Preserve the contract and its safety checks while completing W1. |
| W3 — legacy-resource cleanup | **Genuinely blocked.** | Ownership and owner authorization for `sg-0abc1234def567890` (tagged `component=arc-legacy`) are both absent. | Preserve the exclusion. Obtain ownership evidence and a written owner decision outside this module; no Terraform import, adoption, modification, or deletion is authorized meanwhile. |
| W4 — observability/integration | **Actionable; not yet implemented.** | The required destination is now approved: `arn:aws:sns:us-east-1:123456789012:arc-runner-alerts`. The alarm itself is not yet present in Terraform. | Add the failed-runner CloudWatch metric alarm wired exactly to that ARN, with local/static validation. Do not perform external infrastructure mutation. This work is independent of W1/W2 and does not change W3. |

## W1 decision and benchmark interpretation

D1 resolves the initial compute architecture as dedicated runner capacity on an
EKS managed node group, with no Karpenter and two warm nodes. D2 supersedes
only D1's instance-size selection: use `m7i.xlarge`, not `m7i.large`. The
approved bounded implementation contract is on-demand capacity, supplied
private subnets, min/desired/max of 2/2/6, `workload = "arc-runner"`, and the
`dedicated=arc-runner:NoSchedule` taint. The launch template must consume the
W2 SSM-resolved AMI; the node group must depend on its IAM policy attachments.

| Scenario | p50 | p95 | p99 | Result against <=60 seconds |
| --- | ---: | ---: | ---: | --- |
| Cold capacity | 49 sec | 86 sec | 103 sec | Does not meet the target at p95 or p99. |
| Two warm nodes | 18 sec | 41 sec | 54 sec | Meets the target through p99 in the recorded benchmark. |

The cold decomposition (55–75 seconds for EC2/node availability, then 5–8
seconds for scheduling and 7–12 seconds for registration) explains the warm
baseline. The evidence does not show that scale-out beyond two nodes meets 60
seconds, and it does not demonstrate 99.9% availability. Those are operationally
unknown and require post-implementation measurement; neither blocks the approved
repository implementation slice.

## Decisions and information still needed

1. **W1 repository reconciliation (actionable):** change the launch-template
   instance type from `m7i.large` to `m7i.xlarge`, preserving every other D1
   decision and W2 dependency. Update/add offline safety coverage for the
   approved size.
2. **W4 implementation (actionable):** add the failed-runner CloudWatch metric
   alarm and wire it exactly to
   `arn:aws:sns:us-east-1:123456789012:arc-runner-alerts`; add local/static
   coverage. Do not infer other alarm inputs that are not documented.
3. **W1 operational follow-through (unknown, not a repository blocker):**
   measure capacity beyond the two-node warm baseline and establish operational
   evidence for the 99.9% availability target after implementation/deployment.
4. **W3 ownership/authorization (blocked):** identify the owner and intended
   disposition of `sg-0abc1234def567890`, then obtain authorization before
   cleanup.
5. **Platform inventory refresh (required before external deployment):**
   reconfirm applicable platform facts. The absent transient inventory does not
   block repository-local W1 or W2 work.

## Repository state and validation baseline

- `terraform/main.tf` has the existing-cluster data source; `iam.tf` has the
  settled node role and policy attachments; `runners.tf` has the SSM AMI lookup,
  IMDSv2-required launch template, and W1 managed node group, but contains the
  stale `m7i.large` literal; `observability.tf` has no alarm yet; and
  `variables.tf` supplies cluster, private-subnet, and permissions-boundary
  inputs.
- The offline suite covers the prior W1/W2 trust, boundary, policy, image,
  launch-template, node-group, and safety invariants. Its `m7i.large`
  expectation must be reconciled with D2, and W4 coverage must be added when
  W4 is implemented.
- Terraform is installed locally. Do not run a command requiring provider
  initialization, AWS credentials, or external contact unless its safety is
  established first.

## Recommended next-session sequence

1. Reconcile W1 narrowly: replace the stale `m7i.large` instance type with
   `m7i.xlarge` and adjust its offline safety expectation. Preserve the rest of
   the D1 and W2 contract.
2. Implement W4 independently: add the failed-runner alarm wired exactly to
   the approved SNS ARN and add local/static coverage. Do not introduce a
   fabricated destination or external mutation.
3. Run the offline safety suite and safe formatting/validation available
   locally; preserve W2 and all safety invariants.
4. In parallel at the coordination level, request W3 ownership/authorization.
   Keep that cleanup excluded until both are supplied.
5. Before any infrastructure deployment, refresh the platform inventory,
   obtain separate deployment authorization, retain the two-node warm baseline,
   and establish operational evidence for the availability target.
