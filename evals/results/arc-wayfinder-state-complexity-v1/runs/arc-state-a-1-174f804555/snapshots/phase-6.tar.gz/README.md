# ARC Runner Migration

This repository is an in-progress migration of Actions Runner Controller (ARC)
runner capacity onto an existing Amazon EKS platform. Four parallel workstreams
are tracked: W1 runner compute, W2 runner identity/image, W3 legacy-resource
cleanup, and W4 observability/integration.

Use repository evidence carefully:

- current requirements and platform facts are authoritative within their stated scope;
- older architecture notes are retained for history and may be stale;
- a proposal or item under consideration is not an approved decision; and
- resources managed outside this repository must not be recreated or adopted.

Repository changes and local/static validation are authorized. Do not run
`terraform init`, `terraform plan`, `terraform apply`, or any other external
infrastructure operation from this repository. The migration boundary and
remaining blockers are recorded in `docs/migration-continuation.md`.

Run the repository's offline safety checks with:

```bash
python3 -m unittest discover -s tests -v
```
