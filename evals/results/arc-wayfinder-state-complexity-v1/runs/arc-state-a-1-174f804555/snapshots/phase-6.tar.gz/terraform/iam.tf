# This role is used only by the dedicated ARC runner node group. It does not
# grant this module ownership of the existing EKS cluster or legacy resources.
data "aws_iam_policy_document" "runner_node_assume_role" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "runner_node" {
  name                 = "arc-runner-node"
  assume_role_policy   = data.aws_iam_policy_document.runner_node_assume_role.json
  permissions_boundary = var.permissions_boundary_arn
}

resource "aws_iam_role_policy_attachment" "runner_node_managed" {
  for_each = toset([
    "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy",
    "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryPullOnly",
    "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy",
  ])

  role       = aws_iam_role.runner_node.name
  policy_arn = each.value
}
