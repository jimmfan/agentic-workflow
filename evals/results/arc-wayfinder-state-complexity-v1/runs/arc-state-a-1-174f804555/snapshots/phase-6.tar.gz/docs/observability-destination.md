# Approved W4 observability destination

Status: approved destination input for repository implementation.

Configure the ARC failed-runner CloudWatch metric alarm to notify exactly:

`arn:aws:sns:us-east-1:123456789012:arc-runner-alerts`

This resolves the destination-only blocker. The failed-runner metric and alarm
semantics must be approved separately; this document does not authorize
guessing them. Repository and static validation are authorized once all alarm
inputs are specified; external infrastructure mutation remains unauthorized.
W3 legacy-resource ownership is unchanged and remains blocked.
