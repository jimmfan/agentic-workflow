# W4 observability requirement

The runner platform needs a CloudWatch metric alarm for failed runner jobs. The
alarm must notify the project-approved destination. The destination ARN is now
recorded in `docs/observability-destination.md`.

The metric namespace/name, dimensions, threshold, comparison operator, period,
statistic, and evaluation window are not documented. W4 is blocked until those
alarm inputs are approved. Do not invent an ARN or any alarm semantics. This
W4 blocker is independent and does not block W1 or W2.
