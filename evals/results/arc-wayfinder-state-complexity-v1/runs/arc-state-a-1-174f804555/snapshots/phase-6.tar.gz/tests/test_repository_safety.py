from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
TERRAFORM = "\n".join(
    path.read_text(encoding="utf-8")
    for path in sorted((ROOT / "terraform").glob("*.tf"))
)


class RepositorySafetyTests(unittest.TestCase):
    def test_runner_node_role_uses_the_required_boundary_and_ec2_trust(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'resource\s+"aws_iam_role"\s+"runner_node"[\s\S]*?'
            r'permissions_boundary\s*=\s*var\.permissions_boundary_arn',
        )
        self.assertRegex(
            TERRAFORM,
            r'data\s+"aws_iam_policy_document"\s+"runner_node_assume_role"'
            r'[\s\S]*?identifiers\s*=\s*\["ec2\.amazonaws\.com"\]',
        )

    def test_runner_node_role_has_required_managed_policies(self) -> None:
        for policy in (
            "AmazonEKSWorkerNodePolicy",
            "AmazonEC2ContainerRegistryPullOnly",
            "AmazonEKS_CNI_Policy",
        ):
            with self.subTest(policy=policy):
                self.assertIn(policy, TERRAFORM)

    def test_runner_ami_uses_the_platform_ssm_parameter(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'data\s+"aws_ssm_parameter"\s+"runner_ami"[\s\S]*?'
            r'name\s*=\s*"/platform/arc/runner-ami"',
        )

    def test_dedicated_runner_launch_template_uses_the_resolved_ami(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'resource\s+"aws_launch_template"\s+"runner_node"[\s\S]*?'
            r'image_id\s*=\s*data\.aws_ssm_parameter\.runner_ami\.value',
        )
        self.assertRegex(
            TERRAFORM,
            r'resource\s+"aws_launch_template"\s+"runner_node"[\s\S]*?'
            r'instance_type\s*=\s*"m7i\.xlarge"',
        )

    def test_runner_nodes_require_imdsv2(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'resource\s+"aws_launch_template"\s+"runner_node"[\s\S]*?'
            r'metadata_options\s*\{[\s\S]*?http_tokens\s*=\s*"required"',
        )

    def test_runner_node_group_uses_the_frozen_compute_contract(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'resource\s+"aws_eks_node_group"\s+"runner"[\s\S]*?'
            r'cluster_name\s*=\s*data\.aws_eks_cluster\.existing\.name',
        )
        self.assertRegex(
            TERRAFORM,
            r'resource\s+"aws_eks_node_group"\s+"runner"[\s\S]*?'
            r'subnet_ids\s*=\s*var\.private_subnet_ids',
        )
        self.assertRegex(
            TERRAFORM,
            r'resource\s+"aws_eks_node_group"\s+"runner"[\s\S]*?'
            r'capacity_type\s*=\s*"ON_DEMAND"',
        )
        self.assertRegex(
            TERRAFORM,
            r'scaling_config\s*\{[\s\S]*?min_size\s*=\s*2[\s\S]*?'
            r'desired_size\s*=\s*2[\s\S]*?max_size\s*=\s*6',
        )
        self.assertRegex(
            TERRAFORM,
            r'labels\s*=\s*\{[\s\S]*?workload\s*=\s*"arc-runner"',
        )
        self.assertRegex(
            TERRAFORM,
            r'taint\s*\{[\s\S]*?key\s*=\s*"dedicated"[\s\S]*?'
            r'value\s*=\s*"arc-runner"[\s\S]*?effect\s*=\s*"NO_SCHEDULE"',
        )

    def test_node_group_waits_for_node_role_policies(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'resource\s+"aws_eks_node_group"\s+"runner"[\s\S]*?'
            r'depends_on\s*=\s*\[aws_iam_role_policy_attachment\.runner_node_managed\]',
        )

    def test_node_group_uses_the_dedicated_launch_template(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'resource\s+"aws_eks_node_group"\s+"runner"[\s\S]*?'
            r'launch_template\s*\{[\s\S]*?'
            r'id\s*=\s*aws_launch_template\.runner_node\.id[\s\S]*?'
            r'version\s*=\s*aws_launch_template\.runner_node\.latest_version',
        )

    def test_externally_managed_cluster_is_not_recreated(self) -> None:
        self.assertIsNone(
            re.search(r'resource\s+"aws_eks_cluster"', TERRAFORM, re.IGNORECASE)
        )

    def test_public_ip_assignment_is_not_enabled(self) -> None:
        self.assertIsNone(
            re.search(
                r"(?:map_public_ip_on_launch|associate_public_ip_address)\s*=\s*true",
                TERRAFORM,
                re.IGNORECASE,
            )
        )

    def test_legacy_security_group_is_not_managed(self) -> None:
        self.assertNotIn("sg-0abc1234def567890", TERRAFORM)

    def test_karpenter_is_not_introduced(self) -> None:
        self.assertIsNone(re.search(r"karpenter\.sh|helm_release.*karpenter", TERRAFORM, re.IGNORECASE | re.DOTALL))

    def test_ami_is_not_hard_coded(self) -> None:
        self.assertIsNone(re.search(r"\bami-[0-9a-f]{8,17}\b", TERRAFORM, re.IGNORECASE))


if __name__ == "__main__":
    unittest.main()
