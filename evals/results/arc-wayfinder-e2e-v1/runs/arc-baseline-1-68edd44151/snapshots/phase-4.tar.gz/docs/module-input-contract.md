# ARC Terraform module input contract

## Purpose

The Terraform module must consume platform-owned resources without adopting or
changing them. This document makes the caller-facing input boundary explicit so
that malformed configuration fails locally before a future, separately
authorized Terraform plan performs any cloud reads.

The validation in `terraform/variables.tf` is deliberately structural. It does
not prove ownership, private-network classification, parameter contents, IAM
policy contents, cluster compatibility, or region availability. Those remain
external facts that require evidence from their respective owners.

## Inputs accepted by the module

| Input | Local validation | Caller must establish before an authorized plan | Ownership boundary |
| --- | --- | --- | --- |
| `cluster_name` | Non-empty value. | The named EKS cluster exists, is the intended target, and permits the required read access. | Platform-owned; read through `data.aws_eks_cluster.existing`; never created here. |
| `private_subnet_ids` | Non-empty, unique values in AWS subnet-ID form. | Each subnet is an approved private runner subnet, is in an approved AZ, and has the required EKS, DNS, ECR, SSM, and GitHub egress path. | Platform/network-owned; no subnet resource is managed here. |
| `permissions_boundary_arn` | IAM managed-policy ARN form, including supported AWS partitions. | The policy is the organization-approved boundary and its contents permit only the node-role permissions approved for the selected AMI/bootstrap contract. | Organization-owned; every future IAM role created here must reference it. |
| `runner_ami_ssm_parameter_name` | Absolute SSM parameter-name form with permitted characters. | The parameter is platform-owned, current, readable by the authorized planning identity, and has a value format compatible with the approved launch-template design. | Platform-owned; read through `data.aws_ssm_parameter.runner_ami`; no parameter is managed here. |

## Required evidence before the compute slice

Input validation does not unblock creation of a managed node group. The pending
contracts in [the migration handoff](migration-handoff.md) remain gates:

- D4 supplies the ARC/controller integration and runner-placement contract.
- D6 supplies the private-network and egress contract.
- D8 supplies the exact `m7i` type, AMI architecture/value format, quota, and
  availability evidence.

Record each resolution with its owner, date, source, exact value or interface,
and implementation effect in the handoff before adding compute or IAM
resources. This repository must not use a validation rule to turn an unresolved
external fact into an assumed configuration value.
