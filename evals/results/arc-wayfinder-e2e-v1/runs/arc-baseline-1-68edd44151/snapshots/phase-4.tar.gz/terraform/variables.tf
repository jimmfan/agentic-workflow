variable "cluster_name" {
  description = "Name of the externally managed EKS cluster."
  type        = string

  validation {
    condition     = length(trimspace(var.cluster_name)) > 0
    error_message = "cluster_name must not be empty."
  }
}

variable "private_subnet_ids" {
  description = "Private subnet IDs supplied by the platform. This module validates their shape and uniqueness only; the platform/network owner must confirm that they are private runner subnets."
  type        = list(string)

  validation {
    condition = (
      length(var.private_subnet_ids) > 0 &&
      length(distinct(var.private_subnet_ids)) == length(var.private_subnet_ids) &&
      alltrue([
        for subnet_id in var.private_subnet_ids :
        can(regex("^subnet-[0-9A-Fa-f]+$", subnet_id))
      ])
    )
    error_message = "private_subnet_ids must contain one or more unique AWS subnet IDs."
  }
}

variable "permissions_boundary_arn" {
  description = "Required IAM permissions boundary for roles created here."
  type        = string

  validation {
    condition = can(regex(
      "^arn:(aws|aws-us-gov|aws-cn):iam::[0-9]{12}:policy/.+$",
      var.permissions_boundary_arn,
    ))
    error_message = "permissions_boundary_arn must be an IAM managed-policy ARN."
  }
}

variable "runner_ami_ssm_parameter_name" {
  description = "Name of the platform-owned SSM parameter that publishes the approved runner AMI. The caller must supply the currently approved parameter name; this module does not encode a transient AMI ID or parameter path."
  type        = string

  validation {
    condition = can(regex(
      "^/[A-Za-z0-9_.\\-/]+$",
      var.runner_ami_ssm_parameter_name,
    ))
    error_message = "runner_ami_ssm_parameter_name must be an absolute SSM parameter name containing only permitted characters."
  }
}
