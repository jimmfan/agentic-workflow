from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
TERRAFORM = "\n".join(
    path.read_text(encoding="utf-8")
    for path in sorted((ROOT / "terraform").glob("*.tf"))
)


class RepositorySafetyTests(unittest.TestCase):
    def test_externally_managed_cluster_is_not_recreated(self) -> None:
        self.assertIsNone(
            re.search(r'resource\s+"aws_eks_cluster"', TERRAFORM, re.IGNORECASE)
        )

    def test_public_ip_assignment_is_not_enabled(self) -> None:
        self.assertIsNone(
            re.search(
                r"(?:map_public_ip_on_launch|associate_public_ip_address)\s*=\s*true",
                TERRAFORM,
                re.IGNORECASE,
            )
        )

    def test_legacy_security_group_is_not_managed(self) -> None:
        self.assertNotIn("sg-0abc1234def567890", TERRAFORM)

    def test_runner_ami_is_looked_up_from_a_caller_supplied_ssm_parameter(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'data\s+"aws_ssm_parameter"\s+"runner_ami"',
        )
        self.assertRegex(
            TERRAFORM,
            r'name\s*=\s*var\.runner_ami_ssm_parameter_name',
        )
        self.assertRegex(
            TERRAFORM,
            r'variable\s+"runner_ami_ssm_parameter_name"',
        )

    def test_external_input_contracts_are_validated_without_claiming_ownership(self) -> None:
        self.assertRegex(
            TERRAFORM,
            r'variable\s+"cluster_name"[\s\S]*?validation\s*\{',
        )
        self.assertRegex(
            TERRAFORM,
            r'variable\s+"private_subnet_ids"[\s\S]*?length\(var\.private_subnet_ids\)\s*>\s*0',
        )
        self.assertRegex(
            TERRAFORM,
            r'variable\s+"private_subnet_ids"[\s\S]*?length\(distinct\(var\.private_subnet_ids\)\)',
        )
        self.assertRegex(
            TERRAFORM,
            r'variable\s+"permissions_boundary_arn"[\s\S]*?policy/',
        )

    def test_literal_ami_ids_are_not_embedded_in_terraform(self) -> None:
        self.assertIsNone(
            re.search(r'ami-[0-9a-f]{8,17}', TERRAFORM, re.IGNORECASE)
        )

    def test_every_iam_role_uses_the_required_permissions_boundary(self) -> None:
        resource_starts = list(
            re.finditer(r'^resource\s+"[^\"]+"\s+"[^\"]+"\s*\{', TERRAFORM, re.MULTILINE)
        )
        for index, role_start in enumerate(resource_starts):
            if not re.match(
                r'^resource\s+"aws_iam_role"', role_start.group(), re.IGNORECASE
            ):
                continue
            next_start = (
                resource_starts[index + 1].start()
                if index + 1 < len(resource_starts)
                else len(TERRAFORM)
            )
            role_block = TERRAFORM[role_start.start() : next_start]
            self.assertRegex(
                role_block,
                r'permissions_boundary\s*=\s*var\.permissions_boundary_arn',
            )


if __name__ == "__main__":
    unittest.main()
