# ARC runner migration — durable handoff

**Purpose.** This is the continuity record for migrating ephemeral GitHub Actions
runner capacity onto the existing Amazon EKS platform. It records approved
decisions, benchmark evidence, outstanding contracts, and the next safe
implementation boundary. It is not approval to provision or mutate external
infrastructure.

**Recorded:** 2026-08-15 (repository evidence includes `fdb59f6`, *Evaluator
Phase 3 decision and benchmark evidence*). Revalidate time-sensitive platform
facts before an external plan or implementation.

## Current outcome and guardrails

The target service is ephemeral GitHub Actions runners on an existing EKS
platform. It must provide 99.9% monthly availability and make additional
**usable** runner capacity available within 60 seconds.

The approved initial compute architecture is dedicated runner capacity on EKS
managed node groups using the `m7i` instance family. Karpenter is not part of
the initial rollout, and the initial warm capacity is two nodes.

The following constraints apply to every remaining implementation task:

- Runners use private networking; neither instances nor pods may receive public
  IP addresses.
- Every runner IAM role uses the supplied organization permissions boundary.
- The runner AMI is resolved through the platform-owned SSM parameter, never a
  literal AMI ID.
- Infrastructure owned outside this repository must not be recreated, imported,
  deleted, or silently adopted.
- The EKS cluster is externally managed. The module receives its name as input
  and reads it; it must not create the cluster.
- Repository changes and offline validation are authorized. External
  infrastructure mutation, including `terraform apply`, is not authorized.

## Evidence register

| Area | Known fact | Source and confidence | Consequence |
| --- | --- | --- | --- |
| Compute architecture | Initial rollout uses dedicated capacity, EKS managed node groups, `m7i`, no Karpenter, and two warm nodes. | `docs/decisions/D1-runner-compute-architecture.md`; approved. | Implement one dedicated managed-node-group path after the remaining integration contracts are known. Do not add Karpenter or a shared runner pool as a hedge. |
| Startup performance | Cold capacity measured p50 49 s, p95 86 s, p99 103 s. With two warm nodes it measured p50 18 s, p95 41 s, p99 54 s. | `docs/benchmarks/runner-startup.md`; benchmark evidence, not a production guarantee. | Cold scale-out does not meet the 60-second target at p95 or p99. Preserve two warm nodes in the initial design and validate the result in the target environment. |
| Cold-start cause | EC2/node availability accounts for 55–75 s of a cold start; pod scheduling takes 5–8 s and runner registration 7–12 s. | `docs/benchmarks/runner-startup.md`; measured decomposition. | The primary SLO risk is new-node availability. Optimizing pod scheduling or registration alone cannot make cold starts reliably meet 60 s. |
| Cluster | An EKS cluster already exists and is externally managed. | `docs/requirements.md` and `terraform/main.tf`; high within stated scope. | Retain `data "aws_eks_cluster" "existing"`; never add an `aws_eks_cluster` resource here. |
| Network | Runner subnets are private and supplied as module input. | `docs/requirements.md` and `terraform/variables.tf`; high. | Consume `var.private_subnet_ids`; implementation must avoid public-IP settings. |
| AMI | The approved AMI is published through a platform-owned SSM parameter. Its current name and value format still need confirmation. | Requirements and current Terraform are authoritative for the lookup; the removed transient inventory is not authoritative for path/value details. | Keep the caller-supplied SSM lookup. Do not hard-code an AMI ID or historical parameter path; confirm the parameter contract before consuming its value in a launch template. |
| IAM | Newly created runner roles require the supplied permissions boundary. | `docs/security-requirements.md` and `terraform/variables.tf`; high. | Every new `aws_iam_role` must set `var.permissions_boundary_arn`. |
| Existing security group | `sg-0abc1234def567890` is tagged `component=arc-legacy`, but ownership is unknown. | `docs/existing-resources.md`; observed, not attributable. | Do not reference, import, modify, delete, or infer ownership of it. |
| Module state | Terraform currently has provider constraints, a cluster data source, four inputs, and an AMI SSM lookup; it has no compute or IAM resources. | `terraform/*.tf`; high. | The next infrastructure slice has deliberately not been implemented. |
| Safety checks | Static tests prohibit cluster creation, explicit public-IP enablement, management of the legacy security group, literal AMI IDs, and IAM roles without the required boundary. | `tests/test_repository_safety.py`; high. | Retain and extend these offline protections as Terraform is added. |

## Resolved decisions

| ID | Decision | Status and source | Implementation effect |
| --- | --- | --- | --- |
| D1 | Runner instance family | **Resolved:** `m7i`. `docs/decisions/D1-runner-compute-architecture.md`. | Use an approved `m7i` size in the dedicated node group once exact size, architecture/AMI compatibility, quotas, and availability are confirmed. The family decision is not approval to guess a size. |
| D2 | Shared versus dedicated runner compute | **Resolved:** dedicated runner capacity. Decision record above. | Create isolation boundaries appropriate to a dedicated node group (labels/taints and runner placement only when the ARC contract supplies the consuming workloads). |
| D3 | Provisioning model | **Resolved:** EKS managed node groups; no Karpenter in the initial rollout. Decision record above. | Build only the managed-node-group path. Do not create Karpenter resources, permissions, or an alternate node-pool path. |
| D7 | Initial warm capacity | **Resolved:** two nodes. Decision record, supported by the benchmark. | Configure and test an initial two-node warm baseline. Treat warm capacity as the mechanism for the 60-second requirement, pending target-environment validation. |

## What the benchmark changes

The benchmark replaces the prior assumption that cold elastic capacity could
satisfy the 60-second requirement. It cannot: observed cold p95 (86 seconds)
and p99 (103 seconds) exceed the target, and node availability alone is often
55–75 seconds.

The two-warm-node result is the current implementation basis because its
observed p99 is 54 seconds. It is not sufficient evidence of a production SLO
by itself: the benchmark does not record sample count, workload mix, region/AZ,
instance size, AMI/version, ARC/controller version, contention, failure mode,
or the exact definition of the start/end clock. Capture those details and
repeat the measurement in the approved target environment before claiming
compliance.

```text
Demand served by either:
  warm dedicated node (two-node baseline) ──> measured p99 54 s ──> target supported
  new managed-node-group node              ──> measured p95 86 s ──> not an SLO path
```

Cold scale-out remains useful for sustained demand, but it is not the mechanism
for the first additional usable runner within the stated target. The still-open
GitHub scale policy must determine the runner/pod capacity that two warm nodes
reserve and what happens when that reserve is exhausted.

## Remaining unresolved decisions and dependency gates

| ID | Open item | Blocks | Needed owner/evidence |
| --- | --- | --- | --- |
| D4 | ARC/controller ownership and integration contract | Kubernetes resources, runner CRs, namespace/service account boundaries, GitHub credentials/secrets, runner placement configuration. | ARC/platform owner supplies the current controller deployment, version, namespace, ownership boundary, and supported runner-resource contract. |
| D5 | GitHub runner scope and scaling policy | Runner group configuration, labels, authentication, minimum/maximum runner capacity, capacity reserved by the two warm nodes, validation criteria, and behavior after warm capacity is exhausted. | CI/GitHub owner supplies organizations/repositories, runner groups, workload/concurrency profile, credentials model, and SLO measurement definition. |
| D6 | Network and egress contract | Node security groups, network policies, endpoints/NAT, DNS, GitHub/SSM/ECR access, and node/pod bootstrap. | Network/security owner supplies approved connectivity paths and controls. |
| D8 | Exact `m7i` node specification and platform feasibility | Managed node group launch template, AMI architecture compatibility, node capacity model, subnet/AZ placement, quotas, cost estimate, and benchmark reproducibility. | Platform/capacity owner approves the exact `m7i` type(s), architecture, supported AMI value format, EKS/AMI compatibility, quotas, and target-region/AZ availability. |
| D9 | Production benchmark protocol | SLO acceptance and operational monitoring. | CI/platform owners agree on the clock boundaries for “usable”, percentile/sample window, load profile, telemetry source, and failure/availability scenarios. |

The resolved compute choices make the managed-node-group slice actionable once
D4, D6, and D8 provide its integration, network, and launch details. D5 and
D9 are required before declaring the end-to-end runner service or the 60-second
SLO complete.

## Actionable work for the next implementation agent

This phase intentionally stops before the infrastructure slice. A fresh agent
may take the following work, in this order, without reopening the resolved
architecture decision:

1. **Reconcile the remaining contracts.** Obtain and record D4, D6, and D8
   before writing managed-node-group resources. Obtain D5 and D9 in parallel
   for the runner scale and acceptance design. Preserve source, owner, and date
   for each fact rather than converting an assumption into configuration.
2. **Design the dedicated managed-node-group slice.** Once D4/D6/D8 are
   documented, add only the selected EKS managed-node-group and its required
   launch/IAM configuration. Its baseline must retain two warm nodes and use
   private subnet inputs, the SSM-resolved AMI, the approved `m7i` type, and
   dedicated placement controls. Do not add Karpenter, a shared worker group,
   or the legacy security group.
3. **Add the least-privilege node role.** Derive permissions from the approved
   AMI/bootstrap, EKS, ECR, and network contract; set the required permissions
   boundary. Do not substitute broad guessed policies for the missing contract.
4. **Extend offline guardrails and module documentation.** Test the managed
   node group for private networking, SSM AMI provenance, two-node warm
   baseline, required IAM boundary, dedicated placement, and non-adoption of
   external resources. Document all caller inputs and ownership boundaries.
5. **Implement ARC and GitHub integration only after D4/D5.** Configure only
   the approved controller-owned interface, runner groups, credentials model,
   labels, and limits. Make runner placement consume the dedicated nodes.
6. **Validate progressively.** Run offline format/validation/tests first. Then
   obtain explicit authorization for any external read-only plan and a separate
   non-production rollout. Use D9’s protocol to re-run warm and cold capacity
   measurements; do not claim the SLO from the existing benchmark alone.

## Exact continuation context

Begin with a clean review of `README.md`, this handoff,
`docs/requirements.md`, `docs/security-requirements.md`,
`docs/decisions/D1-runner-compute-architecture.md`,
`docs/benchmarks/runner-startup.md`, and `docs/existing-resources.md`.
`docs/old-architecture-notes.md` is historical only. The transient platform
inventory was removed in `dfc9082`; do not restore its values as current facts.

Before editing Terraform, inspect `git status --short` from a shell whose
working directory is the repository root. This is read-only and identifies
pre-existing work; current repository state may include uncommitted migration
changes. Do not overwrite or revert unrelated changes.

After documentation or future code changes, run the following in that same
repository-root shell. It is offline and makes no persistent or external
change:

```bash
python3 -m unittest discover -s tests -v
```

Expected current result: six passing `RepositorySafetyTests` tests. If a future
change fails, identify the Terraform text that violated the guardrail; do not
weaken the test to allow an unsafe resource.

If Terraform is installed, run the following from the same repository-root
shell to check formatting only; it makes no change:

```bash
terraform -chdir=terraform fmt -check -recursive
```

A normal `terraform plan` can contact cloud APIs. Do not run it until an
explicitly authorized, safe read-only plan and all required inputs are
available. Never run `terraform apply` in this migration phase.

## Maintenance rule

When an open item is resolved, update its row with the exact choice, owner,
date, source, and implementation effect. When benchmark evidence is refreshed,
retain the environment and protocol beside the numbers. When platform facts
are refreshed, preserve the old fact with its date or explicitly mark it
 superseded—do not silently overwrite the evidence trail.
