# ARC runner migration — durable handoff

**Purpose.** This document is the continuity record for migrating ephemeral
GitHub Actions runner capacity onto the existing Amazon EKS platform. It is a
planning record, not an approval to provision infrastructure. It separates
verified repository evidence from open decisions so a new engineer can resume
without treating a proposal, old POC, or observed external resource as a
directive.

**Recorded:** 2026-08-15 (repository state: `180666f`, `main`). Revalidate
time-sensitive platform facts before an implementation or external plan.

## Current outcome and guardrails

The desired service is ephemeral GitHub Actions runners on an existing EKS
platform. The migration must support a 99.9% monthly availability target and
make additional usable runner capacity available within 60 seconds.

The following are non-negotiable constraints from the current requirements:

- Runners use private networking; neither instances nor pods may receive public
  IP addresses.
- Runner IAM roles use the supplied organization permissions boundary.
- The runner AMI is resolved through the platform-owned SSM parameter, never a
  literal AMI ID.
- Infrastructure owned outside this repository must not be recreated, imported,
  deleted, or silently adopted.
- The EKS cluster is externally managed. The module receives its name as input
  and reads it; it must not create the cluster.
- External infrastructure mutation is not authorized in this phase. In
  particular, do not run `terraform apply`.

## Evidence register

| Area | Known fact | Source and confidence | Consequence |
| --- | --- | --- | --- |
| Cluster | An EKS cluster already exists and is externally managed. | `docs/platform-facts.md`, current inventory export (2026-08-14); high within stated scope. | Keep `data "aws_eks_cluster" "existing"`; never add an `aws_eks_cluster` resource here. |
| Network | Runner subnets are private and supplied as module input. | `docs/platform-facts.md`; `terraform/variables.tf`; high. | Consume `var.private_subnet_ids`; implementation must avoid public-IP settings. |
| AMI | The approved AMI is published at `/platform/arc/runner-ami`. | `docs/platform-facts.md`; high, but transient inventory. | Add an SSM data lookup when implementation is authorized; do not copy an AMI ID into code. |
| IAM | Newly created runner roles require the supplied permissions boundary. | `docs/platform-facts.md`, `docs/security-requirements.md`, and `terraform/variables.tf`; high. | Role design can proceed before compute decisions; every role must set `var.permissions_boundary_arn`. |
| Existing SG | `sg-0abc1234def567890` is tagged `component=arc-legacy`, but ownership is unknown. | `docs/existing-resources.md`; observed, not attributable. | Do not reference, import, modify, delete, or infer ownership of it. |
| Module state | Terraform presently has provider constraints, cluster data source, three inputs, and TODOs for IAM/AMI; no compute resources. | `terraform/*.tf`; high. | This is intentionally incomplete. No migration infrastructure has been implemented. |
| Safety checks | Static tests prohibit cluster creation, explicit public-IP enablement, and management of the legacy SG. | `tests/test_repository_safety.py`; high. | Retain and extend these protections as new Terraform is added. |

## Stale, uncertain, and non-authoritative material

- `docs/old-architecture-notes.md` is explicitly superseded. Its 2024
  recommendation for `m6i` in a shared worker group is historical only and
  cannot be used as an approval.
- `docs/compute-options.md` says the platform team is considering `m7i`; that
  is a proposal, not a decision.
- The 2026-08-14 platform inventory is described as transient and may be
  replaced after the migration starts. Confirm cluster inputs, subnet privacy,
  SSM parameter availability/value semantics, and the permissions-boundary ARN
  with the current platform owner before external planning.
- No repository evidence identifies the GitHub organization/repositories,
  runner groups, runner scale policy, controller installation/ownership,
  network egress/DNS dependencies, observability destination, or AMI parameter
  format. These are unknowns, not safe defaults.

## Decision register and dependency gates

| ID | Blocking decision | Current status | Blocks | Needed decision owner/evidence |
| --- | --- | --- | --- | --- |
| D1 | Runner instance family and sizing | Unresolved; `m7i` only under consideration. | Compute launch configuration, capacity modelling, cost estimate, AMI/architecture compatibility checks. | Platform/capacity owner approves family, sizes, architecture, quotas, and availability rationale. |
| D2 | Shared versus dedicated runner compute | Unresolved. | Isolation policy, node labels/taints, security boundaries, capacity placement, operational ownership. | Platform plus security/workload owners document the isolation decision and accepted risks. |
| D3 | Karpenter versus EKS managed node groups | Unresolved. | Provisioning resources, scaling/control-plane integration, IAM, observability, availability design, rollout/runbook. | EKS/platform owner approves the provisioning model and confirms whether it is already installed/externally managed. |
| D4 | ARC/controller ownership and integration contract | Unknown. | Whether this module creates controller resources, runner CRs, Kubernetes access, and GitHub credentials/secrets. | ARC/platform owner provides current controller deployment, version, namespace, and ownership boundary. |
| D5 | GitHub runner scope and scaling policy | Unknown. | Runner group configuration, minimum/maximum capacity, labels, authentication, validation criteria, and 60-second design. | CI/GitHub service owner supplies repos/orgs, runner groups, workload profile, credentials model, and SLO measurement. |
| D6 | Network and egress contract | Unknown beyond private addressing. | Security groups/network policies, endpoints/NAT, DNS, GitHub/SSM/ECR access, and pod/instance bootstrap. | Network/security owner supplies approved connectivity paths and controls. |

### Dependency order

```text
D4 controller contract ─┐
D5 GitHub/scaling scope ├─> ARC runner configuration and acceptance tests
D6 network/egress ──────┤
                        └─> secure end-to-end design

D1 family/sizing ───────┐
D2 isolation model ─────┼─> D3 provisioning choice ─> compute implementation
D6 network/egress ──────┘

Existing constraints (private subnets, SSM AMI, IAM boundary, external EKS)
apply to every implementation path and do not themselves select one.
```

Do not resolve D3 by implementation convenience: its operational model depends
on the approved isolation and capacity design. D4–D6 are also required before
declaring that a chosen compute design can actually register and serve runners.

## Useful work that may proceed now

The following work is safe because it implements or documents existing
constraints without choosing a compute architecture or mutating external state.

1. **Design the least-privilege runner-node IAM role.** Define the required
   permissions from the approved AMI/bootstrap and EKS integration contract;
   encode the supplied permissions boundary and write static tests for it.
   Do not guess broad policies or create the role until its consumers are known.
2. **Add SSM AMI resolution plumbing.** Implement a data source for
   `/platform/arc/runner-ami`, with validation/documentation of the parameter
   format once the platform owner confirms it. Do not wire it to a launch
   resource until D1–D3 are decided.
3. **Strengthen offline safety coverage.** Add checks that future resources use
   the permissions boundary, do not hard-code AMIs, retain private networking,
   and do not manage externally owned resources. These checks must remain
   static/offline.
4. **Create architecture-neutral interfaces and documentation.** Document
   input contracts, ownership boundaries, naming/tagging expectations, and a
   decision log. Avoid adding inputs that encode an unapproved provisioner.
5. **Collect decision evidence (read-only).** Request the specific artifacts
   listed in the decision register: scale/workload profile, controller facts,
   network contract, current inventory confirmation, and approvals. Record the
   source/date/owner beside each result rather than replacing uncertainty with
   inference.
6. **Draft test and observability criteria.** Define how “usable capacity within
   60 seconds” will be measured (trigger, clock start/end, sample size,
   telemetry), along with availability, private-addressing, AMI provenance, and
   IAM-boundary acceptance checks. The exact implementation waits on D1–D6.

## Suggested implementation phases after approvals

1. **Confirm the inputs and ownership boundaries.** Refresh the transient
   platform inventory and capture D1–D6 approvals. This prevents a Terraform
   design from adopting external platform resources or targeting the wrong
   controller/network contract.
2. **Implement architecture-neutral controls.** Add the IAM role and SSM AMI
   data lookup with static tests. These establish security provenance before
   compute is introduced.
3. **Implement the approved compute path.** Build only the selected Karpenter
   or managed-node-group path, using private subnet inputs and the approved
   isolation/sizing design. Do not leave both provisioners active as a hedge.
4. **Implement ARC integration and scale controls.** Configure the approved
   controller contract, GitHub scope, runner groups, credentials, and limits.
5. **Validate progressively.** First run offline format/validation/tests; then
   obtain explicit authorization for any external read-only plan; finally use a
   separately authorized non-production rollout and SLO/scale tests. `apply`
   remains prohibited until that authorization exists.

## Exact continuation context

Start from a clean review of `README.md`, this file, `docs/requirements.md`,
`docs/platform-facts.md`, `docs/security-requirements.md`, and
`docs/existing-resources.md`. Treat `docs/old-architecture-notes.md` as history
only. The only commit currently in the repository is `180666f` (`Initial ARC
evaluation fixture`); this handoff was added afterwards and must be committed
with any review-approved planning change.

Before changing Terraform, inspect `git status --short` from a terminal whose
working directory is the repository root. It is read-only and reveals whether a
previous engineer left work in progress. Run the following offline verification
from that same repository-root shell after documentation or code changes; it
makes no persistent or external change:

```bash
python3 -m unittest discover -s tests -v
```

Expected current result: three passing `RepositorySafetyTests` tests. If it
fails after a future change, first identify which guardrail the Terraform text
violated; do not weaken the test to make an unsafe resource pass.

If Terraform is installed, `terraform -chdir=terraform fmt -check -recursive`
is a local formatting check and makes no change. A normal `terraform plan` can
contact cloud APIs, so do not run it merely because the README calls it
permitted conditionally; first establish that it has no external effect and
that all required credentials/inputs are safe and authorized. Never run
`terraform apply` in this migration phase.

## Maintenance rule

When a decision is made, update its row above with the owner, date, source,
and exact approved choice; move only the work it unblocks into an active
implementation plan. When platform facts are refreshed, preserve the old fact
with its date or explicitly mark it superseded—do not silently overwrite the
evidence trail.
