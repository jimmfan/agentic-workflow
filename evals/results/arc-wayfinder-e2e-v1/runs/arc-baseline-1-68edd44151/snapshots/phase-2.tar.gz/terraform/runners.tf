# The approved runner AMI is owned and published by the platform. This lookup
# deliberately does not interpret the parameter value: AMI parameter format and
# the compute consumer remain pending the approved runner-compute design.
data "aws_ssm_parameter" "runner_ami" {
  name = var.runner_ami_ssm_parameter_name
}

# Compute resources must wait for approved instance-family, isolation, and
# provisioning decisions.
