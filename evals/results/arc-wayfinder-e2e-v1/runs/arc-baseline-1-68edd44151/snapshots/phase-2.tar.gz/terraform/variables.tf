variable "cluster_name" {
  description = "Name of the externally managed EKS cluster."
  type        = string
}

variable "private_subnet_ids" {
  description = "Private subnet IDs supplied by the platform."
  type        = list(string)
}

variable "permissions_boundary_arn" {
  description = "Required IAM permissions boundary for roles created here."
  type        = string
}

variable "runner_ami_ssm_parameter_name" {
  description = "Name of the platform-owned SSM parameter that publishes the approved runner AMI. The caller must supply the currently approved parameter name; this module does not encode a transient AMI ID or parameter path."
  type        = string

  validation {
    condition     = startswith(var.runner_ami_ssm_parameter_name, "/")
    error_message = "runner_ami_ssm_parameter_name must be an absolute SSM parameter name beginning with '/'."
  }
}
