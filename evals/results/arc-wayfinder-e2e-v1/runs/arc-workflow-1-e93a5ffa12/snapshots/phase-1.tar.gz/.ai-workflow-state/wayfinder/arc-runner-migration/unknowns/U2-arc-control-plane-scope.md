# U2: Define ARC control-plane and lifecycle scope

- Status: open
- Resolution mode: human clarification
- Blocked by: none
- Related: [U1 — Choose runner compute architecture](U1-runner-compute-architecture.md), [U3 — Define runner IAM responsibilities and least privilege](U3-runner-iam-least-privilege.md)

## Question

What is this Terraform module responsible for managing in the ARC runner
lifecycle: only runner compute prerequisites, or also ARC controller,
runner-scale-set, GitHub registration, and workload deployment resources? For
each excluded part, which platform or team owns it?

## Evidence

- [Requirements](../../../../docs/requirements.md) names ephemeral GitHub
  Actions runners on an existing EKS platform, but does not state the ARC
  controller version, installation mechanism, GitHub integration boundary, or
  resource ownership split.
- `terraform/main.tf` reads an existing cluster, and the comments in
  `terraform/iam.tf` and `terraform/runners.tf` describe only incomplete node
  IAM and AMI work. They do not establish an ARC deployment scope.
- [Platform facts](../../../../docs/platform-facts.md) confirms the cluster is
  externally managed and must not be created here.

## Resolution

Open. Obtain an explicit ownership and managed-resource boundary from the
platform/ARC owner. This determines resource types, workload identity, network
interfaces, lifecycle tests, and the IAM roles that may be created.
