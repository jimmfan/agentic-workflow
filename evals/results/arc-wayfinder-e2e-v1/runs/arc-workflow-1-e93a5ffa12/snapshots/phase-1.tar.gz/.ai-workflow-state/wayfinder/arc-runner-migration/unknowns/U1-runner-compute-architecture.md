# U1: Choose runner compute architecture

- Status: open
- Resolution mode: human clarification
- Blocked by: none
- Related: [U2 — Define ARC control-plane and lifecycle scope](U2-arc-control-plane-scope.md)

## Question

Which approved compute architecture will supply ephemeral ARC runner capacity:
which instance family, whether runner compute is shared or dedicated, and
whether capacity is provisioned through Karpenter or EKS managed node groups?
The answer must include the architecture's credible path to making additional
usable capacity available within 60 seconds.

## Evidence

- [Compute options](../../../../docs/compute-options.md) identifies all three
  selections as unresolved; `m7i` is only under consideration.
- [Platform facts](../../../../docs/platform-facts.md) explicitly does not
  approve instance family, isolation model, or provisioning mechanism.
- [Requirements](../../../../docs/requirements.md) requires 99.9% monthly
  availability, additional usable capacity within 60 seconds, and private
  networking.
- The 2024 `m6i` shared-worker-group recommendation is stale and unapproved;
  see [old architecture notes](../../../../docs/old-architecture-notes.md).

## Resolution

Open. A platform owner must approve the coupled compute choices and the
evidence or measurement standard for the 60-second capacity target. This blocks
the design of compute resources, their scaling configuration, and their
acceptance tests.
