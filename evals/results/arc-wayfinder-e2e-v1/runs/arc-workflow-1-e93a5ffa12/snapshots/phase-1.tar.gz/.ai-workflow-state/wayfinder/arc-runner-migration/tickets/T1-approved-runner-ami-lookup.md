# T1: Resolve the approved runner AMI through SSM

- Status: ready
- Blocked by: none
- Related: [U3 — Define runner IAM responsibilities and least privilege](../unknowns/U3-runner-iam-least-privilege.md)

## Outcome

The Terraform module reads the runner AMI identifier from the approved
platform-owned SSM parameter `/platform/arc/runner-ami`, without hard-coding an
AMI ID and without creating or mutating infrastructure.

## Acceptance

- Terraform declares a read-only SSM parameter data source for
  `/platform/arc/runner-ami`.
- No literal AMI ID is introduced.
- Offline repository safety tests continue to pass.
- A later compute-resource ticket consumes the lookup only after U1 is
  resolved.

## Notes

This work is independently useful and is explicitly identified as not waiting
on compute architecture in `terraform/runners.tf`. It is ready for a later,
separately authorized implementation session; it is not part of this planning
phase.
