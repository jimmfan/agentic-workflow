# ARC runner migration

## Destination

Make the route to a safe implementation of ephemeral GitHub Actions runner
capacity on the existing EKS platform clear: its approved architecture,
ownership boundaries, security constraints, and independently executable work
must be known well enough to plan implementation without reopening material
decisions.

## Notes

- This is a planning-only effort. Do not run `terraform apply` or mutate
  external infrastructure. Repository changes and offline validation are
  authorized once implementation is separately requested.
- Repository truth: [requirements](../../../docs/requirements.md),
  [security requirements](../../../docs/security-requirements.md), and
  [platform facts](../../../docs/platform-facts.md). The platform facts were
  exported on 2026-08-14 and are a transient snapshot; revalidate any fact that
  affects an external action when implementation begins.
- [Old architecture notes](../../../docs/old-architecture-notes.md) are stale
  historical material, not an approval. In particular, the 2024 `m6i` shared
  worker-group proposal must not guide current design.
- The current frontier is [U1 — Choose runner compute architecture](unknowns/U1-runner-compute-architecture.md)
  and [U2 — Define ARC control-plane and lifecycle scope](unknowns/U2-arc-control-plane-scope.md).
  [T1 — Resolve the approved runner AMI through SSM](tickets/T1-approved-runner-ami-lookup.md)
  is ready once implementation is authorized; it is deliberately not being
  implemented during this planning phase.

## Decisions so far

<!-- No project decision has been accepted in this effort. -->

## Not yet specified

- After the compute architecture and ARC scope are settled, specify the
  scale-up validation, observability, failure handling, and capacity-sizing
  work needed to demonstrate the 60-second additional-capacity requirement.
- Determine the required networking controls and any security-group work only
  after the selected runtime topology shows what is needed. The observed
  `component=arc-legacy` security group remains outside this effort unless
  ownership is established and a new authorization is given.
- Specify Terraform state, CI credentials, and deployment workflow only after
  the managed-resource boundary is clear; the repository supplies no canonical
  backend or delivery process.

## Out of scope

- Creating, importing, changing, deleting, or otherwise taking control of the
  externally managed EKS cluster.
- Importing, modifying, deleting, or assuming ownership of the observed legacy
  security group (`sg-0abc1234def567890`) without owner evidence and separate
  authorization.
- External infrastructure mutation, including `terraform apply`, during this
  Wayfinder effort.
- Reinstating the superseded 2024 `m6i` shared-worker-group proposal as a
  current decision.
