# The runner AMI is owned and published by the platform team. Compute resources
# may consume this lookup after their architecture is approved.
data "aws_ssm_parameter" "runner_ami" {
  name = "/platform/arc/runner-ami"
}

# TODO: create runner compute only after the instance-family, isolation, and
# provisioning decisions are approved.
