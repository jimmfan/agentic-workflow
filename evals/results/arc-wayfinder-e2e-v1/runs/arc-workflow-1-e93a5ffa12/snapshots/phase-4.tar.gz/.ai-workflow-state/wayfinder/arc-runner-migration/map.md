# ARC runner migration

## Destination

Make the route to a safe implementation of ephemeral GitHub Actions runner
capacity on the existing EKS platform clear: its approved architecture,
ownership boundaries, security constraints, and independently executable work
must be known well enough to plan implementation without reopening material
decisions.

## Notes

- This is a planning-only effort. Do not run `terraform apply` or mutate
  external infrastructure. Repository changes and offline validation are
  authorized once implementation is separately requested.
- Repository truth: [requirements](../../../docs/requirements.md),
  [security requirements](../../../docs/security-requirements.md), the approved
  [compute decision](../../../docs/decisions/D1-runner-compute-architecture.md),
  and the [runner startup benchmark](../../../docs/benchmarks/runner-startup.md).
  Revalidate any live platform fact that affects an external action when
  implementation begins; there is no current `docs/platform-facts.md` artifact
  in this repository.
- [Old architecture notes](../../../docs/old-architecture-notes.md) are stale
  historical material, not an approval. In particular, the 2024 `m6i` shared
  worker-group proposal must not guide current design.
- The current frontier is [U2 — Define ARC control-plane and lifecycle scope](unknowns/U2-arc-control-plane-scope.md).
  [U3 — Define runner IAM responsibilities and least privilege](unknowns/U3-runner-iam-least-privilege.md)
  and [T2 — Provision dedicated warm runner capacity](tickets/T2-provision-dedicated-warm-runner-capacity.md)
  are blocked by that boundary. [T1 — Resolve the approved runner AMI through SSM](tickets/T1-approved-runner-ami-lookup.md)
  is complete and is available for T2 to consume once its blockers resolve.

## Decisions so far

- [D1 — Adopt dedicated m7i managed-node-group runner capacity](decisions/D1-runner-compute-architecture.md) — use dedicated `m7i` managed-node-group capacity, no Karpenter, and keep two warm nodes because cold capacity misses the target at p95/p99.

## Not yet specified

- After the control-plane scope and IAM model are settled, specify the
  post-provisioning scale-up validation, observability, failure handling, and
  capacity-sizing work. The startup benchmark establishes two warm nodes as the
  initial normal-path strategy, but does not define production load, failure,
  or alerting thresholds.
- Determine the required networking controls and any security-group work only
  after the selected runtime topology shows what is needed. The observed
  `component=arc-legacy` security group remains outside this effort unless
  ownership is established and a new authorization is given.
- Specify Terraform state, CI credentials, and deployment workflow only after
  the managed-resource boundary is clear; the repository supplies no canonical
  backend or delivery process.

## Out of scope

- Creating, importing, changing, deleting, or otherwise taking control of the
  externally managed EKS cluster.
- Importing, modifying, deleting, or assuming ownership of the observed legacy
  security group (`sg-0abc1234def567890`) without owner evidence and separate
  authorization.
- External infrastructure mutation, including `terraform apply`, during this
  Wayfinder effort.
- Reinstating the superseded 2024 `m6i` shared-worker-group proposal as a
  current decision.
