# D1: Adopt dedicated m7i managed-node-group runner capacity

- Related: [U1 — Choose runner compute architecture](../unknowns/U1-runner-compute-architecture.md), [T2 — Provision dedicated warm runner capacity](../tickets/T2-provision-dedicated-warm-runner-capacity.md)

## Decision

For the initial ARC rollout, use dedicated runner capacity on EKS managed node
groups with the `m7i` instance family. Do not use Karpenter. Maintain an
initial warm capacity of two nodes.

## Why

The approved project decision in
[`docs/decisions/D1-runner-compute-architecture.md`](../../../../docs/decisions/D1-runner-compute-architecture.md)
settles the instance family, isolation, provisioning mechanism, and initial
warm capacity. The startup benchmark shows that cold capacity is not credible
for the 60-second requirement (p95 86 seconds; p99 103 seconds), while two
warm nodes measured p99 54 seconds.

## Consequences

- The next compute slice must create dedicated private runner capacity as an
  EKS managed node group using `m7i`, retaining two warm nodes; it must not
  revive the stale `m6i` shared-worker-group proposal or add Karpenter.
- The 60-second requirement must be evaluated with warm capacity in place;
  cold-node provisioning is not an acceptable normal-path capacity strategy.
- This does not decide the ARC control-plane ownership boundary, workload
  identity, or least-privilege IAM policy. Those remain prerequisites for
  implementation.
