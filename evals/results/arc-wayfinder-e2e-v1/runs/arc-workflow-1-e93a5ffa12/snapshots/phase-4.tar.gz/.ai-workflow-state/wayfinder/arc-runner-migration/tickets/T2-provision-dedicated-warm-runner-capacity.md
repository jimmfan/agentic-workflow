# T2: Provision dedicated warm runner capacity

- Status: blocked
- Blocked by: [U2 — Define ARC control-plane and lifecycle scope](../unknowns/U2-arc-control-plane-scope.md), [U3 — Define runner IAM responsibilities and least privilege](../unknowns/U3-runner-iam-least-privilege.md)
- Related: [D1 — Adopt dedicated m7i managed-node-group runner capacity](../decisions/D1-runner-compute-architecture.md), [T1 — Resolve the approved runner AMI through SSM](T1-approved-runner-ami-lookup.md)

## Outcome

Create the Terraform-managed runner-compute prerequisites that are in this
module's confirmed ownership boundary: a dedicated, private `m7i` EKS managed
node group with an initial warm capacity of two nodes, consuming the existing
approved SSM AMI lookup and only the IAM identity established by U3.

## Acceptance

- The managed-resource boundary from U2 is observed; no ARC controller,
  GitHub registration, legacy security group, cluster, or externally managed
  resource is imported or assumed under management.
- Runner compute uses dedicated `m7i` EKS managed-node-group capacity in the
  supplied private subnets, with no public IP assignment and an initial warm
  capacity of two nodes.
- The node identity and every role created by the module follow U3 and apply
  `var.permissions_boundary_arn` where required.
- The runner AMI is consumed only through the existing
  `/platform/arc/runner-ami` SSM data source; no literal AMI ID is added.
- Offline Terraform and repository safety validation pass. Before an external
  apply, revalidate any live platform inputs and demonstrate that usable
  additional capacity is available within 60 seconds with the warm-capacity
  strategy.
