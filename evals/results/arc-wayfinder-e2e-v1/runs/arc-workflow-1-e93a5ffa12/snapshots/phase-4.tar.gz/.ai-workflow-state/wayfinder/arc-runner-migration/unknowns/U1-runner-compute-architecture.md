# U1: Choose runner compute architecture

- Status: resolved
- Resolution mode: human clarification
- Blocked by: none
- Related: [U2 — Define ARC control-plane and lifecycle scope](U2-arc-control-plane-scope.md)

## Question

Which approved compute architecture will supply ephemeral ARC runner capacity:
which instance family, whether runner compute is shared or dedicated, and
whether capacity is provisioned through Karpenter or EKS managed node groups?
The answer must include the architecture's credible path to making additional
usable capacity available within 60 seconds.

## Evidence

- [Approved compute decision](../../../../docs/decisions/D1-runner-compute-architecture.md)
  selects dedicated `m7i` EKS managed-node-group capacity, no Karpenter, and
  two warm nodes.
- [Runner startup benchmark](../../../../docs/benchmarks/runner-startup.md)
  shows cold capacity misses the 60-second target at p95 and p99, while two
  warm nodes achieve a 54-second p99.
- [Requirements](../../../../docs/requirements.md) requires 99.9% monthly
  availability, additional usable capacity within 60 seconds, and private
  networking.
- The 2024 `m6i` shared-worker-group recommendation is stale and unapproved;
  see [old architecture notes](../../../../docs/old-architecture-notes.md).

## Resolution

Resolved by [D1 — Adopt dedicated m7i managed-node-group runner capacity](../decisions/D1-runner-compute-architecture.md).
The next concrete slice is [T2 — Provision dedicated warm runner capacity](../tickets/T2-provision-dedicated-warm-runner-capacity.md),
which remains blocked until the lifecycle and IAM boundaries are decided.
