# U3: Define runner IAM responsibilities and least privilege

- Status: open
- Resolution mode: human clarification
- Blocked by: [U2 — Define ARC control-plane and lifecycle scope](U2-arc-control-plane-scope.md)
- Related: [T1 — Resolve the approved runner AMI through SSM](../tickets/T1-approved-runner-ami-lookup.md)

## Question

Which IAM identities are needed for the selected ARC scope, and what minimum
AWS actions and resource conditions may each identity have? In particular,
separate node/bootstrap access from pod/workload access and confirm how the
required permissions boundary applies to every role created by this module.

## Evidence

- [Security requirements](../../../../docs/security-requirements.md) requires
  every role created by the module to set
  `var.permissions_boundary_arn`.
- `terraform/iam.tf` calls for a narrowly scoped runner-node role but supplies
  no approved policy actions or workload identity model.
- The approved AMI is exposed through a platform-owned SSM parameter, which
  may require a specific read permission depending on the selected identity.

## Resolution

Open. This cannot be safely resolved until U2 identifies the managed
identities. It blocks creating IAM roles and policies; it does not block the
read-only Terraform data source in T1.
