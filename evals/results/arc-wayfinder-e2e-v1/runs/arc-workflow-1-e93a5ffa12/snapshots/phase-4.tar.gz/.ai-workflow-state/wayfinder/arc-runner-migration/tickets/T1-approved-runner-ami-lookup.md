# T1: Resolve the approved runner AMI through SSM

- Status: done
- Blocked by: none
- Related: [U3 — Define runner IAM responsibilities and least privilege](../unknowns/U3-runner-iam-least-privilege.md)

## Outcome

The Terraform module reads the runner AMI identifier from the approved
platform-owned SSM parameter `/platform/arc/runner-ami`, without hard-coding an
AMI ID and without creating or mutating infrastructure.

## Acceptance

- Terraform declares a read-only SSM parameter data source for
  `/platform/arc/runner-ami`.
- No literal AMI ID is introduced.
- Offline repository safety tests continue to pass.
- A later compute-resource ticket consumes the lookup only after U1 is
  resolved.

## Notes

Implemented in this repository: `terraform/runners.tf` now contains the
read-only lookup, and the offline safety suite verifies both the required
parameter path and the absence of a literal AMI ID. No compute resource consumes
the lookup until U1 is resolved.
